package com.p2p.util;

public class Constantes {

	public static double MAX_PORCENTAJE_ERROR = 100;
}