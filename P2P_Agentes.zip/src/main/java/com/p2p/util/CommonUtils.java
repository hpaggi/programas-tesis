package com.p2p.util;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;

import org.apache.commons.lang3.builder.RecursiveToStringStyle;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.StandardToStringStyle;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.math.NumberUtils;

public class CommonUtils {

	public static int minimoInts(int... nums) {
		if (nums == null || nums.length == 0) {
			return 0;
		}
		return NumberUtils.min(nums);
	}

	public static int multiplicarInts(int... nums) {
		if (nums == null) {
			return 0;
		}
		if (nums.length == 1) {
			return nums[0];
		}
		int base = nums[0];
		for (int i = 1; i < nums.length; i++) {
			base = base * nums[i];
		}
		return base;
	}

	public static double promedio(final double... nums) {
		if (nums == null) {
			return 0;
		}

		double promedio = 0;
		int cantNums = nums.length;
		double suma = 0;

		for (double num : nums) {
			suma += num;
		}
		promedio = suma / cantNums;

		return promedio;
	}

	public static int getInteger(Object object) {
		if (object instanceof Integer) {
			return Integer.valueOf((int) object);
		} else if (object instanceof Integer) {
			return (int) object;
		} else if (object instanceof String) {
			return Integer.valueOf((String) object);
		}
		return 0;
	}

	public static double getDouble(Object object) {
		if (object instanceof Integer) {
			return Double.valueOf((int) object);
		} else if (object instanceof Double) {
			return (double) object;
		} else if (object instanceof String) {
			return Double.valueOf((String) object);
		}
		return 0;
	}

	public static double doubleBetween(double start, double end) {
		double d = start + Math.random() * ((end - start) + 1);
		return roundDouble(d);
	}

	public static int integerBetween(int start, int end) {
		return start + (int) (Math.random() * ((end - start) + 1));
	}

	public static boolean SI_NO() {
		int i = integerBetween(0, 1);
		if (i == 0) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * toString de Apache Commons customizado para no mostrar el nombre de la clase.
	 *
	 * @return String
	 */
	public static String toStringCommon(Object t) {
		StandardToStringStyle style = new StandardToStringStyle();
		style.setUseClassName(false);
		style.setUseIdentityHashCode(false);
		ToStringBuilder builder = new ReflectionToStringBuilder(t, style);

		return builder.toString();
	}

	/**
	 * toString de Apache Commons customizado para no mostrar el nombre de la clase.
	 *
	 * @return String
	 */
	public static String toStringCommon(Object t, boolean recursive) {
		StandardToStringStyle style = new StandardToStringStyle();
		RecursiveToStringStyle rstyle = new RecursiveToStringStyle();
		style.setUseClassName(false);
		style.setUseIdentityHashCode(false);
		ToStringBuilder builder = null;
		if (recursive) {
			builder = new ReflectionToStringBuilder(t, rstyle);
		} else {
			builder = new ReflectionToStringBuilder(t, style);
		}

		return builder.toString();
	}

	/**
	 * Calcula un intervalo de tiempo entre un {@link Instant} y el momento en que se llama al método
	 * {@link #timing(Instant)}
	 *
	 * @param start
	 *            {@link Instant} (JDK 8) Desde que se comenzó a evaluar el intervalo de tiempo
	 * @return
	 */
	public static Duration timing(Instant start) {
		return Duration.between(start, Instant.now());
	}

	/**
	 * Método que concatena textos en un StringBuilder,
	 * y luego retorna el toString() del objeto.
	 */
	public static String sumStr(final Object str1, final Object... nStr) {
		StringBuilder sb = new StringBuilder();
		if (str1 != null) {
			sb.append(String.valueOf(str1));
		}
		if (nStr != null) {
			for (Object element : nStr) {
				if (element != null) {
					sb.append(String.valueOf(element));
				}
			}
		}
		return sb.toString();
	}

	/**
	 * Redondea un Double a 2 decimales.
	 */
	public static Double roundDouble(final Double value) {
		return roundDouble(value, 2);
	}

	/**
	 * Redondea un Double a la cantidad de decimales pasada por parámetro.
	 */
	public static Double roundDouble(final Double value, final int places) {
		if (value == null) {
			return value;
		}
		if (places < 0) {
			throw new IllegalArgumentException();
		}

		BigDecimal bd = new BigDecimal(String.valueOf(value));
		bd = bd.setScale(places, BigDecimal.ROUND_HALF_UP);
		return bd.doubleValue();
	}

	public static String printFixedSize(Object obj, int size) {
		StringBuilder sb = new StringBuilder();

		if (obj == null) {
			return "";
		}

		String text = obj.toString();

		if (text.length() >= size) {
			return text;
		}
		int cant = size - text.length();
		sb.append(text);

		for (int i = 0; i < cant; i++) {
			sb.append(" ");
		}
		return sb.toString();
	}

	public static String repeatChar(String text, int cant) {
		StringBuilder sb = new StringBuilder();

		if (text == null) {
			return "";
		}

		for (int i = 0; i < cant; i++) {
			sb.append(text);
		}
		return sb.toString();
	}
}