package com.p2p.entidades;

public class Campo {

	private String nombre;
	private ValorCampo valor;
	private boolean calculado;

	public Campo(String nombre, ValorCampo valor, boolean calculado) {
		this.nombre = nombre;
		this.valor = valor;
		this.calculado = calculado;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public ValorCampo getValor() {
		return valor;
	}

	public void setValor(ValorCampo valor) {
		this.valor = valor;
	}

	public boolean isCalculado() {
		return calculado;
	}

	public void setCalculado(boolean calculado) {
		this.calculado = calculado;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(nombre).append("=").append(valor);
		return builder.toString();
	}
}