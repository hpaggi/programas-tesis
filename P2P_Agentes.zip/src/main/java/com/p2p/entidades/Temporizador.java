package com.p2p.entidades;

import com.p2p.logica.LogService;

public class Temporizador {

	private static boolean started;
	private static Thread hilo;

	public static void comenzar() {

		hilo = new Thread(new Runnable() {
			@Override
			public void run() {
				started = true;
				printSegs();
			}
		});
		hilo.start();
	}

	public static void parar() {
		started = false;
		hilo.interrupt();
		LogService.getInstance().writeln();
	}

	private static void printSegs() {
		long base = System.currentTimeMillis();
		long now = 0;
		int segs = 0;
		LogService.getInstance().write(segs + " ");

		while (started) {
			now = System.currentTimeMillis() - base;

			if (now == 1000) {
				LogService.getInstance().write(++segs + " ");
				base = System.currentTimeMillis();
			}
		}
	}
}
