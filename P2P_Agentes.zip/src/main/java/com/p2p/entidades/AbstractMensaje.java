package com.p2p.entidades;

import com.p2p.enums.ITipoCampo;

public abstract class AbstractMensaje {

	public abstract int getIndiceMsg();

	public abstract void setIndiceMsg(int indiceMsg);

	public abstract ITipoCampo getCampoBase();

	public abstract Campo getCampo(ITipoCampo campo);

	public abstract String toStringUnaLinea();

}
