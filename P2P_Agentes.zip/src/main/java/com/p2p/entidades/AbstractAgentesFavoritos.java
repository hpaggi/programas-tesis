package com.p2p.entidades;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;

public abstract class AbstractAgentesFavoritos<VALOR, TIPO_AGENTE> {

	protected Map<VALOR, Set<TIPO_AGENTE>> ranking;
	protected int max = 5;

	public AbstractAgentesFavoritos() {
		ranking = new HashMap<VALOR, Set<TIPO_AGENTE>>();
	}

	public final void inicializar(Collection<TIPO_AGENTE> agentes) {
		for (TIPO_AGENTE agente : agentes) {
			aumentar(agente);
		}
	}

	// public abstract Set<TIPO_AGENTE> getAgentesTop(VALOR cantMax);
	public final Set<TIPO_AGENTE> getAgentesTop(Integer cantMax) {
		Set<TIPO_AGENTE> agentes = new HashSet<TIPO_AGENTE>();

		VALOR puntajeMasAlto = getPuntajeMasAlto();

		Set<TIPO_AGENTE> agentesXPuntaje = ranking.get(puntajeMasAlto);

		for (TIPO_AGENTE agente : agentesXPuntaje) {
			// No lo dejo agregar mas de la cantidad máxima.
			if (agentes.size() == cantMax) {
				break;
			}

			agentes.add(agente);
		}

		return agentes;
	}

	public abstract void aumentar(TIPO_AGENTE agente);

	// protected abstract VALOR getPuntajeMasAlto();
	private final VALOR getPuntajeMasAlto() {
		VALOR puntajeMasAlto = getValorMinimo();
		for (VALOR posicion : ranking.keySet()) {
			if (esMayorQue(posicion, puntajeMasAlto)) {
				// if (posicion > puntajeMasAlto) {
				puntajeMasAlto = posicion;
			}
		}
		return puntajeMasAlto;
	}

	protected abstract VALOR getValorMinimo();

	protected abstract boolean esMayorQue(VALOR valor1, VALOR valor2);

	/**
	 * Devuelve el puntaje actual del agente, o null si no lo contiene.
	 */
	protected VALOR getPuntajeAgenteOrNull(TIPO_AGENTE agente) {
		VALOR puntajeActual = null;
		// Recorro el map para ver si el Agente ya tiene un puntaje.
		for (Entry<VALOR, Set<TIPO_AGENTE>> entry : ranking.entrySet()) {
			VALOR puntaje = entry.getKey();
			Set<TIPO_AGENTE> agentesXPuntaje = entry.getValue();

			// Si ya tenía el Agente en el ranking...
			if (CollectionUtils.isNotEmpty(agentesXPuntaje) && agentesXPuntaje.contains(agente)) {
				puntajeActual = puntaje;
				break;
			}
		}
		return puntajeActual;
	}

	/**
	 * Inserta un agente en el ranking, con el puntaje dado.
	 * No remueve el agente de otro puntaje.
	 */
	protected void insertarAgenteEnPuntaje(TIPO_AGENTE agente, VALOR puntaje) {
		Set<TIPO_AGENTE> agentesXPuntaje = ranking.get(puntaje);

		if (agentesXPuntaje == null) {
			agentesXPuntaje = new HashSet<TIPO_AGENTE>();
		}

		agentesXPuntaje.add(agente);
		ranking.put(puntaje, agentesXPuntaje);
	}

	/**
	 * Borra el agente del puntaje dado.
	 */
	protected void borrarAgenteDePuntaje(TIPO_AGENTE agente, VALOR puntaje) {
		Set<TIPO_AGENTE> agentesXPuntaje = ranking.get(puntaje);

		if (CollectionUtils.isNotEmpty(agentesXPuntaje) && agentesXPuntaje.contains(agente)) {
			agentesXPuntaje.remove(agente);
		}
	}

	@Override
	public final String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("AgentesFavoritos INICIO\n");

		if (CollectionUtils.isNotEmpty(ranking.entrySet())) {
			for (Entry<VALOR, Set<TIPO_AGENTE>> entry : ranking.entrySet()) {
				builder.append("    Ranking ").append(entry.getKey()).append(":\n");

				if (CollectionUtils.isNotEmpty(entry.getValue())) {
					for (TIPO_AGENTE agente : entry.getValue()) {
						builder.append("          ").append(agente).append("\n");
					}
				}
			}
		}
		builder.append("AgentesFavoritos FIN\n");
		return builder.toString();
	}
}