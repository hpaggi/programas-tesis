package com.p2p.entidades.sitiosWeb;

import static com.p2p.util.CommonUtils.SI_NO;
import static com.p2p.util.CommonUtils.getInteger;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;

import com.p2p.entidades.AbstractAgente;
import com.p2p.entidades.SalidaConsulta;
import com.p2p.entidades.ValorCampo;
import com.p2p.enums.Modo;
import com.p2p.enums.TipoLog;
import com.p2p.enums.sitiosWeb.CampoSitioWeb;
import com.p2p.logica.LogService;
import com.p2p.logica.sitiosWeb.MapAgentesSitioWeb;
import com.p2p.util.CommonUtils;

public class AgenteSitioWeb extends
		AbstractAgente<AgenteSitioWeb, MensajeSitioWeb, CampoSitioWeb, AgentesFavoritosSitioWeb, SalidaConsultaOtrosAgentesSitioWeb> {

	private Set<AgenteSitioWeb> agentesConsultados;

	public AgenteSitioWeb(String nombre, boolean soyRaiz, int cantMensajes, int cantMaxFavoritos, int timeoutEsperaRespuesta, int peso,
			Modo modo) {
		super(nombre, soyRaiz, cantMensajes, cantMaxFavoritos, timeoutEsperaRespuesta, peso, modo);
		this.agentesConsultados = new HashSet<AgenteSitioWeb>();
	}

	@Override
	protected Map<CampoSitioWeb, Double> generarPorcentajeError() {
		Map<CampoSitioWeb, Double> map = new HashMap<>();

		for (CampoSitioWeb campo : CampoSitioWeb.values()) {
			map.put(campo, getPorcentajeAleatorio());
		}
		return map;
	}

	/**
	 * Inicializa los agentes favoritos por campo calculado, con todos los agentes disponibles.
	 */
	@Override
	public void inicializarListaFavoritos() {
		for (CampoSitioWeb campoCalculado : CampoSitioWeb.dameListaCamposCalculados()) {
			AgentesFavoritosSitioWeb agentesFavoritos = new AgentesFavoritosSitioWeb();
			agentesFavoritos.inicializar(MapAgentesSitioWeb.values());

			mapAgentesFavoritos.put(campoCalculado, agentesFavoritos);
		}
	}

	@Override
	@SuppressWarnings("deprecation")
	protected SalidaConsultaOtrosAgentesSitioWeb consultarAOtrosAgentes(MensajeSitioWeb mensaje, CampoSitioWeb campoConsultado,
			double miCalidad, AgenteSitioWeb agenteLlamador, int miNivel, double calidadLlamador) {
		Instant now = Instant.now();

		AgenteSitioWeb yo = this;
		SalidaConsultaOtrosAgentesSitioWeb salidaOtrosAgentes = new SalidaConsultaOtrosAgentesSitioWeb();
		List<CampoSitioWeb> listaCamposAConsultar = null;

		// Si soy raiz debo consultar por CAR.
		if (soyRaiz) {
			log("Soy raiz, consulto por campo: " + campoConsultado);
			listaCamposAConsultar = new ArrayList<>();
			listaCamposAConsultar.add(campoConsultado);
		} else {
			// Si no soy raiz, puedo consultar el mismo campo o sus subcampos.
			boolean mismoCampo = SI_NO();
			log("Consulto mismo campo: " + mismoCampo);

			if (mismoCampo) {
				listaCamposAConsultar = new ArrayList<>();
				listaCamposAConsultar.add(campoConsultado);
			} else {
				// Elegir subcampos calculados al azar para consultar a otros agentes.
				listaCamposAConsultar = getListaSubcamposCalculadosAlAzar(campoConsultado);
			}
		}

		Map<CampoSitioWeb, List<ValorCampo>> mapValores = new HashMap<>();
		boolean noMeRespondieron = false;
		boolean noTengoMensajesParaConsultar = false;

		log("Lista de campos a consultar: " + listaCamposAConsultar);

		// Por cada campo, le pregunto su valor a otros agentes.
		for (CampoSitioWeb campoAConsultar : listaCamposAConsultar) {
			// Tomo mi lista de favoritos (Debe ser por campo)
			Set<AgenteSitioWeb> agentesAConsultar = mapAgentesFavoritos.get(campoAConsultar).getAgentesTop(cantMaxFavoritos);

			List<AgenteSitioWeb> lista = new ArrayList<AgenteSitioWeb>(agentesAConsultar);
			Set<Integer> indicesUsados = new HashSet<Integer>();

			mapValores.put(campoAConsultar, new ArrayList<ValorCampo>());

			for (int i = 0; i < agentesAConsultar.size(); i++) {
				AgenteSitioWeb agenteAlAzar = dameAgenteAlAzar(lista, indicesUsados);

				// No puedo consultar al agente que me llamó ni a mi mismo.
				if ((agenteLlamador != null && agenteAlAzar != null && agenteLlamador.equals(agenteAlAzar)) || agenteAlAzar.equals(this)) {
					continue;
				}

				// Si tengo mensajes disponibles, consulto a otros.
				if (tengoMensajesParaConsultar()) {
					log(TipoLog.TENGO_MENSAJES_PARA_CONSULTAR, agenteLlamador, agenteAlAzar, miNivel, mensaje, campoConsultado, miCalidad,
							calidadLlamador);
					agentesConsultados.add(agenteAlAzar);
					salidaOtrosAgentes.setCantAgentesConsultados(agentesConsultados.size());
					consumirMensaje(mensaje);

					SalidaConsulta salida = null;
					Thread hiloConsulta = new Thread(new Runnable() {
						@Override
						public void run() {
							// Pasar mi calidad (error), y el otro se debe fijar si tiene mejor calidad que yo.
							// Si no tiene mejor calidad, no responde.
							agenteAlAzar.consultar(yo, miCalidad, mensaje, campoAConsultar, miNivel);
						}
					});
					log(TipoLog.CONSULTO_A_OTRO, agenteLlamador, agenteAlAzar, miNivel, mensaje, campoAConsultar, miCalidad,
							calidadLlamador);
					hiloConsulta.setName("Hilo de " + agenteAlAzar.getNombre() + " Nivel: " + miNivel);
					hiloConsulta.start();
					HilosAppSitioWeb.putThread(this, hiloConsulta);

					try {
						// Acá se debe esperar cierto tiempo por la consulta.
						// Si responde a tiempo, guardo lo que me devuelve y lo pongo como favorito.
						hiloConsulta.join(timeoutEsperaRespuesta * 1000);

						salida = agenteAlAzar.getSalidaConsulta();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}

					// Si el valor es null, es porque no me respondió por no tener mensajes, por tener peor calidad que yo,
					// o porque no me dió el tiempo para esperarlo (join).
					if (salida != null) {
						log(TipoLog.ME_RESPONDIO, agenteLlamador, agenteAlAzar, miNivel, mensaje, campoAConsultar, miCalidad,
								calidadLlamador);
						salidaOtrosAgentes.agregarCalidad(salida.getCalidad());

						mapValores.get(campoAConsultar).add(salida.getValor());
						mapAgentesFavoritos.get(campoAConsultar).aumentar(agenteAlAzar);
						log(TipoLog.ACTUALIZO_FAVORITOS, agenteLlamador, agenteAlAzar, miNivel, mensaje, campoAConsultar, miCalidad,
								calidadLlamador);
					} else {
						noMeRespondieron = true;
						log(TipoLog.NO_ME_RESPONDIO, agenteLlamador, agenteAlAzar, miNivel, mensaje, campoAConsultar, miCalidad,
								calidadLlamador);
					}
					HilosAppSitioWeb.stopAllThreads(agenteAlAzar);
					hiloConsulta.stop();
				} else {
					noTengoMensajesParaConsultar = true;
					log(TipoLog.NO_TENGO_MENSAJES_PARA_CONSULTAR, agenteLlamador, agenteAlAzar, miNivel, mensaje, campoConsultado,
							miCalidad, calidadLlamador);
					break;
				}
			}
		}

		// Aca recorro el map, para obtener el mejor valor para cada campo
		// y actualizar el mensaje con estos valores.
		if (CollectionUtils.isNotEmpty(mapValores.keySet())) {
			for (CampoSitioWeb campo : mapValores.keySet()) {
				ValorCampo mejorValorCampo = obtenerMejorValorCampo(campo, mapValores.get(campo));

				// Aca hay veces que el valor llega en null porque nadie le respondió para ese campo,
				// o yo no tenía mensajes para consultar a otros. Qué hacer en ese caso???

				if (mejorValorCampo != null && mejorValorCampo.get() != null) {
					mensaje.getCampo(campo).setValor(mejorValorCampo);
				} else {
					// No hago nada y me quedo con el valor que tenía del campo.
					if (noTengoMensajesParaConsultar) {
						log(TipoLog.VALOR_CAMPO_NULL_SIN_MENSAJES, agenteLlamador, null, miNivel, mensaje, campo, miCalidad,
								calidadLlamador);
					}
					if (noMeRespondieron) {
						log(TipoLog.VALOR_CAMPO_NULL_NO_ME_RESPONDIERON, agenteLlamador, null, miNivel, mensaje, campo, miCalidad,
								calidadLlamador);
					}
				}
			}
		}

		salidaOtrosAgentes.setMensaje(mensaje);

		Duration duration = CommonUtils.timing(now);
		LogService.getInstance().writeln(
				"@@@@@@@@@@@@@@@@@@@@@@@@ Duración entre entrada y salida de consultarAOtrosAgentes= " + duration.getSeconds() + " segs.");
		return salidaOtrosAgentes;
	}

	/**
	 * Obtiene el mejor valor de la lista de valores.
	 * Puede ser un promedio, o el valor mas alto.
	 */
	@Override
	protected ValorCampo obtenerMejorValorCampo(CampoSitioWeb campo, List<ValorCampo> listaValores) {
		ValorCampo valor = new ValorCampo(null);

		if (CollectionUtils.isNotEmpty(listaValores)) {
			switch (campo) {
			case RESULT:
			case ADDRESS_BAR_BASED_FEATURES:
			case ABNORMAL_BASED_FEATURES:
			case HTML_AND_JAVASCRIPT_BASED_FEATURES:
			case DOMAIN_BASED_FEATURES:
				double[] numeros = new double[listaValores.size()];
				for (int i = 0; i < listaValores.size(); i++) {
					numeros[i] = (double) listaValores.get(i).get();
				}

				double promedio = CommonUtils.promedio(numeros);
				valor = new ValorCampo(CommonUtils.roundDouble(promedio, 5));
				break;
			default:
				break;
			}
		} else {
			// LogService.getInstance().write("List<ValorCampo> listaValores vacía.");
		}

		return valor;
	}

	@Override
	protected List<CampoSitioWeb> getListaSubcamposCalculadosAlAzar(CampoSitioWeb campoConsultado) {
		List<CampoSitioWeb> lista = new ArrayList<>();

		switch (campoConsultado) {
		case RESULT:
			if (SI_NO()) {
				lista.add(CampoSitioWeb.ADDRESS_BAR_BASED_FEATURES);
			}
			if (SI_NO()) {
				lista.add(CampoSitioWeb.ABNORMAL_BASED_FEATURES);
			}
			if (SI_NO()) {
				lista.add(CampoSitioWeb.HTML_AND_JAVASCRIPT_BASED_FEATURES);
			}
			if (SI_NO()) {
				lista.add(CampoSitioWeb.DOMAIN_BASED_FEATURES);
			}
			break;
		default:
			break;
		}
		return lista;
	}

	@Override
	protected ValorCampo calcularValorCampo(MensajeSitioWeb mensaje, CampoSitioWeb campoConsultado, int miNivel) {
		ValorCampo valorCampo = null;

		try {
			int v_1_1 = 0;
			int v_1_2 = 0;
			int v_1_3 = 0;
			int v_1_4 = 0;
			switch (campoConsultado) {
			case RESULT:
				v_1_1 = getInteger(mensaje.getADDRESS_BAR_BASED_FEATURES().get());
				v_1_2 = getInteger(mensaje.getABNORMAL_BASED_FEATURES().get());
				v_1_3 = getInteger(mensaje.getHTML_AND_JAVASCRIPT_BASED_FEATURES().get());
				v_1_4 = getInteger(mensaje.getDOMAIN_BASED_FEATURES().get());

				int v_1 = CommonUtils.minimoInts(v_1_1, v_1_2, v_1_3, v_1_4);
				valorCampo = new ValorCampo(aplicarMiPorcentajeDeError(campoConsultado, v_1));
				break;
			case ADDRESS_BAR_BASED_FEATURES:
				int v_1_1_1 = getInteger(mensaje.getHaving_IP_Address().get());
				int v_1_1_2 = getInteger(mensaje.getURL_Length().get());
				int v_1_1_3 = getInteger(mensaje.getShortining_Service().get());
				int v_1_1_4 = getInteger(mensaje.getHaving_At_Symbol().get());
				int v_1_1_5 = getInteger(mensaje.getDouble_slash_redirecting().get());
				int v_1_1_6 = getInteger(mensaje.getPrefix_Suffix().get());
				int v_1_1_7 = getInteger(mensaje.getHaving_Sub_Domain().get());
				int v_1_1_8 = getInteger(mensaje.getSSLfinal_State().get());
				int v_1_1_9 = getInteger(mensaje.getDomain_registeration_length().get());
				int v_1_1_10 = getInteger(mensaje.getFavicon().get());
				int v_1_1_11 = getInteger(mensaje.getHTTPS_token().get());
				int v_1_1_12 = getInteger(mensaje.getPort().get());

				v_1_1 = CommonUtils.minimoInts(v_1_1_1, v_1_1_2, v_1_1_3, v_1_1_4, v_1_1_5, v_1_1_6, v_1_1_7, v_1_1_8, v_1_1_9, v_1_1_10,
						v_1_1_11, v_1_1_12);
				valorCampo = new ValorCampo(aplicarMiPorcentajeDeError(campoConsultado, v_1_1));
				break;
			case ABNORMAL_BASED_FEATURES:
				int v_1_2_1 = getInteger(mensaje.getRequest_URL().get());
				int v_1_2_2 = getInteger(mensaje.getURL_of_Anchor().get());
				int v_1_2_3 = getInteger(mensaje.getLinks_in_tags().get());
				int v_1_2_4 = getInteger(mensaje.getSFH().get());
				int v_1_2_5 = getInteger(mensaje.getSubmitting_to_email().get());
				int v_1_2_6 = getInteger(mensaje.getAbnormal_URL().get());

				v_1_2 = CommonUtils.minimoInts(v_1_2_1, v_1_2_2, v_1_2_3, v_1_2_4, v_1_2_5, v_1_2_6);
				valorCampo = new ValorCampo(aplicarMiPorcentajeDeError(campoConsultado, v_1_2));
				break;
			case HTML_AND_JAVASCRIPT_BASED_FEATURES:
				int v_1_3_1 = getInteger(mensaje.getRedirect().get());
				int v_1_3_2 = getInteger(mensaje.getOn_mouseover().get());
				int v_1_3_3 = getInteger(mensaje.getRightClick().get());
				int v_1_3_4 = getInteger(mensaje.getPopUpWidnow().get());
				int v_1_3_5 = getInteger(mensaje.getIframe().get());

				v_1_3 = CommonUtils.minimoInts(v_1_3_1, v_1_3_2, v_1_3_3, v_1_3_4, v_1_3_5);
				valorCampo = new ValorCampo(aplicarMiPorcentajeDeError(campoConsultado, v_1_3));
				break;
			case DOMAIN_BASED_FEATURES:
				int v_1_4_1 = getInteger(mensaje.getAge_of_domain().get());
				int v_1_4_2 = getInteger(mensaje.getDNSRecord().get());
				int v_1_4_3 = getInteger(mensaje.getWeb_traffic().get());
				int v_1_4_4 = getInteger(mensaje.getPage_Rank().get());
				int v_1_4_5 = getInteger(mensaje.getGoogle_Index().get());
				int v_1_4_6 = getInteger(mensaje.getLinks_pointing_to_page().get());
				int v_1_4_7 = getInteger(mensaje.getStatistical_report().get());

				v_1_4 = CommonUtils.minimoInts(v_1_4_1, v_1_4_2, v_1_4_3, v_1_4_4, v_1_4_5, v_1_4_6, v_1_4_7);
				valorCampo = new ValorCampo(aplicarMiPorcentajeDeError(campoConsultado, v_1_4));
				break;
			default:
				// Si no es campo calculado, devuelvo el valor que ya tengo.
				valorCampo = mensaje.getCampo(campoConsultado).getValor();
				break;
			}
		} catch (Exception e) {
			LogService.getInstance().writeln(
					"Error en calcularValorCampo, nivel: " + miNivel + "\n" + mensaje.toString() + "Campo consultado: " + campoConsultado);
			e.printStackTrace();
			throw e;
		}
		return valorCampo;
	}
}