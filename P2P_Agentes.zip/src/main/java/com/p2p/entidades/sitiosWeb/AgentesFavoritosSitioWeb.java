package com.p2p.entidades.sitiosWeb;

import com.p2p.entidades.AbstractAgentesFavoritos;

public class AgentesFavoritosSitioWeb extends AbstractAgentesFavoritos<Integer, AgenteSitioWeb> {

	public AgentesFavoritosSitioWeb() {
		super();
		// ranking = new HashMap<Integer, Set<AgenteSitioWeb>>();
	}

	@Override
	public void aumentar(AgenteSitioWeb agente) {
		// Primero me fijo si ya tenía puntaje o no.
		Integer puntajeActualDelAgente = getPuntajeAgenteOrNull(agente);

		// Si aun no tenía puntaje, lo ingreso con el puntaje 1;
		if (puntajeActualDelAgente == null) {
			insertarAgenteEnPuntaje(agente, 1);
		} else {
			// Pero si ya tenía el agente en el ranking.
			// Primero lo remuevo del puntaje actual.
			borrarAgenteDePuntaje(agente, puntajeActualDelAgente);

			// Y luego lo inserto con el nuevo puntaje.
			insertarAgenteEnPuntaje(agente, puntajeActualDelAgente + 1);
		}
	}

	@Override
	protected Integer getValorMinimo() {
		return 0;
	}

	@Override
	protected boolean esMayorQue(Integer valor1, Integer valor2) {
		if (valor1 > valor2) {
			return true;
		}
		return false;
	}
}