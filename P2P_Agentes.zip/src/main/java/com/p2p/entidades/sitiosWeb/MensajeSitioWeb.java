package com.p2p.entidades.sitiosWeb;

import static com.p2p.enums.sitiosWeb.CampoSitioWeb.ABNORMAL_BASED_FEATURES;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.ADDRESS_BAR_BASED_FEATURES;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.Abnormal_URL;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.DNSRecord;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.DOMAIN_BASED_FEATURES;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.Domain_registeration_length;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.Favicon;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.Google_Index;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.HTML_AND_JAVASCRIPT_BASED_FEATURES;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.HTTPS_token;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.Iframe;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.Links_in_tags;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.Links_pointing_to_page;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.Page_Rank;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.Prefix_Suffix;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.RESULT;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.Redirect;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.Request_URL;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.RightClick;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.SFH;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.SSLfinal_State;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.Shortining_Service;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.Statistical_report;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.Submitting_to_email;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.URL_Length;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.URL_of_Anchor;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.age_of_domain;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.double_slash_redirecting;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.having_At_Symbol;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.having_IP_Address;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.having_Sub_Domain;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.on_mouseover;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.popUpWidnow;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.port;
import static com.p2p.enums.sitiosWeb.CampoSitioWeb.web_traffic;

import java.util.HashMap;
import java.util.Map;

import com.p2p.entidades.Campo;
import com.p2p.entidades.AbstractMensaje;
import com.p2p.entidades.ValorCampo;
import com.p2p.enums.ITipoCampo;
import com.p2p.enums.sitiosWeb.CampoSitioWeb;
import com.p2p.util.CommonUtils;

public class MensajeSitioWeb extends AbstractMensaje {

	private int indiceMsg;
	private Map<CampoSitioWeb, Campo> campos;

	public MensajeSitioWeb() {
		campos = new HashMap<CampoSitioWeb, Campo>();
		
		campos.put( RESULT                              , new Campo(RESULT                             .name(), null,RESULT                             .isCalculado()));
		campos.put( ADDRESS_BAR_BASED_FEATURES          , new Campo(ADDRESS_BAR_BASED_FEATURES         .name(), null,ADDRESS_BAR_BASED_FEATURES                  .isCalculado()));
		campos.put( having_IP_Address                   , new Campo(having_IP_Address                  .name(), null,having_IP_Address                  .isCalculado()));
		campos.put( URL_Length                          , new Campo(URL_Length                         .name(), null,URL_Length                         .isCalculado()));
		campos.put( Shortining_Service                  , new Campo(Shortining_Service                 .name(), null,Shortining_Service                 .isCalculado()));
		campos.put( having_At_Symbol                    , new Campo(having_At_Symbol                   .name(), null,having_At_Symbol                   .isCalculado()));
		campos.put( double_slash_redirecting            , new Campo(double_slash_redirecting           .name(), null,double_slash_redirecting           .isCalculado()));
		campos.put( Prefix_Suffix                       , new Campo(Prefix_Suffix                      .name(), null,Prefix_Suffix                      .isCalculado()));
		campos.put( having_Sub_Domain                   , new Campo(having_Sub_Domain                  .name(), null,having_Sub_Domain                  .isCalculado()));
		campos.put( SSLfinal_State                      , new Campo(SSLfinal_State                     .name(), null,SSLfinal_State                     .isCalculado()));
		campos.put( Domain_registeration_length         , new Campo(Domain_registeration_length        .name(), null,Domain_registeration_length        .isCalculado()));
		campos.put( Favicon                             , new Campo(Favicon                            .name(), null,Favicon                            .isCalculado()));
		campos.put( HTTPS_token                         , new Campo(HTTPS_token                        .name(), null,HTTPS_token                        .isCalculado()));
		campos.put( port                                , new Campo(port                               .name(), null,port                               .isCalculado()));
		campos.put( ABNORMAL_BASED_FEATURES             , new Campo(ABNORMAL_BASED_FEATURES            .name(), null,ABNORMAL_BASED_FEATURES            .isCalculado()));
		campos.put( Request_URL                         , new Campo(Request_URL                        .name(), null,Request_URL                        .isCalculado()));
		campos.put( URL_of_Anchor                       , new Campo(URL_of_Anchor                      .name(), null,URL_of_Anchor                      .isCalculado()));
		campos.put( Links_in_tags                       , new Campo(Links_in_tags                      .name(), null,Links_in_tags                      .isCalculado()));
		campos.put( SFH                                 , new Campo(SFH                                .name(), null,SFH                                .isCalculado()));
		campos.put( Submitting_to_email                 , new Campo(Submitting_to_email                .name(), null,Submitting_to_email                .isCalculado()));
		campos.put( Abnormal_URL                        , new Campo(Abnormal_URL                       .name(), null,Abnormal_URL                       .isCalculado()));
		campos.put( HTML_AND_JAVASCRIPT_BASED_FEATURES  , new Campo(HTML_AND_JAVASCRIPT_BASED_FEATURES .name(), null,HTML_AND_JAVASCRIPT_BASED_FEATURES .isCalculado()));
		campos.put( Redirect                            , new Campo(Redirect                           .name(), null,Redirect                           .isCalculado()));
		campos.put( on_mouseover                        , new Campo(on_mouseover                       .name(), null,on_mouseover                       .isCalculado()));
		campos.put( RightClick                          , new Campo(RightClick                         .name(), null,RightClick                         .isCalculado()));
		campos.put( popUpWidnow                         , new Campo(popUpWidnow                        .name(), null,popUpWidnow                        .isCalculado()));
		campos.put( Iframe                              , new Campo(Iframe                             .name(), null,Iframe                             .isCalculado()));
		campos.put( DOMAIN_BASED_FEATURES               , new Campo(DOMAIN_BASED_FEATURES              .name(), null,DOMAIN_BASED_FEATURES              .isCalculado()));
		campos.put( age_of_domain                       , new Campo(age_of_domain                      .name(), null,age_of_domain                      .isCalculado()));
		campos.put( DNSRecord                           , new Campo(DNSRecord                          .name(), null,DNSRecord                          .isCalculado()));
		campos.put( web_traffic                         , new Campo(web_traffic                        .name(), null,web_traffic                        .isCalculado()));
		campos.put( Page_Rank                           , new Campo(Page_Rank                          .name(), null,Page_Rank                          .isCalculado()));
		campos.put( Google_Index                        , new Campo(Google_Index                       .name(), null,Google_Index                       .isCalculado()));
		campos.put( Links_pointing_to_page              , new Campo(Links_pointing_to_page             .name(), null,Links_pointing_to_page             .isCalculado()));
		campos.put( Statistical_report                  , new Campo(Statistical_report                 .name(), null,Statistical_report                 .isCalculado()));
	}

	@Override
	public int getIndiceMsg() {
		return indiceMsg;
	}

	@Override
	public void setIndiceMsg(int indiceMsg) {
		this.indiceMsg = indiceMsg;
	}
	
	@Override
	public CampoSitioWeb getCampoBase() {
		return RESULT;
	}

	@Override
	public Campo getCampo(ITipoCampo campo) {
		return campos.get(campo);
	}

	public ValorCampo getRESULT() {
		return campos.get(RESULT).getValor();
	}

	public void setRESULT(ValorCampo valor) {
		campos.get(RESULT).setValor(valor);
	}

	public ValorCampo getADDRESS_BAR_BASED_FEATURES() {
		return campos.get(ADDRESS_BAR_BASED_FEATURES).getValor();
	}

	public void setADDRESS_BAR_BASED_FEATURES(ValorCampo valor) {
		campos.get(ADDRESS_BAR_BASED_FEATURES).setValor(valor);
	}

	public ValorCampo getHaving_IP_Address() {
		return campos.get(having_IP_Address).getValor();
	}

	public void setHaving_IP_Address(ValorCampo valor) {
		campos.get(having_IP_Address).setValor(valor);
	}

	public ValorCampo getURL_Length() {
		return campos.get(URL_Length).getValor();
	}

	public void setURL_Length(ValorCampo valor) {
		campos.get(URL_Length).setValor(valor);
	}

	public ValorCampo getShortining_Service() {
		return campos.get(Shortining_Service).getValor();
	}

	public void setShortining_Service(ValorCampo valor) {
		campos.get(Shortining_Service).setValor(valor);
	}

	public ValorCampo getHaving_At_Symbol() {
		return campos.get(having_At_Symbol).getValor();
	}

	public void setHaving_At_Symbol(ValorCampo valor) {
		campos.get(having_At_Symbol).setValor(valor);
	}

	public ValorCampo getDouble_slash_redirecting() {
		return campos.get(double_slash_redirecting).getValor();
	}

	public void setDouble_slash_redirecting(ValorCampo valor) {
		campos.get(double_slash_redirecting).setValor(valor);
	}

	public ValorCampo getPrefix_Suffix() {
		return campos.get(Prefix_Suffix).getValor();
	}

	public void setPrefix_Suffix(ValorCampo valor) {
		campos.get(Prefix_Suffix).setValor(valor);
	}

	public ValorCampo getHaving_Sub_Domain() {
		return campos.get(having_Sub_Domain).getValor();
	}

	public void setHaving_Sub_Domain(ValorCampo valor) {
		campos.get(having_Sub_Domain).setValor(valor);
	}

	public ValorCampo getSSLfinal_State() {
		return campos.get(SSLfinal_State).getValor();
	}

	public void setSSLfinal_State(ValorCampo valor) {
		campos.get(SSLfinal_State).setValor(valor);
	}

	public ValorCampo getDomain_registeration_length() {
		return campos.get(Domain_registeration_length).getValor();
	}

	public void setDomain_registeration_length(ValorCampo valor) {
		campos.get(Domain_registeration_length).setValor(valor);
	}

	public ValorCampo getFavicon() {
		return campos.get(Favicon).getValor();
	}

	public void setFavicon(ValorCampo valor) {
		campos.get(Favicon).setValor(valor);
	}

	public ValorCampo getHTTPS_token() {
		return campos.get(HTTPS_token).getValor();
	}

	public void setHTTPS_token(ValorCampo valor) {
		campos.get(HTTPS_token).setValor(valor);
	}

	public ValorCampo getPort() {
		return campos.get(port).getValor();
	}

	public void setPort(ValorCampo valor) {
		campos.get(port).setValor(valor);
	}

	public ValorCampo getABNORMAL_BASED_FEATURES() {
		return campos.get(ABNORMAL_BASED_FEATURES).getValor();
	}

	public void setABNORMAL_BASED_FEATURES(ValorCampo valor) {
		campos.get(ABNORMAL_BASED_FEATURES).setValor(valor);
	}

	public ValorCampo getRequest_URL() {
		return campos.get(Request_URL).getValor();
	}

	public void setRequest_URL(ValorCampo valor) {
		campos.get(Request_URL).setValor(valor);
	}

	public ValorCampo getURL_of_Anchor() {
		return campos.get(URL_of_Anchor).getValor();
	}

	public void setURL_of_Anchor(ValorCampo valor) {
		campos.get(URL_of_Anchor).setValor(valor);
	}

	public ValorCampo getLinks_in_tags() {
		return campos.get(Links_in_tags).getValor();
	}

	public void setLinks_in_tags(ValorCampo valor) {
		campos.get(Links_in_tags).setValor(valor);
	}

	public ValorCampo getSFH() {
		return campos.get(SFH).getValor();
	}

	public void setSFH(ValorCampo valor) {
		campos.get(SFH).setValor(valor);
	}

	public ValorCampo getSubmitting_to_email() {
		return campos.get(Submitting_to_email).getValor();
	}

	public void setSubmitting_to_email(ValorCampo valor) {
		campos.get(Submitting_to_email).setValor(valor);
	}

	public ValorCampo getAbnormal_URL() {
		return campos.get(Abnormal_URL).getValor();
	}

	public void setAbnormal_URL(ValorCampo valor) {
		campos.get(Abnormal_URL).setValor(valor);
	}

	public ValorCampo getHTML_AND_JAVASCRIPT_BASED_FEATURES() {
		return campos.get(HTML_AND_JAVASCRIPT_BASED_FEATURES).getValor();
	}

	public void setHTML_AND_JAVASCRIPT_BASED_FEATURES(ValorCampo valor) {
		campos.get(HTML_AND_JAVASCRIPT_BASED_FEATURES).setValor(valor);
	}

	public ValorCampo getRedirect() {
		return campos.get(Redirect).getValor();
	}

	public void setRedirect(ValorCampo valor) {
		campos.get(Redirect).setValor(valor);
	}

	public ValorCampo getOn_mouseover() {
		return campos.get(on_mouseover).getValor();
	}

	public void setOn_mouseover(ValorCampo valor) {
		campos.get(on_mouseover).setValor(valor);
	}

	public ValorCampo getRightClick() {
		return campos.get(RightClick).getValor();
	}

	public void setRightClick(ValorCampo valor) {
		campos.get(RightClick).setValor(valor);
	}

	public ValorCampo getPopUpWidnow() {
		return campos.get(popUpWidnow).getValor();
	}

	public void setPopUpWidnow(ValorCampo valor) {
		campos.get(popUpWidnow).setValor(valor);
	}

	public ValorCampo getIframe() {
		return campos.get(Iframe).getValor();
	}

	public void setIframe(ValorCampo valor) {
		campos.get(Iframe).setValor(valor);
	}

	public ValorCampo getDOMAIN_BASED_FEATURES() {
		return campos.get(DOMAIN_BASED_FEATURES).getValor();
	}

	public void setDOMAIN_BASED_FEATURES(ValorCampo valor) {
		campos.get(DOMAIN_BASED_FEATURES).setValor(valor);
	}

	public ValorCampo getAge_of_domain() {
		return campos.get(age_of_domain).getValor();
	}

	public void setAge_of_domain(ValorCampo valor) {
		campos.get(age_of_domain).setValor(valor);
	}

	public ValorCampo getDNSRecord() {
		return campos.get(DNSRecord).getValor();
	}

	public void setDNSRecord(ValorCampo valor) {
		campos.get(DNSRecord).setValor(valor);
	}

	public ValorCampo getWeb_traffic() {
		return campos.get(web_traffic).getValor();
	}

	public void setWeb_traffic(ValorCampo valor) {
		campos.get(web_traffic).setValor(valor);
	}

	public ValorCampo getPage_Rank() {
		return campos.get(Page_Rank).getValor();
	}

	public void setPage_Rank(ValorCampo valor) {
		campos.get(Page_Rank).setValor(valor);
	}

	public ValorCampo getGoogle_Index() {
		return campos.get(Google_Index).getValor();
	}

	public void setGoogle_Index(ValorCampo valor) {
		campos.get(Google_Index).setValor(valor);
	}

	public ValorCampo getLinks_pointing_to_page() {
		return campos.get(Links_pointing_to_page).getValor();
	}

	public void setLinks_pointing_to_page(ValorCampo valor) {
		campos.get(Links_pointing_to_page).setValor(valor);
	}

	public ValorCampo getStatistical_report() {
		return campos.get(Statistical_report).getValor();
	}

	public void setStatistical_report(ValorCampo valor) {
		campos.get(Statistical_report).setValor(valor);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("MensajeSitiosWeb INICIO\n");

		builder.append("     ").append(campos.get(RESULT)).append("\n");
		builder.append("     ").append(campos.get(ADDRESS_BAR_BASED_FEATURES)).append("\n");
		builder.append("     ").append(campos.get(having_IP_Address)).append("\n");
		builder.append("     ").append(campos.get(URL_Length)).append("\n");
		builder.append("     ").append(campos.get(Shortining_Service)).append("\n");
		builder.append("     ").append(campos.get(having_At_Symbol)).append("\n");
		builder.append("     ").append(campos.get(double_slash_redirecting)).append("\n");
		builder.append("     ").append(campos.get(Prefix_Suffix)).append("\n");
		builder.append("     ").append(campos.get(having_Sub_Domain)).append("\n");
		builder.append("     ").append(campos.get(SSLfinal_State)).append("\n");
		builder.append("     ").append(campos.get(Domain_registeration_length)).append("\n");
		builder.append("     ").append(campos.get(Favicon)).append("\n");
		builder.append("     ").append(campos.get(HTTPS_token)).append("\n");
		builder.append("     ").append(campos.get(port)).append("\n");
		builder.append("     ").append(campos.get(ABNORMAL_BASED_FEATURES)).append("\n");
		builder.append("     ").append(campos.get(Request_URL)).append("\n");
		builder.append("     ").append(campos.get(URL_of_Anchor)).append("\n");
		builder.append("     ").append(campos.get(Links_in_tags)).append("\n");
		builder.append("     ").append(campos.get(SFH)).append("\n");
		builder.append("     ").append(campos.get(Submitting_to_email)).append("\n");
		builder.append("     ").append(campos.get(Abnormal_URL)).append("\n");
		builder.append("     ").append(campos.get(HTML_AND_JAVASCRIPT_BASED_FEATURES)).append("\n");
		builder.append("     ").append(campos.get(Redirect)).append("\n");
		builder.append("     ").append(campos.get(on_mouseover)).append("\n");
		builder.append("     ").append(campos.get(RightClick)).append("\n");
		builder.append("     ").append(campos.get(popUpWidnow)).append("\n");
		builder.append("     ").append(campos.get(Iframe)).append("\n");
		builder.append("     ").append(campos.get(DOMAIN_BASED_FEATURES)).append("\n");
		builder.append("     ").append(campos.get(age_of_domain)).append("\n");
		builder.append("     ").append(campos.get(DNSRecord)).append("\n");
		builder.append("     ").append(campos.get(web_traffic)).append("\n");
		builder.append("     ").append(campos.get(Page_Rank)).append("\n");
		builder.append("     ").append(campos.get(Google_Index)).append("\n");
		builder.append("     ").append(campos.get(Links_pointing_to_page)).append("\n");
		builder.append("     ").append(campos.get(Statistical_report)).append("\n");
		builder.append("MensajeSitiosWeb FIN\n");

		return builder.toString();
	}

	@Override
	public String toStringUnaLinea() {
		StringBuilder builder = new StringBuilder();
		builder.append("MensajeSitiosWeb [");

		builder.append(CommonUtils.printFixedSize(campos.get(RESULT), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(ADDRESS_BAR_BASED_FEATURES), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(having_IP_Address), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(URL_Length), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(Shortining_Service), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(having_At_Symbol), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(double_slash_redirecting), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(Prefix_Suffix), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(having_Sub_Domain), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(SSLfinal_State), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(Domain_registeration_length), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(Favicon), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(HTTPS_token), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(port), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(ABNORMAL_BASED_FEATURES), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(Request_URL), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(URL_of_Anchor), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(Links_in_tags), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(SFH), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(Submitting_to_email), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(Abnormal_URL), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(HTML_AND_JAVASCRIPT_BASED_FEATURES), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(Redirect), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(on_mouseover), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(RightClick), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(popUpWidnow), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(Iframe), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(DOMAIN_BASED_FEATURES), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(age_of_domain), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(DNSRecord), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(web_traffic), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(Page_Rank), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(Google_Index), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(Links_pointing_to_page), 2)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(Statistical_report), 2)).append(" ");
		builder.append("]");

		return builder.toString();
	}
}