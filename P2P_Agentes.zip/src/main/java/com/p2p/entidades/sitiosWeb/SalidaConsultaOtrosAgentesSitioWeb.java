package com.p2p.entidades.sitiosWeb;

import com.p2p.entidades.AbstractSalidaConsultaOtrosAgentes;

public class SalidaConsultaOtrosAgentesSitioWeb extends AbstractSalidaConsultaOtrosAgentes<MensajeSitioWeb> {

}