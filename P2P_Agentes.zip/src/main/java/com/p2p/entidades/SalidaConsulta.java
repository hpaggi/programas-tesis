package com.p2p.entidades;

public class SalidaConsulta {

	private ValorCampo valor;
	private Double calidad;

	public ValorCampo getValor() {
		return valor;
	}

	public void setValor(ValorCampo valor) {
		this.valor = valor;
	}

	public Double getCalidad() {
		return calidad;
	}

	public void setCalidad(Double calidad) {
		this.calidad = calidad;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Salida [valor=").append(valor).append(", calidad=").append(calidad).append("]");
		return builder.toString();
	}
}