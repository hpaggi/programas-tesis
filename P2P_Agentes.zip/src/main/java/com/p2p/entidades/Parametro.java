package com.p2p.entidades;

import com.p2p.enums.TipoParametro;

public class Parametro {

	private TipoParametro tipo;
	private Object valor;

	public Parametro(TipoParametro tipo, Object valor) {
		this.tipo = tipo;
		this.valor = valor;
	}

	public TipoParametro getTipo() {
		return tipo;
	}

	public void setTipo(TipoParametro tipo) {
		this.tipo = tipo;
	}

	public Object getValor() {
		return valor;
	}

	public void setValor(Object valor) {
		this.valor = valor;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Parametro [tipo=").append(tipo).append(", valor=").append(valor).append("]");
		return builder.toString();
	}

}