package com.p2p.entidades.creditos;

import static com.p2p.util.CommonUtils.SI_NO;
import static com.p2p.util.CommonUtils.getInteger;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;

import com.p2p.entidades.AbstractAgente;
import com.p2p.entidades.SalidaConsulta;
import com.p2p.entidades.ValorCampo;
import com.p2p.enums.Modo;
import com.p2p.enums.TipoLog;
import com.p2p.enums.creditos.CampoCredito;
import com.p2p.logica.LogService;
import com.p2p.logica.creditos.MapAgentesCredito;
import com.p2p.util.CommonUtils;

public class AgenteCredito
		extends AbstractAgente<AgenteCredito, MensajeCredito, CampoCredito, AgentesFavoritosCredito, SalidaConsultaOtrosAgentesCredito> {

	private Set<AgenteCredito> agentesConsultados;

	public AgenteCredito(String nombre, boolean soyRaiz, int cantMensajes, int cantMaxFavoritos, int timeoutEsperaRespuesta, int peso,
			Modo modo) {
		super(nombre, soyRaiz, cantMensajes, cantMaxFavoritos, timeoutEsperaRespuesta, peso, modo);
		this.agentesConsultados = new HashSet<AgenteCredito>();
	}

	@Override
	protected Map<CampoCredito, Double> generarPorcentajeError() {
		Map<CampoCredito, Double> map = new HashMap<>();

		for (CampoCredito campo : CampoCredito.values()) {
			map.put(campo, getPorcentajeAleatorio());
		}
		return map;
	}

	/**
	 * Inicializa los agentes favoritos por campo calculado, con todos los agentes disponibles.
	 */
	@Override
	public void inicializarListaFavoritos() {
		for (CampoCredito campoCalculado : CampoCredito.dameListaCamposCalculados()) {
			AgentesFavoritosCredito agentesFavoritos = new AgentesFavoritosCredito();
			agentesFavoritos.inicializar(MapAgentesCredito.values());

			mapAgentesFavoritos.put(campoCalculado, agentesFavoritos);
		}
	}

	@Override
	@SuppressWarnings("deprecation")
	protected SalidaConsultaOtrosAgentesCredito consultarAOtrosAgentes(MensajeCredito mensaje, CampoCredito campoConsultado,
			double miCalidad, AgenteCredito agenteLlamador, int miNivel, double calidadLlamador) {
		Instant now = Instant.now();

		AgenteCredito yo = this;
		SalidaConsultaOtrosAgentesCredito salidaOtrosAgentes = new SalidaConsultaOtrosAgentesCredito();
		List<CampoCredito> listaCamposAConsultar = null;

		// Si soy raiz debo consultar por RESULT.
		if (soyRaiz) {
			log("Soy raiz, consulto por campo: " + campoConsultado);
			listaCamposAConsultar = new ArrayList<>();
			listaCamposAConsultar.add(campoConsultado);
		} else {
			// Si no soy raiz, puedo consultar el mismo campo o sus subcampos.
			boolean mismoCampo = SI_NO();
			log("Consulto mismo campo: " + mismoCampo);

			if (mismoCampo) {
				listaCamposAConsultar = new ArrayList<>();
				listaCamposAConsultar.add(campoConsultado);
			} else {
				// Elegir subcampos calculados al azar para consultar a otros agentes.
				listaCamposAConsultar = getListaSubcamposCalculadosAlAzar(campoConsultado);
			}
		}

		Map<CampoCredito, List<ValorCampo>> mapValores = new HashMap<>();
		boolean noMeRespondieron = false;
		boolean noTengoMensajesParaConsultar = false;

		log("Lista de campos a consultar: " + listaCamposAConsultar);

		// Por cada campo, le pregunto su valor a otros agentes.
		for (CampoCredito campoAConsultar : listaCamposAConsultar) {
			// Tomo mi lista de favoritos (Debe ser por campo)
			Set<AgenteCredito> agentesAConsultar = mapAgentesFavoritos.get(campoAConsultar).getAgentesTop(cantMaxFavoritos);

			List<AgenteCredito> lista = new ArrayList<AgenteCredito>(agentesAConsultar);
			Set<Integer> indicesUsados = new HashSet<Integer>();

			mapValores.put(campoAConsultar, new ArrayList<ValorCampo>());

			for (int i = 0; i < agentesAConsultar.size(); i++) {
				AgenteCredito agenteAlAzar = dameAgenteAlAzar(lista, indicesUsados);

				// No puedo consultar al agente que me llamó ni a mi mismo.
				if ((agenteLlamador != null && agenteAlAzar != null && agenteLlamador.equals(agenteAlAzar)) || agenteAlAzar.equals(this)) {
					continue;
				}

				// Si tengo mensajes disponibles, consulto a otros.
				if (tengoMensajesParaConsultar()) {
					log(TipoLog.TENGO_MENSAJES_PARA_CONSULTAR, agenteLlamador, agenteAlAzar, miNivel, mensaje, campoConsultado, miCalidad,
							calidadLlamador);
					agentesConsultados.add(agenteAlAzar);
					salidaOtrosAgentes.setCantAgentesConsultados(agentesConsultados.size());
					consumirMensaje(mensaje);

					SalidaConsulta salida = null;
					Thread hiloConsulta = new Thread(new Runnable() {
						@Override
						public void run() {
							// Pasar mi calidad (error), y el otro se debe fijar si tiene mejor calidad que yo.
							// Si no tiene mejor calidad, no responde.
							agenteAlAzar.consultar(yo, miCalidad, mensaje, campoAConsultar, miNivel);
						}
					});
					log(TipoLog.CONSULTO_A_OTRO, agenteLlamador, agenteAlAzar, miNivel, mensaje, campoAConsultar, miCalidad,
							calidadLlamador);
					hiloConsulta.setName("Hilo de " + agenteAlAzar.getNombre() + " Nivel: " + miNivel);
					hiloConsulta.start();
					HilosAppCredito.putThread(this, hiloConsulta);

					try {
						// Acá se debe esperar cierto tiempo por la consulta.
						// Si responde a tiempo, guardo lo que me devuelve y lo pongo como favorito.
						hiloConsulta.join(timeoutEsperaRespuesta * 1000);

						salida = agenteAlAzar.getSalidaConsulta();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}

					// Si el valor es null, es porque no me respondió por no tener mensajes, por tener peor calidad que yo,
					// o porque no me dió el tiempo para esperarlo (join).
					if (salida != null) {
						log(TipoLog.ME_RESPONDIO, agenteLlamador, agenteAlAzar, miNivel, mensaje, campoAConsultar, miCalidad,
								calidadLlamador);
						salidaOtrosAgentes.agregarCalidad(salida.getCalidad());

						mapValores.get(campoAConsultar).add(salida.getValor());
						mapAgentesFavoritos.get(campoAConsultar).aumentar(agenteAlAzar);
						log(TipoLog.ACTUALIZO_FAVORITOS, agenteLlamador, agenteAlAzar, miNivel, mensaje, campoAConsultar, miCalidad,
								calidadLlamador);
					} else {
						noMeRespondieron = true;
						log(TipoLog.NO_ME_RESPONDIO, agenteLlamador, agenteAlAzar, miNivel, mensaje, campoAConsultar, miCalidad,
								calidadLlamador);
					}
					HilosAppCredito.stopAllThreads(agenteAlAzar);
					hiloConsulta.stop();
				} else {
					noTengoMensajesParaConsultar = true;
					log(TipoLog.NO_TENGO_MENSAJES_PARA_CONSULTAR, agenteLlamador, agenteAlAzar, miNivel, mensaje, campoConsultado,
							miCalidad, calidadLlamador);
					break;
				}
			}
		}

		// Aca recorro el map, para obtener el mejor valor para cada campo
		// y actualizar el mensaje con estos valores.
		if (CollectionUtils.isNotEmpty(mapValores.keySet())) {
			for (CampoCredito campo : mapValores.keySet()) {
				ValorCampo mejorValorCampo = obtenerMejorValorCampo(campo, mapValores.get(campo));

				// Aca hay veces que el valor llega en null porque nadie le respondió para ese campo,
				// o yo no tenía mensajes para consultar a otros. Qué hacer en ese caso???

				if (mejorValorCampo != null && mejorValorCampo.get() != null) {
					mensaje.getCampo(campo).setValor(mejorValorCampo);
				} else {
					// No hago nada y me quedo con el valor que tenía del campo.
					if (noTengoMensajesParaConsultar) {
						log(TipoLog.VALOR_CAMPO_NULL_SIN_MENSAJES, agenteLlamador, null, miNivel, mensaje, campo, miCalidad,
								calidadLlamador);
					}
					if (noMeRespondieron) {
						log(TipoLog.VALOR_CAMPO_NULL_NO_ME_RESPONDIERON, agenteLlamador, null, miNivel, mensaje, campo, miCalidad,
								calidadLlamador);
					}
				}
			}
		}

		salidaOtrosAgentes.setMensaje(mensaje);

		Duration duration = CommonUtils.timing(now);
		LogService.getInstance().writeln(
				"@@@@@@@@@@@@@@@@@@@@@@@@ Duración entre entrada y salida de consultarAOtrosAgentes= " + duration.getSeconds() + " segs.");
		return salidaOtrosAgentes;
	}

	/**
	 * Obtiene el mejor valor de la lista de valores.
	 * Puede ser un promedio, o el valor mas alto.
	 */
	@Override
	protected ValorCampo obtenerMejorValorCampo(CampoCredito campo, List<ValorCampo> listaValores) {
		ValorCampo valor = new ValorCampo(null);

		if (CollectionUtils.isNotEmpty(listaValores)) {
			switch (campo) {
			case RESULT:
			case FAC_NEGATIVOS:
			case FAC_POSITIVOS:
				double[] numeros = new double[listaValores.size()];
				for (int i = 0; i < listaValores.size(); i++) {
					numeros[i] = (double) listaValores.get(i).get();
				}

				double promedio = CommonUtils.promedio(numeros);
				valor = new ValorCampo(CommonUtils.roundDouble(promedio, 5));
				break;
			default:
				break;
			}
		} else {
			// LogService.getInstance().write("List<ValorCampo> listaValores vacía.");
		}

		return valor;
	}

	@Override
	protected List<CampoCredito> getListaSubcamposCalculadosAlAzar(CampoCredito campoConsultado) {
		List<CampoCredito> lista = new ArrayList<>();

		switch (campoConsultado) {
		case RESULT:
			if (SI_NO()) {
				lista.add(CampoCredito.FAC_NEGATIVOS);
			}
			if (SI_NO()) {
				lista.add(CampoCredito.FAC_POSITIVOS);
			}
			break;
		default:
			break;
		}
		return lista;
	}

	@Override
	protected ValorCampo calcularValorCampo(MensajeCredito mensaje, CampoCredito campoConsultado, int miNivel) {
		ValorCampo valorCampo = null;

		try {
			switch (campoConsultado) {
			case RESULT:
				// el valor del RESULTADO es 2 si FAC_POSITIVOS/FAC_NEGATIVOS < 0.5 y 1 en otro caso
				Double neg = CommonUtils.getDouble(mensaje.getFAC_NEGATIVOS().get());
				Double pos = CommonUtils.getDouble(mensaje.getFAC_POSITIVOS().get());

				Double div = pos / neg;
				int valorResult = 0;

				if (div < 0.5) {
					valorResult = 2;
				} else {
					valorResult = 1;
				}

				valorCampo = new ValorCampo(aplicarMiPorcentajeDeError(campoConsultado, valorResult));
				break;
			case FAC_NEGATIVOS:
				int C2 = getInteger(mensaje.getC2().get());
				int C4 = getInteger(mensaje.getC4().get());
				int C5 = getInteger(mensaje.getC5().get());
				int C6 = getInteger(mensaje.getC6().get());
				int C9 = getInteger(mensaje.getC9().get());
				int C10 = getInteger(mensaje.getC10().get());
				// int C12 = getInteger(mensaje.getC12().get());
				int C13 = getInteger(mensaje.getC13().get());
				int C14 = getInteger(mensaje.getC14().get());
				int C16 = getInteger(mensaje.getC16().get());
				int C18 = getInteger(mensaje.getC18().get());
				int C20 = getInteger(mensaje.getC20().get());

				double valorNeg = C2 + C4 + C5 / 1000 + C6 + C9 + C10 + C13 / 10 + C14 + C16 + C18 + C20;

				valorCampo = new ValorCampo(aplicarMiPorcentajeDeError(campoConsultado, valorNeg));
				break;
			case FAC_POSITIVOS:
				int C1 = getInteger(mensaje.getC1().get());
				int C3 = getInteger(mensaje.getC3().get());
				int C7 = getInteger(mensaje.getC7().get());
				int C8 = getInteger(mensaje.getC8().get());
				int C11 = getInteger(mensaje.getC11().get());
				// int C12 = getInteger(mensaje.getC12().get());
				int C15 = getInteger(mensaje.getC15().get());
				int C17 = getInteger(mensaje.getC17().get());
				int C19 = getInteger(mensaje.getC19().get());

				double valorPos = C1 + C3 + C7 + C8 + C11 + C15 + C17 + C19;
				valorCampo = new ValorCampo(aplicarMiPorcentajeDeError(campoConsultado, valorPos));
				break;
			default:
				// Si no es campo calculado, devuelvo el valor que ya tengo.
				valorCampo = mensaje.getCampo(campoConsultado).getValor();
				break;
			}
		} catch (Exception e) {
			LogService.getInstance().writeln(
					"Error en calcularValorCampo, nivel: " + miNivel + "\n" + mensaje.toString() + "Campo consultado: " + campoConsultado);
			e.printStackTrace();
			throw e;
		}
		return valorCampo;
	}
}