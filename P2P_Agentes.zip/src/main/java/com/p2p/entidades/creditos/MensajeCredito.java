package com.p2p.entidades.creditos;

import static com.p2p.enums.creditos.CampoCredito.C1;
import static com.p2p.enums.creditos.CampoCredito.C10;
import static com.p2p.enums.creditos.CampoCredito.C11;
import static com.p2p.enums.creditos.CampoCredito.C12;
import static com.p2p.enums.creditos.CampoCredito.C13;
import static com.p2p.enums.creditos.CampoCredito.C14;
import static com.p2p.enums.creditos.CampoCredito.C15;
import static com.p2p.enums.creditos.CampoCredito.C16;
import static com.p2p.enums.creditos.CampoCredito.C17;
import static com.p2p.enums.creditos.CampoCredito.C18;
import static com.p2p.enums.creditos.CampoCredito.C19;
import static com.p2p.enums.creditos.CampoCredito.C2;
import static com.p2p.enums.creditos.CampoCredito.C20;
import static com.p2p.enums.creditos.CampoCredito.C3;
import static com.p2p.enums.creditos.CampoCredito.C4;
import static com.p2p.enums.creditos.CampoCredito.C5;
import static com.p2p.enums.creditos.CampoCredito.C6;
import static com.p2p.enums.creditos.CampoCredito.C7;
import static com.p2p.enums.creditos.CampoCredito.C8;
import static com.p2p.enums.creditos.CampoCredito.C9;
import static com.p2p.enums.creditos.CampoCredito.FAC_NEGATIVOS;
import static com.p2p.enums.creditos.CampoCredito.FAC_POSITIVOS;
import static com.p2p.enums.creditos.CampoCredito.RESULT;

import java.util.HashMap;
import java.util.Map;

import com.p2p.entidades.Campo;
import com.p2p.entidades.AbstractMensaje;
import com.p2p.entidades.ValorCampo;
import com.p2p.enums.ITipoCampo;
import com.p2p.enums.creditos.CampoCredito;
import com.p2p.util.CommonUtils;

public class MensajeCredito extends AbstractMensaje {

	private int indiceMsg;
	private Map<CampoCredito, Campo> campos;

	public MensajeCredito() {
		campos = new HashMap<CampoCredito, Campo>();
		
		campos.put(RESULT			, new Campo(RESULT			.name(), null,RESULT			.isCalculado()));
		campos.put(FAC_POSITIVOS	, new Campo(FAC_POSITIVOS	.name(), null,FAC_POSITIVOS	    .isCalculado()));
		campos.put(C1				, new Campo(C1				.name(), null,C1				.isCalculado()));
		campos.put(C3				, new Campo(C3				.name(), null,C3				.isCalculado()));
		campos.put(C7				, new Campo(C7				.name(), null,C7				.isCalculado()));
		campos.put(C8				, new Campo(C8				.name(), null,C8				.isCalculado()));
		campos.put(C11				, new Campo(C11				.name(), null,C11				.isCalculado()));
		campos.put(C15				, new Campo(C15				.name(), null,C15				.isCalculado()));
		campos.put(C17				, new Campo(C17				.name(), null,C17				.isCalculado()));
		campos.put(C19				, new Campo(C19				.name(), null,C19				.isCalculado()));
		campos.put(FAC_NEGATIVOS	, new Campo(FAC_NEGATIVOS	.name(), null,FAC_NEGATIVOS		.isCalculado()));
		campos.put(C2				, new Campo(C2				.name(), null,C2				.isCalculado()));
		campos.put(C4				, new Campo(C4				.name(), null,C4				.isCalculado()));
		campos.put(C5				, new Campo(C5				.name(), null,C5				.isCalculado()));
		campos.put(C6				, new Campo(C6				.name(), null,C6				.isCalculado()));
		campos.put(C9				, new Campo(C9				.name(), null,C9				.isCalculado()));
		campos.put(C10				, new Campo(C10				.name(), null,C10				.isCalculado()));
		campos.put(C13				, new Campo(C13				.name(), null,C13				.isCalculado()));
		campos.put(C14				, new Campo(C14				.name(), null,C14				.isCalculado()));
		campos.put(C16				, new Campo(C16				.name(), null,C16				.isCalculado()));
		campos.put(C18				, new Campo(C18				.name(), null,C18				.isCalculado()));
		campos.put(C20				, new Campo(C20				.name(), null,C20				.isCalculado()));
		
		campos.put(C12				, new Campo(C12				.name(), null,C12				.isCalculado()));
	}
	
	@Override
	public int getIndiceMsg() {
		return indiceMsg;
	}

	@Override
	public void setIndiceMsg(int indiceMsg) {
		this.indiceMsg = indiceMsg;
	}
	
	@Override
	public CampoCredito getCampoBase() {
		return RESULT;
	}
	
	public Campo getCampo(ITipoCampo campo) {
		return campos.get(campo);
	}

	public ValorCampo getRESULT() {
		return campos.get(RESULT).getValor();
	}

	public void setRESULT(ValorCampo valor) {
		campos.get(RESULT).setValor(valor);
	}

	public ValorCampo getFAC_POSITIVOS() {
		return campos.get(FAC_POSITIVOS).getValor();
	}

	public void setFAC_POSITIVOS(ValorCampo valor) {
		campos.get(FAC_POSITIVOS).setValor(valor);
	}

	public ValorCampo getC1() {
		return campos.get(C1).getValor();
	}

	public void setC1(ValorCampo valor) {
		campos.get(C1).setValor(valor);
	}

	public ValorCampo getC3() {
		return campos.get(C3).getValor();
	}

	public void setC3(ValorCampo valor) {
		campos.get(C3).setValor(valor);
	}

	public ValorCampo getC7() {
		return campos.get(C7).getValor();
	}

	public void setC7(ValorCampo valor) {
		campos.get(C7).setValor(valor);
	}

	public ValorCampo getC8() {
		return campos.get(C8).getValor();
	}

	public void setC8(ValorCampo valor) {
		campos.get(C8).setValor(valor);
	}

	public ValorCampo getC11() {
		return campos.get(C11).getValor();
	}

	public void setC11(ValorCampo valor) {
		campos.get(C11).setValor(valor);
	}

	public ValorCampo getC15() {
		return campos.get(C15).getValor();
	}

	public void setC15(ValorCampo valor) {
		campos.get(C15).setValor(valor);
	}

	public ValorCampo getC17() {
		return campos.get(C17).getValor();
	}

	public void setC17(ValorCampo valor) {
		campos.get(C17).setValor(valor);
	}

	public ValorCampo getC19() {
		return campos.get(C19).getValor();
	}

	public void setC19(ValorCampo valor) {
		campos.get(C19).setValor(valor);
	}

	public ValorCampo getFAC_NEGATIVOS() {
		return campos.get(FAC_NEGATIVOS).getValor();
	}

	public void setFAC_NEGATIVOS(ValorCampo valor) {
		campos.get(FAC_NEGATIVOS).setValor(valor);
	}

	public ValorCampo getC2() {
		return campos.get(C2).getValor();
	}

	public void setC2(ValorCampo valor) {
		campos.get(C2).setValor(valor);
	}

	public ValorCampo getC4() {
		return campos.get(C4).getValor();
	}

	public void setC4(ValorCampo valor) {
		campos.get(C4).setValor(valor);
	}

	public ValorCampo getC5() {
		return campos.get(C5).getValor();
	}

	public void setC5(ValorCampo valor) {
		campos.get(C5).setValor(valor);
	}

	public ValorCampo getC6() {
		return campos.get(C6).getValor();
	}

	public void setC6(ValorCampo valor) {
		campos.get(C6).setValor(valor);
	}

	public ValorCampo getC9() {
		return campos.get(C9).getValor();
	}

	public void setC9(ValorCampo valor) {
		campos.get(C9).setValor(valor);
	}

	public ValorCampo getC10() {
		return campos.get(C10).getValor();
	}

	public void setC10(ValorCampo valor) {
		campos.get(C10).setValor(valor);
	}

	public ValorCampo getC13() {
		return campos.get(C13).getValor();
	}

	public void setC13(ValorCampo valor) {
		campos.get(C13).setValor(valor);
	}

	public ValorCampo getC14() {
		return campos.get(C14).getValor();
	}

	public void setC14(ValorCampo valor) {
		campos.get(C14).setValor(valor);
	}

	public ValorCampo getC16() {
		return campos.get(C16).getValor();
	}

	public void setC16(ValorCampo valor) {
		campos.get(C16).setValor(valor);
	}

	public ValorCampo getC18() {
		return campos.get(C18).getValor();
	}

	public void setC18(ValorCampo valor) {
		campos.get(C18).setValor(valor);
	}

	public ValorCampo getC20() {
		return campos.get(C20).getValor();
	}

	public void setC20(ValorCampo valor) {
		campos.get(C20).setValor(valor);
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("MensajeCredito INICIO\n");

		builder.append("     ").append(campos.get(RESULT)).append("\n");
		builder.append("     ").append(campos.get(FAC_POSITIVOS)).append("\n");
		builder.append("     ").append(campos.get(C1)).append("\n");
		builder.append("     ").append(campos.get(C3)).append("\n");
		builder.append("     ").append(campos.get(C7)).append("\n");
		builder.append("     ").append(campos.get(C8)).append("\n");
		builder.append("     ").append(campos.get(C11)).append("\n");
		builder.append("     ").append(campos.get(C15)).append("\n");
		builder.append("     ").append(campos.get(C17)).append("\n");
		builder.append("     ").append(campos.get(C19)).append("\n");
		builder.append("     ").append(campos.get(FAC_NEGATIVOS)).append("\n");
		builder.append("     ").append(campos.get(C2)).append("\n");
		builder.append("     ").append(campos.get(C4)).append("\n");
		builder.append("     ").append(campos.get(C5)).append("\n");
		builder.append("     ").append(campos.get(C6)).append("\n");
		builder.append("     ").append(campos.get(C9)).append("\n");
		builder.append("     ").append(campos.get(C10)).append("\n");
		builder.append("     ").append(campos.get(C13)).append("\n");
		builder.append("     ").append(campos.get(C14)).append("\n");
		builder.append("     ").append(campos.get(C16)).append("\n");
		builder.append("     ").append(campos.get(C18)).append("\n");
		builder.append("     ").append(campos.get(C20)).append("\n");
		builder.append("MensajeCredito FIN\n");

		return builder.toString();
	}

	public String toStringUnaLinea() {
		StringBuilder builder = new StringBuilder();
		builder.append("MensajeCredito [");

		builder.append(CommonUtils.printFixedSize(campos.get(RESULT), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(FAC_POSITIVOS), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(C1), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(C3), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(C7), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(C8), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(C11), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(C15), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(C17), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(C19), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(FAC_NEGATIVOS), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(C2), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(C4), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(C5), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(C6), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(C9), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(C10), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(C13), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(C14), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(C16), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(C18), 6)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(C20), 6)).append(" ");
		builder.append("]");
		
		return builder.toString();
	}
	
//	public ValorCampo getC12() {
//		return campos.get(C12).getValor();
//	}

	public void setC12(ValorCampo valor) {
		campos.get(C12).setValor(valor);
	}
}