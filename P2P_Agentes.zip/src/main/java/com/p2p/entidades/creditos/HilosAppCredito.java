package com.p2p.entidades.creditos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.p2p.logica.LogService;

public class HilosAppCredito {

	private static Map<AgenteCredito, List<Thread>> map = new HashMap<>();

	public static List<Thread> get(AgenteCredito key) {
		List<Thread> hilos = map.get(key);

		if (hilos == null) {
			hilos = new ArrayList<>();
		}
		return hilos;
	}

	public static List<Thread> put(AgenteCredito key, List<Thread> hilos) {
		return map.put(key, hilos);
	}

	public static void putThread(AgenteCredito key, Thread hilo) {
		List<Thread> hilos = get(key);

		if (hilos == null) {
			hilos = new ArrayList<>();
		}
		hilos.add(hilo);

		map.put(key, hilos);
	}

	public static List<Thread> remove(AgenteCredito hilo) {
		return map.remove(hilo);
	}

	@SuppressWarnings("deprecation")
	public static void stopAllThreads(AgenteCredito agenteAlAzar) {
		try {
			List<Thread> hilos = get(agenteAlAzar);
			for (Thread hilo : hilos) {
				// LogService.getInstance().writeln("//////////////// Parando hilo " + hilo.getName() + " ////////////////");
				hilo.stop();
			}
		} catch (Exception e) {
			LogService.getInstance().errorln("Error al hacer stop en los hilos del agente " + agenteAlAzar.getNombre());
		}
	}
}