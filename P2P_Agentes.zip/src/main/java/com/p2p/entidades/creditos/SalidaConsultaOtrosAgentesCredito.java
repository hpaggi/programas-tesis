package com.p2p.entidades.creditos;

import com.p2p.entidades.AbstractSalidaConsultaOtrosAgentes;

public class SalidaConsultaOtrosAgentesCredito extends AbstractSalidaConsultaOtrosAgentes<MensajeCredito> {

}