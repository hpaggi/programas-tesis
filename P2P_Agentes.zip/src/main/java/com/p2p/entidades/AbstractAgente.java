package com.p2p.entidades;

import static com.p2p.util.CommonUtils.sumStr;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.p2p.enums.ITipoCampo;
import com.p2p.enums.Modo;
import com.p2p.enums.TipoLog;
import com.p2p.logica.LogService;
import com.p2p.logica.MensajesService;
import com.p2p.util.CommonUtils;
import com.p2p.util.Constantes;

public abstract class AbstractAgente<TIPO_AGENTE extends AbstractAgente<?, ?, ?, ?, ?>, TIPO_MENSAJE extends AbstractMensaje, TIPO_CAMPO extends ITipoCampo, TIPO_FAVORITOS, TIPO_SALIDA extends AbstractSalidaConsultaOtrosAgentes<TIPO_MENSAJE>>
		implements Comparable<AbstractAgente<TIPO_AGENTE, TIPO_MENSAJE, TIPO_CAMPO, TIPO_FAVORITOS, TIPO_SALIDA>> {

	protected String nombre;
	protected boolean soyRaiz;
	// protected Double calidadRaiz;
	protected int cantMensajesInicial;
	protected int cantMensajes;
	protected int cantMaxFavoritos;
	protected Map<TIPO_CAMPO, Double> porcentajeError;
	protected int timeoutEsperaRespuesta;
	protected int demoraPropiaEnResponder;
	protected int peso;
	protected Modo modo;
	protected SalidaConsulta salidaConsulta;

	// private Set<AbstractAgente> agentesConsultados;
	protected Map<TIPO_CAMPO, TIPO_FAVORITOS> mapAgentesFavoritos;
	protected List<String> logList;

	public AbstractAgente(String nombre, boolean soyRaiz, int cantMensajes, int cantMaxFavoritos, int timeoutEsperaRespuesta, int peso,
			Modo modo) {
		super();
		this.nombre = nombre;
		this.soyRaiz = soyRaiz;
		// this.calidadRaiz = calidadRaiz;
		this.cantMensajes = cantMensajes;
		this.cantMaxFavoritos = cantMaxFavoritos;
		this.cantMensajesInicial = cantMensajes;
		this.porcentajeError = generarPorcentajeError();
		this.timeoutEsperaRespuesta = timeoutEsperaRespuesta;
		this.peso = peso;
		this.modo = modo;
		this.demoraPropiaEnResponder = CommonUtils.integerBetween(0, 5);
		this.mapAgentesFavoritos = new HashMap<TIPO_CAMPO, TIPO_FAVORITOS>();
		// this.agentesConsultados = new HashSet<AgenteSitioWeb>();
		this.logList = new ArrayList<String>();
	}

	protected abstract Map<TIPO_CAMPO, Double> generarPorcentajeError();

	protected Double getPorcentajeAleatorio() {
		Double d = CommonUtils.roundDouble(CommonUtils.doubleBetween(0.1, Constantes.MAX_PORCENTAJE_ERROR) / 100);

		if (d.compareTo(0d) == 0) {
			d = getPorcentajeAleatorio();
		}
		return d;
	}

	/**
	 * Inicializa los agentes favoritos por campo calculado, con todos los agentes disponibles.
	 */
	public abstract void inicializarListaFavoritos();

	protected void demorarEnResponder() {
		try {
			Thread.sleep(demoraPropiaEnResponder * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public final void consultar(TIPO_AGENTE agenteLlamador, double calidadLlamador, TIPO_MENSAJE mensaje, TIPO_CAMPO campoConsultado,
			int nivelDelLlamador) {
		// public void consultar(AgenteSitioWeb agenteLlamador, double calidadLlamador, MensajeSitioWeb mensaje, CampoSitioWeb
		// campoConsultado,
		// int nivelDelLlamador) {
		// Pongo en null la salida, por si tenía un valor anterior seteado.
		setSalidaConsulta(null);
		int miNivel = nivelDelLlamador + 1;
		log(TipoLog.RECIBO_CONSULTA, agenteLlamador, null, miNivel, mensaje, campoConsultado, null, calidadLlamador);

		demorarEnResponder();

		SalidaConsulta salida = new SalidaConsulta();

		double miCalidad = (1 / (1 + porcentajeError.get(campoConsultado))) * (Math.pow(1d / miNivel, peso));
		miCalidad = CommonUtils.roundDouble(miCalidad, 5);

		if (soyRaiz) {
			miCalidad = CommonUtils.roundDouble(miCalidad, 2);
		}

		// Primero veo si el campoConsultado es calculado.
		if (campoConsultado.isCalculado()) {
			// Algoritmo para ver si calculo yo mismo o consulto a otro agente.
			boolean consultoAOtros = consultarAOtros(porcentajeError.get(campoConsultado), miNivel);

			salida.setCalidad(miCalidad);

			// Primero ver si tengo mensajes para responder. Si no tengo ya no hago nada.
			if (tengoMensajesParaResponder()) {
				log(TipoLog.TENGO_MENSAJES_PARA_RESPONDER, agenteLlamador, null, miNivel, mensaje, campoConsultado, miCalidad,
						calidadLlamador);

				if (consultoAOtros) {
					log(TipoLog.CONSULTO_A_OTRO_SI, agenteLlamador, null, miNivel, mensaje, campoConsultado, miCalidad, calidadLlamador);

					// Acá puede ser que consuma mensajes al consultar a otros.
					TIPO_SALIDA salidaConsultaOtrosAgentes = consultarAOtrosAgentes(mensaje, campoConsultado, miCalidad, agenteLlamador,
							miNivel, calidadLlamador);

					// Luego de consultar a otros agentes, calcular calidad de otra forma.
					miCalidad = calcularCalidadSegunRespuestaAgentes(miCalidad, salidaConsultaOtrosAgentes, miNivel);
					// TODO: Qué hacer con esta calidad si no consulté a otros. Queda en 0? Queda en null? Queda la anterior?
					salida.setCalidad(miCalidad);

					// generar un nro X al azar entre 0 y Nro.max.mensajes.por.agente (la cantidad que se les da al inicio)
					// si X> (1 - calidad calculada propia )/porcentaje de mensajes restantes
					// ------ si tiene mensajes
					// ----------- responder
					// ------ fin si
					// fin si

					double X = CommonUtils.doubleBetween(0, 1);
					double porcentajeMensajesRestantes = cantMensajes / cantMensajesInicial;
					boolean responder = X < (miCalidad / (porcentajeMensajesRestantes + 1));

					// Si yo tengo mejor calidad que el que me consulta o modo=SIMPLE, puedo responder.
					if (miCalidad > calidadLlamador || responder || estoyEnModoSimple()) {
						log("miCalidad: " + miCalidad + " calidadLlamador: " + calidadLlamador + " responder: " + responder
								+ " estoyEnModoSimple: " + estoyEnModoSimple());
						log(TipoLog.TENGO_MEJOR_CALIDAD, agenteLlamador, null, miNivel, mensaje, campoConsultado, miCalidad,
								calidadLlamador);

						// Entonces antes de responder, tengo que ver nuevamente si me quedan mensajes.
						if (tengoMensajesParaResponder()) {
							log(TipoLog.TENGO_MENSAJES_PARA_RESPONDER, agenteLlamador, null, miNivel, mensaje, campoConsultado, miCalidad,
									calidadLlamador);

							TIPO_MENSAJE mensajeActualizadoPorAgentes = salidaConsultaOtrosAgentes.getMensaje();
							ValorCampo valorCampoCalculado = calcularValorCampo(mensajeActualizadoPorAgentes, campoConsultado, miNivel);

							mensaje.getCampo(campoConsultado).setValor(valorCampoCalculado);
							salida.setValor(valorCampoCalculado);
							setSalidaConsulta(salida);
							consumirMensaje(mensaje);

							log(TipoLog.MENSAJE_A_DEVOLVER, agenteLlamador, null, miNivel, mensaje, campoConsultado, miCalidad,
									calidadLlamador);
						} else {
							log(TipoLog.NO_TENGO_MENSAJES_PARA_RESPONDER, agenteLlamador, null, miNivel, mensaje, campoConsultado,
									miCalidad, calidadLlamador);
							setSalidaConsulta(null);
						}
					} else {
						log(TipoLog.TENGO_PEOR_CALIDAD, agenteLlamador, null, miNivel, mensaje, campoConsultado, miCalidad,
								calidadLlamador);
						setSalidaConsulta(null);
					}
				} else {// consultoAOtros no.
					log(TipoLog.CONSULTO_A_OTRO_NO, agenteLlamador, null, miNivel, mensaje, campoConsultado, miCalidad, calidadLlamador);

					// generar un nro X al azar entre 0 y Nro.max.mensajes.por.agente (la cantidad que se les da al inicio)
					// si X> (1 - calidad calculada propia )/porcentaje de mensajes restantes
					// ------ si tiene mensajes
					// ----------- responder
					// ------ fin si
					// fin si

					double X = CommonUtils.doubleBetween(0, 1);
					double porcentajeMensajesRestantes = cantMensajes / cantMensajesInicial;
					boolean responder = X < (miCalidad / (porcentajeMensajesRestantes + 1));

					// Si yo tengo mejor calidad que el que me consulta o modo=SIMPLE, puedo responder.
					if (miCalidad > calidadLlamador || responder || estoyEnModoSimple()) {
						log("miCalidad: " + miCalidad + " calidadLlamador: " + calidadLlamador + " responder: " + responder
								+ " estoyEnModoSimple: " + estoyEnModoSimple());
						log(TipoLog.TENGO_MEJOR_CALIDAD, agenteLlamador, null, miNivel, mensaje, campoConsultado, miCalidad,
								calidadLlamador);

						// Entonces antes de responder, tengo que ver nuevamente si me quedan mensajes.
						if (tengoMensajesParaResponder()) {
							log(TipoLog.TENGO_MENSAJES_PARA_RESPONDER, agenteLlamador, null, miNivel, mensaje, campoConsultado, miCalidad,
									calidadLlamador);
							ValorCampo valorCampoCalculado = calcularValorCampo(mensaje, campoConsultado, miNivel);
							mensaje.getCampo(campoConsultado).setValor(valorCampoCalculado);

							salida.setValor(valorCampoCalculado);
							setSalidaConsulta(salida);
							consumirMensaje(mensaje);

							log(TipoLog.MENSAJE_A_DEVOLVER, agenteLlamador, null, miNivel, mensaje, campoConsultado, miCalidad,
									calidadLlamador);
						} else {
							log(TipoLog.NO_TENGO_MENSAJES_PARA_RESPONDER, agenteLlamador, null, miNivel, mensaje, campoConsultado,
									miCalidad, calidadLlamador);
							setSalidaConsulta(null);
						}
					} else {
						log(TipoLog.TENGO_PEOR_CALIDAD, agenteLlamador, null, miNivel, mensaje, campoConsultado, miCalidad,
								calidadLlamador);
						setSalidaConsulta(null);
					}
				}
			} else {
				log(TipoLog.NO_TENGO_MENSAJES_PARA_RESPONDER, agenteLlamador, null, miNivel, mensaje, campoConsultado, miCalidad,
						calidadLlamador);
				setSalidaConsulta(null);
			}
		} else {// El campoConsultado no es calculado.
			// Entonces antes de responder, tengo que ver nuevamente si me quedan mensajes.
			if (tengoMensajesParaResponder()) {
				log(TipoLog.TENGO_MENSAJES_PARA_RESPONDER, agenteLlamador, null, miNivel, mensaje, campoConsultado, miCalidad,
						calidadLlamador);

				// Retorno el valor del mismo campo consultado porque no es calculado.
				salida.setValor(mensaje.getCampo(campoConsultado).getValor());
				setSalidaConsulta(salida);
				consumirMensaje(mensaje);

				log(TipoLog.MENSAJE_A_DEVOLVER, agenteLlamador, null, miNivel, mensaje, campoConsultado, miCalidad, calidadLlamador);
			} else {
				log(TipoLog.NO_TENGO_MENSAJES_PARA_RESPONDER, agenteLlamador, null, miNivel, mensaje, campoConsultado, miCalidad,
						calidadLlamador);
				setSalidaConsulta(null);
			}
		}
	}

	/**
	 * Retorna true si el modo elegido es SIMPLE.
	 */
	protected final boolean estoyEnModoSimple() {
		return Modo.SIMPLE.equals(modo);
	}

	/**
	 * Algoritmo para determinar si consulta a otros por un campo o no.
	 */
	protected final boolean consultarAOtros(Double erroDeCampo, int miNivel) {
		// Si soy la raíz y es la primer consulta (nivel=1), debo consultar a otros.
		if (soyRaiz && miNivel == 1) {
			return true;
		} else {
			// generar nro aleatorio entre 0 y 1
			int num = CommonUtils.integerBetween(0, 1);

			// si nro > error del campo
			if (num > erroDeCampo) {
				// ----- consultar
				return true;
			} else {
				return false;
			}
		}
	}

	/**
	 * Calculo mi calidad, en base a las calidades de los agentes consultados, la cantidad de estos, y algunos otros parámetros.
	 */
	protected final double calcularCalidadSegunRespuestaAgentes(double miCalidad, TIPO_SALIDA salida, int miNivel) {
		if (salida.getCantAgentesQueRespondieron() == 0) {
			return miCalidad;
		}

		Double calidadMax = salida.getCalidadMaxima();
		Double calidadMin = salida.getCalidadMinima();

		if (calidadMax == null || calidadMin == null) {
			return 0;
		}

		Double deltaCalidades = calidadMax - calidadMin;
		double calidad = (calidadMax / Math.pow(miNivel, peso)) * (1 / (1 + deltaCalidades));

		double Q = calidad;
		double q = miCalidad;

		double max = Double.max(q, Q);
		double exp = (peso + 1) * salida.getCantAgentesConsultados() / salida.getCantAgentesQueRespondieron();

		double calidadFinal = Math.pow(max, exp);

		return CommonUtils.roundDouble(calidadFinal, 5);
	}

	protected abstract TIPO_SALIDA consultarAOtrosAgentes(TIPO_MENSAJE mensaje, TIPO_CAMPO campoConsultado, double miCalidad,
			TIPO_AGENTE agenteLlamador, int miNivel, double calidadLlamador);

	/**
	 * Obtiene el mejor valor de la lista de valores.
	 * Puede ser un promedio, o el valor mas alto.
	 */
	protected abstract ValorCampo obtenerMejorValorCampo(TIPO_CAMPO campo, List<ValorCampo> listaValores);

	protected abstract List<TIPO_CAMPO> getListaSubcamposCalculadosAlAzar(TIPO_CAMPO campoConsultado);

	protected abstract ValorCampo calcularValorCampo(TIPO_MENSAJE mensaje, TIPO_CAMPO campoConsultado, int miNivel);

	protected double aplicarMiPorcentajeDeError(TIPO_CAMPO campo, double valor) {
		double val = valor + (valor * porcentajeError.get(campo) / 100);

		return CommonUtils.roundDouble(val, 5);
	}

	protected final TIPO_AGENTE dameAgenteAlAzar(List<TIPO_AGENTE> lista, Set<Integer> indicesUsados) {
		int size = lista.size();
		Integer indice = CommonUtils.integerBetween(0, size - 1);

		while (indicesUsados.contains(indice) && size != indicesUsados.size()) {
			indice = CommonUtils.integerBetween(0, size - 1);
		}

		if (size != indicesUsados.size()) {
			indicesUsados.add(indice);
			return lista.get(indice);
		} else {
			return null;
		}
	}

	protected final boolean tengoMensajesParaConsultar() {
		return cantMensajes != 0;
	}

	protected final boolean tengoMensajesParaResponder() {
		return cantMensajes != 0;
	}

	/**
	 * Resta 1 a la cantidad de mensajes restantes del agente.
	 * Además suma 1 a la cantidad de mensajes consumidos por un registro.
	 */
	protected final void consumirMensaje(TIPO_MENSAJE mensaje) {
		MensajesService.getInstance().add(mensaje.getIndiceMsg());
		cantMensajes--;
	}

	public final synchronized void log(String texto) {
		logList.add(texto);
		LogService.getInstance().writeln(texto);
	}

	public final synchronized void log(TipoLog tipo, TIPO_AGENTE agenteLlamador, TIPO_AGENTE agenteAlAzar, int miNivel,
			TIPO_MENSAJE mensaje, TIPO_CAMPO campoConsultado, Double miCalidad, double calidadLlamador) {
		String msg = "";
		String agenteLlamadorStr = agenteLlamador != null ? agenteLlamador.getNombre() : "SERVICIO";
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy - hh:mm:ss.SSS");
		String fecha = sdf.format(new Date()) + " || ";

		String indiceMsg = "Msg. nro: " + mensaje.getIndiceMsg() + " || ";
		String miCal = ". Mi calidad: " + miCalidad;
		String calLlam = ". Calidad llamador: " + calidadLlamador;
		String cantMsg = ". Me quedan " + cantMensajes + " mensajes.";
		switch (tipo) {
		case RECIBO_CONSULTA:
			msg = sumStr(fecha, indiceMsg, "Yo ", this.getNombre(), " recibo consulta por el campo ", campoConsultado, ". Mi nivel: ",
					miNivel, calLlam, cantMsg);
			break;
		case RESPONDO_CONSULTA:
			msg = sumStr(fecha, indiceMsg, "Yo ", this.getNombre(), " respondo consulta por el campo ", campoConsultado, ". Mi nivel: ",
					miNivel, miCal, calLlam, cantMsg);
			break;
		case CONSULTO_A_OTRO_SI:
			msg = sumStr(fecha, indiceMsg, "Yo ", this.getNombre(), " decidí consultar a otros. Mi nivel: ", miNivel, miCal, calLlam,
					cantMsg);
			break;
		case CONSULTO_A_OTRO_NO:
			msg = sumStr(fecha, indiceMsg, "Yo ", this.getNombre(), " decidí no consultar a otros. Mi nivel: ", miNivel, miCal, calLlam,
					cantMsg);
			break;
		case CONSULTO_A_OTRO:
			msg = sumStr(fecha, indiceMsg, "Yo ", this.getNombre(), " voy a consultar al ", agenteAlAzar.getNombre(), " por el campo ",
					campoConsultado, ". Agente llamador: ", agenteLlamadorStr, ". Mi nivel: ", miNivel, miCal, calLlam, cantMsg);
			break;
		case TENGO_MEJOR_CALIDAD:
			msg = sumStr(fecha, indiceMsg, "Yo ", this.getNombre(), " tengo mejor calidad que ", agenteLlamadorStr, ". Mi nivel: ", miNivel,
					miCal, calLlam, cantMsg);
			break;
		case TENGO_PEOR_CALIDAD:
			msg = sumStr(fecha, indiceMsg, "Yo ", this.getNombre(), " tengo peor calidad que ", agenteLlamadorStr, ". Mi nivel: ", miNivel,
					miCal, calLlam, cantMsg);
			break;
		case TENGO_MENSAJES_PARA_RESPONDER:
			msg = sumStr(fecha, indiceMsg, "Yo ", this.getNombre(), " tengo mensajes para responder", ". Mi nivel: ", miNivel, miCal,
					calLlam, cantMsg);
			break;
		case NO_TENGO_MENSAJES_PARA_RESPONDER:
			msg = sumStr(fecha, indiceMsg, "Yo ", this.getNombre(), " no tengo mensajes para responder", ". Mi nivel: ", miNivel, miCal,
					calLlam, cantMsg);
			break;
		case MENSAJE_A_DEVOLVER:
			msg = sumStr(fecha, indiceMsg, "Yo ", this.getNombre(), miCal, cantMsg, " Devuelvo el mensaje= ", mensaje.toStringUnaLinea());
			break;
		case TENGO_MENSAJES_PARA_CONSULTAR:
			msg = sumStr(fecha, indiceMsg, "Yo ", this.getNombre(), " tengo mensajes para consultar", ". Mi nivel: ", miNivel, miCal,
					calLlam, cantMsg);
			break;
		case NO_TENGO_MENSAJES_PARA_CONSULTAR:
			msg = sumStr(fecha, indiceMsg, "Yo ", this.getNombre(), " NO tengo mensajes para consultar. Agente llamador: ",
					agenteLlamadorStr, ". Mi nivel: ", miNivel, miCal, calLlam, cantMsg);
			break;
		case NO_ME_RESPONDIO:
			msg = sumStr(fecha, indiceMsg, "Yo ", this.getNombre(), " consulté al ", agenteAlAzar.getNombre(), " por el campo ",
					campoConsultado, " y NO me respondió (no tiene msj, peor calidad que yo, timeout). Mi nivel: ", miNivel, miCal, calLlam,
					cantMsg);
			break;
		case ME_RESPONDIO:
			msg = sumStr(fecha, indiceMsg, "Yo ", this.getNombre(), " consulté al ", agenteAlAzar.getNombre(), " por el campo ",
					campoConsultado, " y me respondió a tiempo. Mi nivel: ", miNivel, miCal, calLlam, cantMsg);
			break;
		case VALOR_CAMPO_NULL_NO_ME_RESPONDIERON:
			// Hay veces que el valor llega en null porque nadie le respondió para ese campo.
			msg = sumStr(fecha, indiceMsg, "Yo ", this.getNombre(), " consulté a otros por el campo ", campoConsultado,
					" pero nadie me respondió. Me quedo con el valor del campo que tenía. Mi nivel: ", miNivel, miCal, calLlam, cantMsg);
			break;
		case VALOR_CAMPO_NULL_SIN_MENSAJES:
			// Hay veces que el valor llega en null porque yo no tenía mensajes para consultar a otros.
			msg = sumStr(fecha, indiceMsg, "Yo ", this.getNombre(), " no pude consultar a otros por el campo ", campoConsultado,
					" porque me quedé sin mensajes. Me quedo con el valor del campo que tenía. Mi nivel: ", miNivel, miCal, calLlam,
					cantMsg);
			break;
		case ACTUALIZO_FAVORITOS:
			msg = sumStr(fecha, indiceMsg, "Yo ", this.getNombre(), " actualizo mi lista de favoritos. Sumo un punto para el ",
					agenteAlAzar.getNombre(), " para el campo ", campoConsultado, ". Mi nivel: ", miNivel, miCal, calLlam, cantMsg);
			break;
		default:
			break;
		}

		logList.add(msg);
		LogService.getInstance().writeln(msg);
	}

	public String getNombre() {
		return nombre;
	}

	// public Map<TIPO_CAMPO, Double> getPorcentajeError() {
	// return porcentajeError;
	// }
	//
	// public double getPorcentajeError(TIPO_CAMPO campo) {
	// return porcentajeError.get(campo);
	// }

	public SalidaConsulta getSalidaConsulta() {
		return salidaConsulta;
	}

	public void setSalidaConsulta(SalidaConsulta salidaConsulta) {
		this.salidaConsulta = salidaConsulta;
	}

	public synchronized List<String> getLog() {
		return logList;
	}

	@Override
	public final String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Agente [nombre=").append(nombre).append(", cantMensajes=").append(cantMensajes).append(", porcentajeError=")
				.append(porcentajeError).append("%, timeoutEsperaRespuesta=").append(timeoutEsperaRespuesta)
				.append("segs, demoraPropiaEnResponder=").append(demoraPropiaEnResponder).append("segs]");
		return builder.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		return result;
	}

	@Override
	public final boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		@SuppressWarnings("unchecked")
		TIPO_AGENTE other = (TIPO_AGENTE) obj;
		if (nombre == null) {
			if (other.nombre != null) {
				return false;
			}
		} else if (!nombre.equals(other.nombre)) {
			return false;
		}
		return true;
	}

	@Override
	public int compareTo(AbstractAgente<TIPO_AGENTE, TIPO_MENSAJE, TIPO_CAMPO, TIPO_FAVORITOS, TIPO_SALIDA> other) {
		return this.nombre.compareTo(other.getNombre());
	}
}