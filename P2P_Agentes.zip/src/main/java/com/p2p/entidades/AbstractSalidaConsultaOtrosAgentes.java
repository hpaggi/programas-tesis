package com.p2p.entidades;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;

public class AbstractSalidaConsultaOtrosAgentes<TIPO_MENSAJE extends AbstractMensaje> {

	private TIPO_MENSAJE mensaje;
	private int cantAgentesQueRespondieron;
	private int cantAgentesConsultados;
	private List<Double> calidades;

	/**
	 * Devuelve la calidad máxima de todas las calidades obtenidas, o null si no tiene ninguna.
	 */
	public Double getCalidadMaxima() {
		Double calidaMaxima = Double.MIN_VALUE;

		if (CollectionUtils.isNotEmpty(calidades)) {
			for (Double calidad : calidades) {
				calidaMaxima = Double.max(calidaMaxima, calidad);
			}
		} else {
			calidaMaxima = null;
		}
		return calidaMaxima;
	}

	/**
	 * Devuelve la calidad mínima de todas las calidades obtenidas, o null si no tiene ninguna.
	 */
	public Double getCalidadMinima() {
		Double calidaMinima = Double.MAX_VALUE;

		if (CollectionUtils.isNotEmpty(calidades)) {
			for (Double calidad : calidades) {
				calidaMinima = Double.min(calidaMinima, calidad);
			}
		} else {
			calidaMinima = null;
		}
		return calidaMinima;
	}

	/**
	 * Agrega un valor de calidad a la lista, e incrementa el contador de agentes.
	 */
	public void agregarCalidad(Double calidad) {
		if (calidad != null) {
			getCalidades().add(calidad);
			cantAgentesQueRespondieron++;
		}
	}

	public TIPO_MENSAJE getMensaje() {
		return mensaje;
	}

	public void setMensaje(TIPO_MENSAJE mensaje) {
		this.mensaje = mensaje;
	}

	public int getCantAgentesQueRespondieron() {
		return cantAgentesQueRespondieron;
	}

	public void setCantAgentesQueRespondieron(int cantAgentesQueRespondieron) {
		this.cantAgentesQueRespondieron = cantAgentesQueRespondieron;
	}

	public int getCantAgentesConsultados() {
		return cantAgentesConsultados;
	}

	public void setCantAgentesConsultados(int cantAgentesConsultados) {
		this.cantAgentesConsultados = cantAgentesConsultados;
	}

	public List<Double> getCalidades() {
		if (CollectionUtils.isEmpty(calidades)) {
			calidades = new ArrayList<>();
		}
		return calidades;
	}

	public void setCalidades(List<Double> calidades) {
		this.calidades = calidades;
	}
}