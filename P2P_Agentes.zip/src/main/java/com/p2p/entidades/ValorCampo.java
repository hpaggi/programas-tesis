package com.p2p.entidades;

public class ValorCampo {

	private Object valor;

	public ValorCampo(Object valor) {
		this.valor = valor;
	}

	public Object get() {
		return valor;
	}

	public void set(Object valor) {
		this.valor = valor;
	}

	@Override
	public String toString() {
		return String.valueOf(valor);
	}
}