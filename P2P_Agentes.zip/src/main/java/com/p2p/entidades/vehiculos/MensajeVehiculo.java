package com.p2p.entidades.vehiculos;

import static com.p2p.enums.vehiculos.CampoVehiculo.CAR;
import static com.p2p.enums.vehiculos.CampoVehiculo.CONFORT;
import static com.p2p.enums.vehiculos.CampoVehiculo.NUMERO_ASIENTOS;
import static com.p2p.enums.vehiculos.CampoVehiculo.NUMERO_PUERTAS;
import static com.p2p.enums.vehiculos.CampoVehiculo.PRECIO;
import static com.p2p.enums.vehiculos.CampoVehiculo.PRECIO_COMPRA;
import static com.p2p.enums.vehiculos.CampoVehiculo.PRECIO_MANT;
import static com.p2p.enums.vehiculos.CampoVehiculo.SEGURIDAD;
import static com.p2p.enums.vehiculos.CampoVehiculo.TAMANIO_BAUL;
import static com.p2p.enums.vehiculos.CampoVehiculo.TECH;

import java.util.HashMap;
import java.util.Map;

import com.p2p.entidades.Campo;
import com.p2p.entidades.AbstractMensaje;
import com.p2p.entidades.ValorCampo;
import com.p2p.enums.ITipoCampo;
import com.p2p.enums.vehiculos.CampoVehiculo;
import com.p2p.util.CommonUtils;

/**
 * Representa un mensaje a pasar entre agentes, representando un vehículo.<br>
 * <br>
 *
 * Ejemplo de forma de anidación:<br>
 * <br>
 * <b>
 * CAR = Aceptabilidad del auto<br>
 * . . PRICE = Precio en general<br>
 * . . . . . precio de compra<br>
 * . . . . . precio de mantenimiento<br>
 * . . TECH = caracteristicas técnicas<br>
 * . . . . . COMFORT = confort<br>
 * . . . . . . . . nro de puertas<br>
 * . . . . . . . . nro de asientos (cantidad de pasajeros)<br>
 * . . . . . . . . tamaño del baul<br>
 * . . . . . Seguridad del auto<br>
 * </b>
 *
 * <br>
 * Ejemplo de lectura de datos desde archivo externo:<br>
 * <br>
 * <b>
 * Precio compra;Precio manten;PRICE;Nro. puertas;Nro pasajeros;Baul;COMFORT;Seguridad;TECH;CAR CALCULADO<br>
 * 1 ;1 ;1 ;2 ;2 ;3 ;12 ;3 ;108 ;0<br>
 * </b>
 *
 * @author German
 */
public class MensajeVehiculo extends AbstractMensaje {

	private int indiceMsg;
	private Map<CampoVehiculo, Campo> campos;

	public MensajeVehiculo() {
		campos = new HashMap<CampoVehiculo, Campo>();

		campos.put(CAR, new Campo(CAR.name(), null, CAR.isCalculado()));
		campos.put(PRECIO, new Campo(PRECIO.name(), null, PRECIO.isCalculado()));
		campos.put(PRECIO_COMPRA, new Campo(PRECIO_COMPRA.name(), null, PRECIO_COMPRA.isCalculado()));
		campos.put(PRECIO_MANT, new Campo(PRECIO_MANT.name(), null, PRECIO_MANT.isCalculado()));
		campos.put(TECH, new Campo(TECH.name(), null, TECH.isCalculado()));
		campos.put(CONFORT, new Campo(CONFORT.name(), null, CONFORT.isCalculado()));
		campos.put(NUMERO_PUERTAS, new Campo(NUMERO_PUERTAS.name(), null, NUMERO_PUERTAS.isCalculado()));
		campos.put(NUMERO_ASIENTOS, new Campo(NUMERO_ASIENTOS.name(), null, NUMERO_ASIENTOS.isCalculado()));
		campos.put(TAMANIO_BAUL, new Campo(TAMANIO_BAUL.name(), null, TAMANIO_BAUL.isCalculado()));
		campos.put(SEGURIDAD, new Campo(SEGURIDAD.name(), null, SEGURIDAD.isCalculado()));
	}

	@Override
	public int getIndiceMsg() {
		return indiceMsg;
	}

	@Override
	public void setIndiceMsg(int indiceMsg) {
		this.indiceMsg = indiceMsg;
	}

	@Override
	public CampoVehiculo getCampoBase() {
		return CAR;
	}

	@Override
	public Campo getCampo(ITipoCampo campo) {
		return campos.get(campo);
	}

	public ValorCampo getCar() {
		return campos.get(CAR).getValor();
	}

	public void setCar(ValorCampo valor) {
		campos.get(CAR).setValor(valor);
	}

	public ValorCampo getPrecio() {
		return campos.get(PRECIO).getValor();
	}

	public void setPrecio(ValorCampo valor) {
		campos.get(PRECIO).setValor(valor);
	}

	public ValorCampo getPrecioCompra() {
		return campos.get(PRECIO_COMPRA).getValor();
	}

	public void setPrecioCompra(ValorCampo valor) {
		campos.get(PRECIO_COMPRA).setValor(valor);
	}

	public ValorCampo getPrecioMant() {
		return campos.get(PRECIO_MANT).getValor();
	}

	public void setPrecioMant(ValorCampo valor) {
		campos.get(PRECIO_MANT).setValor(valor);
	}

	public ValorCampo getTech() {
		return campos.get(TECH).getValor();
	}

	public void setTech(ValorCampo valor) {
		campos.get(TECH).setValor(valor);
	}

	public ValorCampo getConfort() {
		return campos.get(CONFORT).getValor();
	}

	public void setConfort(ValorCampo valor) {
		campos.get(CONFORT).setValor(valor);
	}

	public ValorCampo getNumeroPuertas() {
		return campos.get(NUMERO_PUERTAS).getValor();
	}

	public void setNumeroPuertas(ValorCampo valor) {
		campos.get(NUMERO_PUERTAS).setValor(valor);
	}

	public ValorCampo getNumeroAsientos() {
		return campos.get(NUMERO_ASIENTOS).getValor();
	}

	public void setNumeroAsientos(ValorCampo valor) {
		campos.get(NUMERO_ASIENTOS).setValor(valor);
	}

	public ValorCampo getTamanioBaul() {
		return campos.get(TAMANIO_BAUL).getValor();
	}

	public void setTamanioBaul(ValorCampo valor) {
		campos.get(TAMANIO_BAUL).setValor(valor);
	}

	public ValorCampo getSeguridad() {
		return campos.get(SEGURIDAD).getValor();
	}

	public void setSeguridad(ValorCampo valor) {
		campos.get(SEGURIDAD).setValor(valor);
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("MensajeVehiculo INICIO\n");

		builder.append("     ").append(campos.get(CAR)).append("\n");
		builder.append("     ").append(campos.get(PRECIO)).append("\n");
		builder.append("     ").append(campos.get(PRECIO_COMPRA)).append("\n");
		builder.append("     ").append(campos.get(PRECIO_MANT)).append("\n");
		builder.append("     ").append(campos.get(TECH)).append("\n");
		builder.append("     ").append(campos.get(CONFORT)).append("\n");
		builder.append("     ").append(campos.get(NUMERO_PUERTAS)).append("\n");
		builder.append("     ").append(campos.get(NUMERO_ASIENTOS)).append("\n");
		builder.append("     ").append(campos.get(TAMANIO_BAUL)).append("\n");
		builder.append("     ").append(campos.get(SEGURIDAD)).append("\n");
		builder.append("MensajeVehiculo FIN\n");

		return builder.toString();
	}

	@Override
	public String toStringUnaLinea() {
		StringBuilder builder = new StringBuilder();
		builder.append("MensajeVehiculo [");

		builder.append(CommonUtils.printFixedSize(campos.get(CAR), 14)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(PRECIO), 15)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(PRECIO_COMPRA), 24)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(PRECIO_MANT), 22)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(TECH), 14)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(CONFORT), 15)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(NUMERO_PUERTAS), 28)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(NUMERO_ASIENTOS), 31)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(TAMANIO_BAUL), 23)).append(" ");
		builder.append(CommonUtils.printFixedSize(campos.get(SEGURIDAD), 17)).append(" ");
		builder.append("]");

		return builder.toString();
	}
}