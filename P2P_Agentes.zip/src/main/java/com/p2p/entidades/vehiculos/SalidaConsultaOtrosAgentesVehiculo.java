package com.p2p.entidades.vehiculos;

import com.p2p.entidades.AbstractSalidaConsultaOtrosAgentes;

public class SalidaConsultaOtrosAgentesVehiculo extends AbstractSalidaConsultaOtrosAgentes<MensajeVehiculo> {

}