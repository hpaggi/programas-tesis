package com.p2p.entidades.vehiculos;

import static com.p2p.util.CommonUtils.SI_NO;
import static com.p2p.util.CommonUtils.getDouble;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;

import com.p2p.entidades.AbstractAgente;
import com.p2p.entidades.SalidaConsulta;
import com.p2p.entidades.ValorCampo;
import com.p2p.enums.Modo;
import com.p2p.enums.TipoLog;
import com.p2p.enums.vehiculos.CampoVehiculo;
import com.p2p.enums.vehiculos.NivelPrecio;
import com.p2p.enums.vehiculos.NivelSeguridad;
import com.p2p.enums.vehiculos.NumeroAsientos;
import com.p2p.enums.vehiculos.NumeroPuertas;
import com.p2p.enums.vehiculos.TamanioBaul;
import com.p2p.logica.LogService;
import com.p2p.logica.vehiculos.FuncionesCAR;
import com.p2p.logica.vehiculos.FuncionesCONFORT;
import com.p2p.logica.vehiculos.FuncionesPRECIO;
import com.p2p.logica.vehiculos.FuncionesTECH;
import com.p2p.logica.vehiculos.MapAgentesVehiculo;
import com.p2p.util.CommonUtils;

public class AgenteVehiculo extends
		AbstractAgente<AgenteVehiculo, MensajeVehiculo, CampoVehiculo, AgentesFavoritosVehiculo, SalidaConsultaOtrosAgentesVehiculo> {

	private Set<AgenteVehiculo> agentesConsultados;

	public AgenteVehiculo(String nombre, boolean soyRaiz, int cantMensajes, int cantMaxFavoritos, int timeoutEsperaRespuesta, int peso,
			Modo modo) {
		super(nombre, soyRaiz, cantMensajes, cantMaxFavoritos, timeoutEsperaRespuesta, peso, modo);
		this.agentesConsultados = new HashSet<AgenteVehiculo>();
	}

	@Override
	protected Map<CampoVehiculo, Double> generarPorcentajeError() {
		Map<CampoVehiculo, Double> map = new HashMap<>();

		for (CampoVehiculo campo : CampoVehiculo.values()) {
			map.put(campo, getPorcentajeAleatorio());
		}
		return map;
	}

	/**
	 * Inicializa los agentes favoritos por campo calculado, con todos los agentes disponibles.
	 */
	@Override
	public void inicializarListaFavoritos() {
		for (CampoVehiculo campoCalculado : CampoVehiculo.dameListaCamposCalculados()) {
			AgentesFavoritosVehiculo agentesFavoritos = new AgentesFavoritosVehiculo();
			agentesFavoritos.inicializar(MapAgentesVehiculo.values());

			mapAgentesFavoritos.put(campoCalculado, agentesFavoritos);
		}
	}

	@Override
	@SuppressWarnings("deprecation")
	protected SalidaConsultaOtrosAgentesVehiculo consultarAOtrosAgentes(MensajeVehiculo mensaje, CampoVehiculo campoConsultado,
			double miCalidad, AgenteVehiculo agenteLlamador, int miNivel, double calidadLlamador) {
		Instant now = Instant.now();

		AgenteVehiculo yo = this;
		SalidaConsultaOtrosAgentesVehiculo salidaOtrosAgentes = new SalidaConsultaOtrosAgentesVehiculo();
		List<CampoVehiculo> listaCamposAConsultar = null;

		// Si soy raiz debo consultar por CAR.
		if (soyRaiz) {
			log("Soy raiz, consulto por campo: " + campoConsultado);
			listaCamposAConsultar = new ArrayList<>();
			listaCamposAConsultar.add(campoConsultado);
		} else {
			// Si no soy raiz, puedo consultar el mismo campo o sus subcampos.
			boolean mismoCampo = SI_NO();
			log("Consulto mismo campo: " + mismoCampo);

			if (mismoCampo) {
				listaCamposAConsultar = new ArrayList<>();
				listaCamposAConsultar.add(campoConsultado);
			} else {
				// Elegir subcampos calculados al azar para consultar a otros agentes.
				listaCamposAConsultar = getListaSubcamposCalculadosAlAzar(campoConsultado);
			}
		}

		Map<CampoVehiculo, List<ValorCampo>> mapValores = new HashMap<>();
		boolean noMeRespondieron = false;
		boolean noTengoMensajesParaConsultar = false;

		log("Lista de campos a consultar: " + listaCamposAConsultar);

		// Por cada campo, le pregunto su valor a otros agentes.
		for (CampoVehiculo campoAConsultar : listaCamposAConsultar) {
			// Tomo mi lista de favoritos (Debe ser por campo)
			Set<AgenteVehiculo> agentesAConsultar = mapAgentesFavoritos.get(campoAConsultar).getAgentesTop(cantMaxFavoritos);

			List<AgenteVehiculo> lista = new ArrayList<AgenteVehiculo>(agentesAConsultar);
			Set<Integer> indicesUsados = new HashSet<Integer>();

			mapValores.put(campoAConsultar, new ArrayList<ValorCampo>());

			for (int i = 0; i < agentesAConsultar.size(); i++) {
				AgenteVehiculo agenteAlAzar = dameAgenteAlAzar(lista, indicesUsados);

				// No puedo consultar al agente que me llamó ni a mi mismo.
				if ((agenteLlamador != null && agenteAlAzar != null && agenteLlamador.equals(agenteAlAzar)) || agenteAlAzar.equals(this)) {
					continue;
				}

				// Si tengo mensajes disponibles, consulto a otros.
				if (tengoMensajesParaConsultar()) {
					log(TipoLog.TENGO_MENSAJES_PARA_CONSULTAR, agenteLlamador, agenteAlAzar, miNivel, mensaje, campoConsultado, miCalidad,
							calidadLlamador);
					agentesConsultados.add(agenteAlAzar);
					salidaOtrosAgentes.setCantAgentesConsultados(agentesConsultados.size());
					consumirMensaje(mensaje);

					SalidaConsulta salida = null;
					Thread hiloConsulta = new Thread(new Runnable() {
						@Override
						public void run() {
							// Pasar mi calidad (error), y el otro se debe fijar si tiene mejor calidad que yo.
							// Si no tiene mejor calidad, no responde.
							agenteAlAzar.consultar(yo, miCalidad, mensaje, campoAConsultar, miNivel);
						}
					});
					log(TipoLog.CONSULTO_A_OTRO, agenteLlamador, agenteAlAzar, miNivel, mensaje, campoAConsultar, miCalidad,
							calidadLlamador);
					hiloConsulta.setName("Hilo de " + agenteAlAzar.getNombre() + " Nivel: " + miNivel);
					hiloConsulta.start();
					HilosAppVehiculo.putThread(this, hiloConsulta);

					try {
						// Acá se debe esperar cierto tiempo por la consulta.
						// Si responde a tiempo, guardo lo que me devuelve y lo pongo como favorito.
						hiloConsulta.join(timeoutEsperaRespuesta * 1000);

						salida = agenteAlAzar.getSalidaConsulta();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}

					// Si el valor es null, es porque no me respondió por no tener mensajes, por tener peor calidad que yo,
					// o porque no me dió el tiempo para esperarlo (join).
					if (salida != null) {
						log(TipoLog.ME_RESPONDIO, agenteLlamador, agenteAlAzar, miNivel, mensaje, campoAConsultar, miCalidad,
								calidadLlamador);
						salidaOtrosAgentes.agregarCalidad(salida.getCalidad());

						mapValores.get(campoAConsultar).add(salida.getValor());
						mapAgentesFavoritos.get(campoAConsultar).aumentar(agenteAlAzar);
						log(TipoLog.ACTUALIZO_FAVORITOS, agenteLlamador, agenteAlAzar, miNivel, mensaje, campoAConsultar, miCalidad,
								calidadLlamador);
					} else {
						noMeRespondieron = true;
						log(TipoLog.NO_ME_RESPONDIO, agenteLlamador, agenteAlAzar, miNivel, mensaje, campoAConsultar, miCalidad,
								calidadLlamador);
					}
					HilosAppVehiculo.stopAllThreads(agenteAlAzar);
					hiloConsulta.stop();
				} else {
					noTengoMensajesParaConsultar = true;
					log(TipoLog.NO_TENGO_MENSAJES_PARA_CONSULTAR, agenteLlamador, agenteAlAzar, miNivel, mensaje, campoConsultado,
							miCalidad, calidadLlamador);
					break;
				}
			}
		}

		// Aca recorro el map, para obtener el mejor valor para cada campo
		// y actualizar el mensaje con estos valores.
		if (CollectionUtils.isNotEmpty(mapValores.keySet())) {
			for (CampoVehiculo campo : mapValores.keySet()) {
				ValorCampo mejorValorCampo = obtenerMejorValorCampo(campo, mapValores.get(campo));

				// Aca hay veces que el valor llega en null porque nadie le respondió para ese campo,
				// o yo no tenía mensajes para consultar a otros. Qué hacer en ese caso???

				if (mejorValorCampo != null && mejorValorCampo.get() != null) {
					mensaje.getCampo(campo).setValor(mejorValorCampo);
				} else {
					// No hago nada y me quedo con el valor que tenía del campo.
					if (noTengoMensajesParaConsultar) {
						log(TipoLog.VALOR_CAMPO_NULL_SIN_MENSAJES, agenteLlamador, null, miNivel, mensaje, campo, miCalidad,
								calidadLlamador);
					}
					if (noMeRespondieron) {
						log(TipoLog.VALOR_CAMPO_NULL_NO_ME_RESPONDIERON, agenteLlamador, null, miNivel, mensaje, campo, miCalidad,
								calidadLlamador);
					}
				}
			}
		}

		salidaOtrosAgentes.setMensaje(mensaje);

		Duration duration = CommonUtils.timing(now);
		LogService.getInstance().writeln(
				"@@@@@@@@@@@@@@@@@@@@@@@@ Duración entre entrada y salida de consultarAOtrosAgentes= " + duration.getSeconds() + " segs.");
		return salidaOtrosAgentes;
	}

	/**
	 * Obtiene el mejor valor de la lista de valores.
	 * Puede ser un promedio, o el valor mas alto.
	 */
	@Override
	protected ValorCampo obtenerMejorValorCampo(CampoVehiculo campo, List<ValorCampo> listaValores) {
		ValorCampo valor = new ValorCampo(null);

		if (CollectionUtils.isNotEmpty(listaValores)) {
			switch (campo) {
			case CAR:
			case PRECIO:
			case TECH:
			case CONFORT:
				double[] numeros = new double[listaValores.size()];
				for (int i = 0; i < listaValores.size(); i++) {
					numeros[i] = (double) listaValores.get(i).get();
				}

				double promedio = CommonUtils.promedio(numeros);
				valor = new ValorCampo(CommonUtils.roundDouble(promedio, 5));
				break;
			default:
				break;
			}
		} else {
			// LogService.getInstance().write("List<ValorCampo> listaValores vacía.");
		}

		return valor;
	}

	@Override
	protected List<CampoVehiculo> getListaSubcamposCalculadosAlAzar(CampoVehiculo campoConsultado) {
		List<CampoVehiculo> lista = new ArrayList<>();

		switch (campoConsultado) {
		case CAR:
			if (SI_NO()) {
				lista.add(CampoVehiculo.PRECIO);
			}
			if (SI_NO()) {
				lista.add(CampoVehiculo.TECH);
			}
			break;
		case PRECIO:// no tiene subcampos calculados.
			break;
		case TECH:
			if (SI_NO()) {
				lista.add(CampoVehiculo.CONFORT);
			}
			break;
		case CONFORT:// no tiene subcampos calculados.
			break;
		default:
			break;
		}
		return lista;
	}

	@Override
	protected ValorCampo calcularValorCampo(MensajeVehiculo mensaje, CampoVehiculo campoConsultado, int miNivel) {
		ValorCampo valorCampo = null;

		try {
			switch (campoConsultado) {
			case CAR:
				double precio = getDouble(mensaje.getPrecio().get());
				double caracteristicasTecnicas = getDouble(mensaje.getTech().get());

				double valorCar = FuncionesCAR.calcularAceptabilidad(precio, caracteristicasTecnicas);
				valorCampo = new ValorCampo(aplicarMiPorcentajeDeError(campoConsultado, valorCar));
				break;
			case PRECIO:
				NivelPrecio precioCompra = (NivelPrecio) mensaje.getPrecioCompra().get();
				NivelPrecio precioMantenimiento = (NivelPrecio) mensaje.getPrecioMant().get();

				double valorPrecio = FuncionesPRECIO.calcularPrecio(precioCompra, precioMantenimiento);
				valorCampo = new ValorCampo(aplicarMiPorcentajeDeError(campoConsultado, valorPrecio));
				break;
			case TECH:
				double confort = getDouble(mensaje.getConfort().get());
				NivelSeguridad seguridad = (NivelSeguridad) mensaje.getSeguridad().get();

				double valorTech = FuncionesTECH.calcularCaracteristicasTecnicas(confort, seguridad);
				valorCampo = new ValorCampo(aplicarMiPorcentajeDeError(campoConsultado, valorTech));
				break;
			case CONFORT:
				NumeroPuertas numPuertas = (NumeroPuertas) mensaje.getNumeroPuertas().get();
				NumeroAsientos numAsientos = (NumeroAsientos) mensaje.getNumeroAsientos().get();
				TamanioBaul tamBaul = (TamanioBaul) mensaje.getTamanioBaul().get();

				double valorConfort = FuncionesCONFORT.calcularConfort(numPuertas, numAsientos, tamBaul);
				valorCampo = new ValorCampo(aplicarMiPorcentajeDeError(campoConsultado, valorConfort));
				break;
			default:
				// Si no es campo calculado, devuelvo el valor que ya tengo.
				valorCampo = mensaje.getCampo(campoConsultado).getValor();
				break;
			}
		} catch (Exception e) {
			LogService.getInstance().writeln(
					"Error en calcularValorCampo, nivel: " + miNivel + "\n" + mensaje.toString() + "Campo consultado: " + campoConsultado);
			e.printStackTrace();
			throw e;
		}
		return valorCampo;
	}
}