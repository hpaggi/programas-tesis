package com.p2p.logica.creditos;

import java.time.Duration;
import java.time.Instant;

import com.p2p.entidades.SalidaConsulta;
import com.p2p.entidades.ValorCampo;
import com.p2p.entidades.creditos.AgenteCredito;
import com.p2p.entidades.creditos.AgentesFavoritosCredito;
import com.p2p.entidades.creditos.HilosAppCredito;
import com.p2p.entidades.creditos.MensajeCredito;
import com.p2p.entidades.creditos.SalidaConsultaOtrosAgentesCredito;
import com.p2p.enums.creditos.CampoCredito;
import com.p2p.logica.AbstractService;
import com.p2p.logica.LogService;
import com.p2p.logica.MensajesService;
import com.p2p.util.CommonUtils;

public class CreditosService
		extends AbstractService<AgenteCredito, MensajeCredito, CampoCredito, AgentesFavoritosCredito, SalidaConsultaOtrosAgentesCredito> {

	private static CreditosService instance = new CreditosService();

	private CreditosService() {
		super();
	}

	public static CreditosService getInstance() {
		LogService.getInstance().writeln("Instanciando servicio SitiosWebService.");
		return instance;
	}

	@SuppressWarnings("deprecation")
	@Override
	protected void iniciarConsulta() {
		for (MensajeCredito mensaje : listaDeDatos) {
			Instant now = Instant.now();
			int indiceMsg = mensaje.getIndiceMsg();

			LogService.getInstance().writeln("###################################  Antes de consultar mensaje número " + indiceMsg
					+ "  ###################################");

			SalidaConsulta salida = null;
			Thread hiloConsulta = new Thread(new Runnable() {
				@Override
				public void run() {
					agenteRaiz.consultar(null, 0d, mensaje, CampoCredito.RESULT, 0);
				}
			});
			hiloConsulta.setName("Hilo de" + agenteRaiz.getNombre() + " Nivel: " + 0);
			hiloConsulta.start();

			try {
				hiloConsulta.join(timeoutEsperaRespuesta * 1000);

				salida = agenteRaiz.getSalidaConsulta();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			LogService.getInstance().writeln("###################################  Después de consultar mensaje número " + indiceMsg
					+ "  ###################################\n");

			Duration duration = CommonUtils.timing(now);

			if (salida != null) {
				LogService.getInstance().writeln("Respuesta recibida por el SERVICIO.");
				LogService.getInstance().writeln("	Calidad recibida=" + salida.getCalidad());
				LogService.getInstance().writeln("	Tiempo entre enviar y recibir mensaje=" + duration.getSeconds() + " segs.");
				LogService.getInstance().writeln("	Valor recibido de RESULT: " + salida.getValor() + "");
				mensaje.getCampo(CampoCredito.RESULT).setValor(salida.getValor());
			} else {
				LogService.getInstance().writeln("@@@@@@@@@@@@@@@@ Valor de RESULT: SERVICO NO LLEGÓ A ESPERAR @@@@@@@@@@@@@@@@");
			}
			HilosAppCredito.stopAllThreads((AgenteCredito) agenteRaiz);
			hiloConsulta.stop();

			LogService.getInstance().write("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ");
			LogService.getInstance().write("Duración entre entrada y salida de mensaje número ");
			LogService.getInstance().writeln(indiceMsg + ": " + duration.getSeconds() + " segs. @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
			LogService.getInstance().writeln();

			logMensajes.add(mensaje.toStringUnaLinea());
		}

		LogService.getInstance().writeln();
		LogService.getInstance().write("###################################  ");
		LogService.getInstance().write("Cantidad de mensajes gastados por registro");
		LogService.getInstance().writeln("  ###################################");

		for (MensajeCredito mensaje : listaDeDatos) {
			int indiceMsg = mensaje.getIndiceMsg();
			int cant = MensajesService.getInstance().getCant(indiceMsg);

			LogService.getInstance().write("	Registro " + indiceMsg + ": " + cant);
			LogService.getInstance().writeln(cant == 1 ? " mensaje." : " mensajes.");
		}

		LogService.getInstance().writeln();
		LogService.getInstance().writeln(
				"-------------------------------------------------------------------------------------------------------------------------------------");
		LogService.getInstance().writeln(
				"-------------------------------------------------------- FIN DE LA EJECUCIÓN --------------------------------------------------------");
		LogService.getInstance().writeln(
				"-------------------------------------------------------------------------------------------------------------------------------------");

		LogService.getInstance().writeln();
		imprimirLogsDeAgentes();
	}

	@Override
	protected CampoCredito getTipoCampo(MensajeCredito mensaje) {
		return mensaje.getCampoBase();
	}

	/**
	 * Instancia los agentes para que puedan interactuar.
	 */
	@Override
	protected void instanciarAgentes() {
		MapAgentesCredito.init();

		agenteRaiz = new AgenteCredito("Agente OMEGA", true, cantMensajesXAgente, cantMaxFavoritos, timeoutEsperaRespuesta, peso, modo);
		LogService.getInstance().writeln("Instanciando agente: " + agenteRaiz);

		// MapAgentesCredito.put("Agente OMEGA", agenteRaiz);

		for (int i = 1; i <= cantAgentes; i++) {
			String nombre = "Agente " + i;
			AgenteCredito agente = new AgenteCredito(nombre, false, cantMensajesXAgente, cantMaxFavoritos, timeoutEsperaRespuesta, peso,
					modo);

			LogService.getInstance().writeln("Instanciando agente: " + agente);
			MapAgentesCredito.put(nombre, agente);
		}
		LogService.getInstance().writeln();

		listaAgentes = MapAgentesCredito.values();
		agenteRaiz.inicializarListaFavoritos();
		for (AgenteCredito agente : MapAgentesCredito.values()) {
			agente.inicializarListaFavoritos();
		}
	}

	@Override
	protected MensajeCredito getMensaje(String[] a) throws Exception {
		if (a.length != 23) {
			throw new Exception("Línea con cantidad de parámetros distinta a la esperada.");
		}

		// C1;C20;RESULTADO orig;factores POS;Factores NEG;RES CALC;RESULTADO
		int c1 = Integer.valueOf(a[0]);
		int c2 = Integer.valueOf(a[1]);
		int c3 = Integer.valueOf(a[2]);
		int c4 = Integer.valueOf(a[3]);
		int c5 = Integer.valueOf(a[4]);
		int c6 = Integer.valueOf(a[5]);
		int c7 = Integer.valueOf(a[6]);
		int c8 = Integer.valueOf(a[7]);
		int c9 = Integer.valueOf(a[8]);
		int c10 = Integer.valueOf(a[9]);
		int c11 = Integer.valueOf(a[10]);
		int c12 = Integer.valueOf(a[11]);
		int c13 = Integer.valueOf(a[12]);
		int c14 = Integer.valueOf(a[13]);
		int c15 = Integer.valueOf(a[14]);
		int c16 = Integer.valueOf(a[15]);
		int c17 = Integer.valueOf(a[16]);
		int c18 = Integer.valueOf(a[17]);
		int c19 = Integer.valueOf(a[18]);
		int c20 = Integer.valueOf(a[19]);

		String fac_posStr = a[20];
		fac_posStr = fac_posStr.replace(",", ".");
		double fac_pos = Double.valueOf(fac_posStr);

		String fac_negStr = a[21];
		fac_negStr = fac_negStr.replace(",", ".");
		double fac_neg = Double.valueOf(fac_negStr);

		int RESULT = Integer.valueOf(a[22]);

		MensajeCredito linea = new MensajeCredito();

		linea.setC1(new ValorCampo(c1));
		linea.setC2(new ValorCampo(c2));
		linea.setC3(new ValorCampo(c3));
		linea.setC4(new ValorCampo(c4));
		linea.setC5(new ValorCampo(c5));
		linea.setC6(new ValorCampo(c6));
		linea.setC7(new ValorCampo(c7));
		linea.setC8(new ValorCampo(c8));
		linea.setC9(new ValorCampo(c9));
		linea.setC10(new ValorCampo(c10));
		linea.setC11(new ValorCampo(c11));
		linea.setC12(new ValorCampo(c12));
		linea.setC13(new ValorCampo(c13));
		linea.setC14(new ValorCampo(c14));
		linea.setC15(new ValorCampo(c15));
		linea.setC16(new ValorCampo(c16));
		linea.setC17(new ValorCampo(c17));
		linea.setC18(new ValorCampo(c18));
		linea.setC19(new ValorCampo(c19));
		linea.setC20(new ValorCampo(c20));

		linea.setFAC_POSITIVOS(new ValorCampo(fac_pos));
		linea.setFAC_NEGATIVOS(new ValorCampo(fac_neg));

		linea.setRESULT(new ValorCampo(RESULT));

		return linea;
	}
}