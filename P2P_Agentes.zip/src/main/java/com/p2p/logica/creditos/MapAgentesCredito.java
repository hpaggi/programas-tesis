package com.p2p.logica.creditos;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.p2p.entidades.creditos.AgenteCredito;

public class MapAgentesCredito {

	private static Map<String, AgenteCredito> map;

	/**
	 * Inicializa el mapa de agentes vacío.
	 */
	public static void init() {
		map = new HashMap<String, AgenteCredito>();
	}

	public static int size() {
		return map.size();
	}

	public static boolean isEmpty() {
		return map.isEmpty();
	}

	public static boolean containsKey(Object key) {
		return map.containsKey(key);
	}

	public static boolean containsValue(Object value) {
		return map.containsValue(value);
	}

	public static AgenteCredito get(Object key) {
		return map.get(key);
	}

	public static AgenteCredito put(String key, AgenteCredito value) {
		return map.put(key, value);
	}

	public static AgenteCredito remove(Object key) {
		return map.remove(key);
	}

	public static Collection<AgenteCredito> values() {
		List<AgenteCredito> list = new ArrayList<AgenteCredito>(map.values());
		Collections.sort(list);
		return list;
	}

	public static Set<Entry<String, AgenteCredito>> entrySet() {
		return map.entrySet();
	}
}