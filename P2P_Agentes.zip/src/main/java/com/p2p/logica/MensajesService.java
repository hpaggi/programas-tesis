package com.p2p.logica;

import java.util.HashMap;
import java.util.Map;

public class MensajesService {

	private static MensajesService instance = new MensajesService();
	private Map<Integer, Integer> mapCantMensajesXRegistro;

	private MensajesService() {
		if (mapCantMensajesXRegistro == null) {
			mapCantMensajesXRegistro = new HashMap<>();
		}
	}

	public static MensajesService getInstance() {
		return instance;
	}

	/**
	 * Suma 1, a la cantidad de mensajes del registro parámetro.
	 */
	public synchronized void add(Integer registro) {
		Integer cantMensajes = 0;

		if (mapCantMensajesXRegistro.get(registro) != null) {
			cantMensajes = mapCantMensajesXRegistro.get(registro);
		}
		cantMensajes++;

		mapCantMensajesXRegistro.put(registro, cantMensajes);
	}

	/**
	 * Devuelve la cantidad de mensajes del registro parámetro.
	 */
	public synchronized Integer getCant(Integer registro) {
		Integer cantMensajes = 0;

		if (mapCantMensajesXRegistro.get(registro) != null) {
			cantMensajes = mapCantMensajesXRegistro.get(registro);
		}

		return cantMensajes;
	}

	/**
	 * Pone en 0 la cantidad de mensajes del registro parámetro.
	 */
	public synchronized void clear(Integer registro) {
		mapCantMensajesXRegistro.put(registro, 0);
	}

	/**
	 * Pone en 0 la cantidad de mensajes de todos los registros.
	 */
	public synchronized void clearAll() {
		mapCantMensajesXRegistro = new HashMap<>();
	}
}