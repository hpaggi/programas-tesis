package com.p2p.logica;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.p2p.entidades.AbstractAgente;
import com.p2p.entidades.AbstractMensaje;
import com.p2p.entidades.AbstractSalidaConsultaOtrosAgentes;
import com.p2p.entidades.Parametro;
import com.p2p.enums.ITipoCampo;
import com.p2p.enums.Modo;
import com.p2p.enums.TipoNegocio;
import com.p2p.util.CommonUtils;

public abstract class AbstractService<TIPO_AGENTE extends AbstractAgente<?, ?, ?, ?, ?>, TIPO_MENSAJE extends AbstractMensaje, TIPO_CAMPO extends ITipoCampo, TIPO_FAVORITOS, TIPO_SALIDA extends AbstractSalidaConsultaOtrosAgentes<TIPO_MENSAJE>> {

	protected List<TIPO_MENSAJE> listaDeDatos;
	protected List<String> logMensajes = new ArrayList<String>();
	protected int cantAgentes;
	protected int cantMensajesXAgente;
	protected int cantMaxFavoritos;
	protected int timeoutEsperaRespuesta;
	protected int peso;
	protected int cantEjecuciones;
	protected Modo modo;
	protected TipoNegocio tipoNegocio;
	protected File archivoDatos;
	// protected Double calidadRaiz;
	protected AbstractAgente<TIPO_AGENTE, TIPO_MENSAJE, TIPO_CAMPO, TIPO_FAVORITOS, TIPO_SALIDA> agenteRaiz;
	protected Collection<TIPO_AGENTE> listaAgentes;

	/**
	 * Método principal que inicia todo el proceso de mensajería.
	 */
	public final void init(Parametro... parametros) {
		LogService.getInstance().writeln();
		LogService.getInstance().writeln("------------------------------------------------ INICIANDO " + this.getClass().getSimpleName()
				+ " ------------------------------------------------");
		LogService.getInstance().writeln(
				"----------------------------------------------------------------------------------------------------------------------------");
		LogService.getInstance().writeln();

		leerParametros(parametros);
		procesarJuegoDeDatos();
		instanciarAgentes();
		iniciarConsulta();
	}

	/**
	 * Borra el log de mensajes.
	 */
	public final void clearMensajes() {
		logMensajes = new ArrayList<>();
	}

	/**
	 * Lee los parámetros de iniciales del sistema.
	 */
	private void leerParametros(Parametro[] parametros) {
		for (Parametro param : parametros) {
			LogService.getInstance().writeln(param);
			switch (param.getTipo()) {
			case CANTIDAD_AGENTES:
				cantAgentes = Integer.valueOf((String) param.getValor());
				break;
			case CANTIDAD_MENSAJES:
				cantMensajesXAgente = Integer.valueOf((String) param.getValor());
				break;
			case CANTIDAD_MAX_FAVORITOS:
				cantMaxFavoritos = Integer.valueOf((String) param.getValor());
				break;
			case TIMEOUT_ESPERA_RESPUESTA:
				timeoutEsperaRespuesta = Integer.valueOf((String) param.getValor());
				break;
			case ARCHIVO_DATOS:
				archivoDatos = (File) param.getValor();
				break;
			case PESO:
				peso = Integer.valueOf((String) param.getValor());
				break;
			case CANTIDAD_EJECUCIONES:
				cantEjecuciones = Integer.valueOf((String) param.getValor());
				break;
			case MODO:
				modo = (Modo) param.getValor();
				break;
			// case CALIDAD_RAIZ:
			// if (param.getValor() == null || StringUtils.isBlank((String) param.getValor())) {
			// calidadRaiz = 1d;
			// } else {
			// String valor = (String) param.getValor();
			// valor = valor.replace(",", ".");
			// calidadRaiz = Double.valueOf(valor);
			// }
			// break;
			default:
				break;
			}
		}
		LogService.getInstance().writeln();
	}

	/**
	 * Procesa el archivo del juego de datos y genera una lista con los datos.
	 */
	private void procesarJuegoDeDatos() {
		listaDeDatos = procesarLineas(archivoDatos);
	}

	/**
	 * Lee el archivo linea por línea tratando de obtener los datos contenidos.
	 */
	private List<TIPO_MENSAJE> procesarLineas(File fileIn) {
		List<TIPO_MENSAJE> lista = new ArrayList<TIPO_MENSAJE>();

		if (fileIn != null && fileIn.exists() && !fileIn.isDirectory()) {
			FileReader frIn = null;
			BufferedReader br = null;

			try {
				frIn = new FileReader(fileIn);

				// Creamos el Buffer de Lectura
				br = new BufferedReader(frIn);

				String strLinea;
				int indice = 0;

				// Leer el archivo linea por linea
				while ((strLinea = br.readLine()) != null) {
					// Imprimimos la linea por pantalla
					// log.info(strLinea);

					String[] a = strLinea.split(";");

					try {
						TIPO_MENSAJE linea = getMensaje(a);
						indice++;
						linea.setIndiceMsg(indice);

						LogService.getInstance().writeln("Línea leida correctamente: " + strLinea);
						lista.add(linea);
					} catch (Exception e) {
						LogService.getInstance().errorln("-------------------------------------------------");
						LogService.getInstance().errorln("Error parseando la línea: " + strLinea);
						LogService.getInstance().errorln("-------------------------------------------------");
					}
				}
				LogService.getInstance().writeln();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (null != frIn) {
						frIn.close();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return lista;
	}

	protected abstract TIPO_MENSAJE getMensaje(String[] a) throws Exception;

	/**
	 * Instancia los agentes para que puedan interactuar.
	 */
	protected abstract void instanciarAgentes();

	/**
	 * Inicia las consultas.
	 */
	protected abstract void iniciarConsulta();

	protected abstract TIPO_CAMPO getTipoCampo(TIPO_MENSAJE mensaje);

	/**
	 * Imprime y guarda los logs de cada agente en órden.
	 */
	public final void guardarLogsDeAgentes() {
		List<String> lineas = new ArrayList<>();

		lineas.add(" ");
		lineas.add(
				"------------------------------------------------------- LOG de Agentes INICIO -------------------------------------------------------");
		lineas.add(" ");

		// Imprimo a OMEGA porque no está en el map de agentes. ------------------
		List<String> logs = agenteRaiz.getLog();

		lineas.add("------------------------------------------------ Log del agente: " + agenteRaiz.getNombre()
				+ " INICIO ------------------------------------------------");

		synchronized (logs) {
			for (String log : logs) {
				lineas.add(log);
			}
		}

		lineas.add("------------------------------------------------ Log del agente: " + agenteRaiz.getNombre()
				+ " FIN ------------------------------------------------");
		lineas.add(" ");
		// ------------------

		for (TIPO_AGENTE agente : listaAgentes) {
			logs = agente.getLog();

			lineas.add("------------------------------------------------ Log del agente: " + agente.getNombre()
					+ " INICIO ------------------------------------------------");

			synchronized (logs) {
				for (String log : logs) {
					lineas.add(log);
				}
			}

			lineas.add("------------------------------------------------ Log del agente: " + agente.getNombre()
					+ " FIN ------------------------------------------------");
			lineas.add(" ");
		}

		lineas.add(
				"------------------------------------------------------- LOG de Agentes FIN -------------------------------------------------------");
		lineas.add(" ");

		LogService.getInstance().writeln("Guardando logs de agentes.");
		guardarLogsEnArchivo(lineas, "LOG_AGENTES");
	}

	/**
	 * Imprime los logs de cada agente en órden.
	 */
	public final void imprimirLogsDeAgentes() {
		LogService.getInstance().writeln();

		LogService.getInstance().writeln(
				"------------------------------------------------------- LOG de Agentes INICIO -------------------------------------------------------");
		LogService.getInstance().writeln();

		// Imprimo a OMEGA porque no está en el map de agentes. ------------------
		List<String> logs = agenteRaiz.getLog();

		LogService.getInstance().writeln("------------------------------------------------ Log del agente: " + agenteRaiz.getNombre()
				+ " INICIO ------------------------------------------------");

		synchronized (logs) {
			for (String log : logs) {
				LogService.getInstance().writeln(log);
			}
		}

		LogService.getInstance().writeln("------------------------------------------------ Log del agente: " + agenteRaiz.getNombre()
				+ " FIN ------------------------------------------------");
		LogService.getInstance().writeln();
		// ------------------

		for (TIPO_AGENTE agente : listaAgentes) {
			logs = agente.getLog();

			LogService.getInstance().writeln("------------------------------------------------ Log del agente: " + agente.getNombre()
					+ " INICIO ------------------------------------------------");

			synchronized (logs) {
				for (String log : logs) {
					LogService.getInstance().writeln(log);
				}
			}

			LogService.getInstance().writeln("------------------------------------------------ Log del agente: " + agente.getNombre()
					+ " FIN ------------------------------------------------");
			LogService.getInstance().writeln();
		}

		LogService.getInstance().writeln(
				"------------------------------------------------------- LOG de Agentes FIN -------------------------------------------------------");
		LogService.getInstance().writeln();
	}

	/**
	 * Imprime y guarda los mensajes finales obtenidos.
	 */
	public final void guardarLogsMensajes() {
		List<String> lineas = new ArrayList<>();

		lineas.add(" ");
		lineas.add(
				"------------------------------------------------ LOG de Mensajes INICIO ------------------------------------------------");

		synchronized (logMensajes) {
			for (String log : logMensajes) {
				int i = logMensajes.indexOf(log) + 1;
				String index = CommonUtils.printFixedSize(i + ") ", 5);

				lineas.add(index + log);
			}
		}

		lineas.add("------------------------------------------------ LOG de Mensajes FIN ------------------------------------------------");
		lineas.add(" ");

		LogService.getInstance().writeln("Guardando logs de mensajes.");
		guardarLogsEnArchivo(lineas, "MENSAJES");
	}

	/**
	 * Imprime los mensajes finales obtenidos.
	 */
	public final void imprimirLogsMensajes() {
		LogService.getInstance().writeln();

		LogService.getInstance().writeln(
				"------------------------------------------------ LOG de Mensajes INICIO ------------------------------------------------");

		synchronized (logMensajes) {
			for (String log : logMensajes) {
				int i = logMensajes.indexOf(log) + 1;
				String index = CommonUtils.printFixedSize(i + ") ", 5);

				LogService.getInstance().writeln(index + log);
			}
		}

		LogService.getInstance().writeln(
				"------------------------------------------------ LOG de Mensajes FIN ------------------------------------------------");
		LogService.getInstance().writeln();
	}

	private void guardarLogsEnArchivo(List<String> lineas, String tipo) {
		String extension = "." + StringUtils.substringAfterLast(archivoDatos.getName(), ".");

		String dirSalida = archivoDatos.getParent();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy_hh-mm");
		String fecha = sdf.format(new Date()) + "_";

		String nombreArchivo = archivoDatos.getName().replace(extension, "") + "_OUT_" + fecha + tipo + ".txt";

		LogService.getInstance().writeln("Guardando en archivo: " + dirSalida + "\\" + nombreArchivo);
		LogService.getInstance().writeln();

		File fileOut = createFile(dirSalida, nombreArchivo);
		FileWriter archivoSalida = null;
		PrintWriter pw = null;

		try {

			archivoSalida = new FileWriter(fileOut);
			pw = new PrintWriter(archivoSalida);

			for (String linea : lineas) {
				pw.println(linea);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (null != archivoSalida) {
					archivoSalida.close();
				}
				if (null != pw) {
					pw.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void guardarLogPantallaEnArchivo(String texto) {
		String extension = "." + StringUtils.substringAfterLast(archivoDatos.getName(), ".");

		String dirSalida = archivoDatos.getParent();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy_hh-mm");
		String fecha = sdf.format(new Date()) + "_";

		String nombreArchivo = archivoDatos.getName().replace(extension, "") + "_OUT_" + fecha + "LOG_PANTALLA.txt";

		LogService.getInstance().writeln("Guardando en archivo: " + dirSalida + "\\" + nombreArchivo);
		LogService.getInstance().writeln();

		File fileOut = createFile(dirSalida, nombreArchivo);
		FileWriter archivoSalida = null;
		PrintWriter pw = null;

		try {

			archivoSalida = new FileWriter(fileOut);
			pw = new PrintWriter(archivoSalida);

			pw.println(texto);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (null != archivoSalida) {
					archivoSalida.close();
				}
				if (null != pw) {
					pw.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private File createFile(String dirName, String fileName) {
		File dir = new File(dirName);
		dir.mkdirs();

		File file = new File(dir, fileName);

		return file;
	}
}