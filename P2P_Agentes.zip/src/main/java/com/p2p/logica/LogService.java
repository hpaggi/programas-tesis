package com.p2p.logica;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class LogService {

	private static LogService instance = new LogService();

	private JTextArea textAreaLogs;
	private JScrollPane scrollPanelLog;

	private LogService() {
	}

	public static LogService getInstance() {
		return instance;
	}

	public void init(JTextArea textAreaLogs, JScrollPane scrollPanelLog) {
		this.textAreaLogs = textAreaLogs;
		this.scrollPanelLog = scrollPanelLog;
	}

	public synchronized void writeln() {
		System.out.println();
		writeText("\n");
	}

	public synchronized void writeln(Object obj) {
		if (obj != null) {
			System.out.println(obj.toString());
			writeText(obj.toString() + "\n");
		}

	}

	public synchronized void write(Object obj) {
		if (obj != null) {
			System.out.print(obj.toString());
			writeText(obj.toString());
		}
	}

	/**
	 * Vacía el log de la pantalla.
	 */
	public synchronized void clear() {
		System.out.println();
		textAreaLogs.setText("");
		scrollPanelLog.getVerticalScrollBar().setValue(scrollPanelLog.getVerticalScrollBar().getMinimum());
	}

	public synchronized void errorln() {
		System.err.println();
		writeError("\n");
	}

	public synchronized void errorln(Object obj) {
		if (obj != null) {
			System.err.println(obj.toString());
			writeError(obj.toString() + "\n");
		}

	}

	public synchronized void error(Object obj) {
		if (obj != null) {
			System.err.print(obj.toString());
			writeError(obj.toString());
		}
	}

	private void writeText(Object obj) {
		textAreaLogs.append(obj.toString());
		scrollPanelLog.getVerticalScrollBar().setValue(scrollPanelLog.getVerticalScrollBar().getMaximum() + 100);
	}

	private void writeError(Object obj) {
		// textAreaLogs.setForeground(Color.RED);
		textAreaLogs.append(obj.toString());
		// textAreaLogs.setForeground(Color.GREEN);
		scrollPanelLog.getVerticalScrollBar().setValue(scrollPanelLog.getVerticalScrollBar().getMaximum() + 100);
	}
}