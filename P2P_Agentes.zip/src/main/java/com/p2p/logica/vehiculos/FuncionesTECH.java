package com.p2p.logica.vehiculos;

import com.p2p.enums.vehiculos.NivelSeguridad;
import com.p2p.util.CommonUtils;

public class FuncionesTECH {

	public static double calcularCaracteristicasTecnicas(double confort, NivelSeguridad seguridad) {
		double valoracion = 0;

		double valoracionNivelSeguridad = valorSegunNivelSeguridad(seguridad);

		valoracion = valoracionNivelSeguridad * confort;

		return CommonUtils.roundDouble(valoracion, 5);
	}

	private static double valorSegunNivelSeguridad(NivelSeguridad seguridad) {
		double valoracion = 0;

		switch (seguridad) {
		case BAJA:
			valoracion = 1;
			break;
		case MEDIA:
			valoracion = 2;
			break;
		case ALTA:
			valoracion = 3;
			break;
		default:
			break;
		}
		return valoracion;
	}
}