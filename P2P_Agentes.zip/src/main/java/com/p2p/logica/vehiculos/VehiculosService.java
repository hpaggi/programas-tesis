package com.p2p.logica.vehiculos;

import java.time.Duration;
import java.time.Instant;

import com.p2p.entidades.SalidaConsulta;
import com.p2p.entidades.ValorCampo;
import com.p2p.entidades.vehiculos.AgenteVehiculo;
import com.p2p.entidades.vehiculos.AgentesFavoritosVehiculo;
import com.p2p.entidades.vehiculos.HilosAppVehiculo;
import com.p2p.entidades.vehiculos.MensajeVehiculo;
import com.p2p.entidades.vehiculos.SalidaConsultaOtrosAgentesVehiculo;
import com.p2p.enums.vehiculos.CampoVehiculo;
import com.p2p.enums.vehiculos.NivelPrecio;
import com.p2p.enums.vehiculos.NivelSeguridad;
import com.p2p.enums.vehiculos.NumeroAsientos;
import com.p2p.enums.vehiculos.NumeroPuertas;
import com.p2p.enums.vehiculos.TamanioBaul;
import com.p2p.logica.AbstractService;
import com.p2p.logica.LogService;
import com.p2p.logica.MensajesService;
import com.p2p.util.CommonUtils;

public class VehiculosService extends
		AbstractService<AgenteVehiculo, MensajeVehiculo, CampoVehiculo, AgentesFavoritosVehiculo, SalidaConsultaOtrosAgentesVehiculo> {

	private static VehiculosService instance = new VehiculosService();

	private VehiculosService() {
		super();
	}

	public static VehiculosService getInstance() {
		LogService.getInstance().writeln("Instanciando servicio VehiculosService.");
		return instance;
	}

	@SuppressWarnings("deprecation")
	@Override
	protected void iniciarConsulta() {
		for (MensajeVehiculo mensaje : listaDeDatos) {
			Instant now = Instant.now();
			int indiceMsg = mensaje.getIndiceMsg();

			LogService.getInstance().writeln("###################################  Antes de consultar mensaje número " + indiceMsg
					+ "  ###################################");

			SalidaConsulta salida = null;
			Thread hiloConsulta = new Thread(new Runnable() {
				@Override
				public void run() {
					agenteRaiz.consultar(null, 0d, mensaje, CampoVehiculo.CAR, 0);
				}
			});
			hiloConsulta.setName("Hilo de" + agenteRaiz.getNombre() + " Nivel: " + 0);
			hiloConsulta.start();

			try {
				hiloConsulta.join(timeoutEsperaRespuesta * 1000);

				salida = agenteRaiz.getSalidaConsulta();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			LogService.getInstance().writeln("###################################  Después de consultar mensaje número " + indiceMsg
					+ "  ###################################\n");

			Duration duration = CommonUtils.timing(now);

			if (salida != null) {
				LogService.getInstance().writeln("Respuesta recibida por el SERVICIO.");
				LogService.getInstance().writeln("	Calidad recibida=" + salida.getCalidad());
				LogService.getInstance().writeln("	Tiempo entre enviar y recibir mensaje=" + duration.getSeconds() + " segs.");
				LogService.getInstance().writeln("	Valor recibido de CAR: " + salida.getValor() + "");
				mensaje.getCampo(CampoVehiculo.CAR).setValor(salida.getValor());
			} else {
				LogService.getInstance().writeln("@@@@@@@@@@@@@@@@ Valor de CAR: SERVICO NO LLEGÓ A ESPERAR @@@@@@@@@@@@@@@@");
			}
			HilosAppVehiculo.stopAllThreads((AgenteVehiculo) agenteRaiz);
			hiloConsulta.stop();

			LogService.getInstance().write("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ");
			LogService.getInstance().write("Duración entre entrada y salida de mensaje número ");
			LogService.getInstance().writeln(indiceMsg + ": " + duration.getSeconds() + " segs. @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
			LogService.getInstance().writeln();

			logMensajes.add(mensaje.toStringUnaLinea());
		}

		LogService.getInstance().writeln();
		LogService.getInstance().write("###################################  ");
		LogService.getInstance().write("Cantidad de mensajes gastados por registro");
		LogService.getInstance().writeln("  ###################################");

		for (MensajeVehiculo mensaje : listaDeDatos) {
			int indiceMsg = mensaje.getIndiceMsg();
			int cant = MensajesService.getInstance().getCant(indiceMsg);

			LogService.getInstance().write("	Registro " + indiceMsg + ": " + cant);
			LogService.getInstance().writeln(cant == 1 ? " mensaje." : " mensajes.");
		}

		LogService.getInstance().writeln();
		LogService.getInstance().writeln(
				"-------------------------------------------------------------------------------------------------------------------------------------");
		LogService.getInstance().writeln(
				"-------------------------------------------------------- FIN DE LA EJECUCIÓN --------------------------------------------------------");
		LogService.getInstance().writeln(
				"-------------------------------------------------------------------------------------------------------------------------------------");

		LogService.getInstance().writeln();
		imprimirLogsDeAgentes();
	}

	@Override
	protected CampoVehiculo getTipoCampo(MensajeVehiculo mensaje) {
		return mensaje.getCampoBase();
	}

	/**
	 * Instancia los agentes para que puedan interactuar.
	 */
	@Override
	protected void instanciarAgentes() {
		MapAgentesVehiculo.init();

		agenteRaiz = new AgenteVehiculo("Agente OMEGA", true, cantMensajesXAgente, cantMaxFavoritos, timeoutEsperaRespuesta, peso, modo);
		LogService.getInstance().writeln("Instanciando agente: " + agenteRaiz);

		// MapAgentesVehiculo.put("Agente OMEGA", agenteRaiz);

		for (int i = 1; i <= cantAgentes; i++) {
			String nombre = "Agente " + i;
			AgenteVehiculo agente = new AgenteVehiculo(nombre, false, cantMensajesXAgente, cantMaxFavoritos, timeoutEsperaRespuesta, peso,
					modo);

			LogService.getInstance().writeln("Instanciando agente: " + agente);
			MapAgentesVehiculo.put(nombre, agente);
		}
		LogService.getInstance().writeln();

		listaAgentes = MapAgentesVehiculo.values();
		agenteRaiz.inicializarListaFavoritos();
		for (AgenteVehiculo agente : MapAgentesVehiculo.values()) {
			agente.inicializarListaFavoritos();
		}
	}

	@Override
	protected MensajeVehiculo getMensaje(String[] a) throws Exception {
		if (a.length != 10) {
			throw new Exception("Línea con cantidad de parámetros distinta a la esperada.");
		}

		int precioCompra = Integer.valueOf(a[0]);
		int precioMant = Integer.valueOf(a[1]);
		int precio = Integer.valueOf(a[2]);
		int numPuertas = Integer.valueOf(a[3]);
		int numAsientos = Integer.valueOf(a[4]);
		int tamanioBaul = Integer.valueOf(a[5]);
		int confort = Integer.valueOf(a[6]);
		int seguridad = Integer.valueOf(a[7]);
		int tech = Integer.valueOf(a[8]);
		int car = Integer.valueOf(a[9]);

		MensajeVehiculo linea = new MensajeVehiculo();

		linea.setPrecioCompra(new ValorCampo(NivelPrecio.getFromCode(precioCompra)));
		linea.setPrecioMant(new ValorCampo(NivelPrecio.getFromCode(precioMant)));
		linea.setPrecio(new ValorCampo(precio));

		linea.setNumeroPuertas(new ValorCampo(NumeroPuertas.getFromCode(numPuertas)));
		linea.setNumeroAsientos(new ValorCampo(NumeroAsientos.getFromCode(numAsientos)));
		linea.setTamanioBaul(new ValorCampo(TamanioBaul.getFromCode(tamanioBaul)));
		linea.setConfort(new ValorCampo(confort));
		linea.setSeguridad(new ValorCampo(NivelSeguridad.getFromCode(seguridad)));
		linea.setTech(new ValorCampo(tech));

		linea.setCar(new ValorCampo(car));

		return linea;
	}
}