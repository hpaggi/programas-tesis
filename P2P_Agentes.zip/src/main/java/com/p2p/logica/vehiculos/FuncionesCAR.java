package com.p2p.logica.vehiculos;

import com.p2p.util.CommonUtils;

public class FuncionesCAR {

	public static double calcularAceptabilidad(double precio, double caracteristicasTecnicas) {
		double valoracion = 0;

		valoracion = precio * caracteristicasTecnicas;

		return CommonUtils.roundDouble(valoracion, 5);
	}
}