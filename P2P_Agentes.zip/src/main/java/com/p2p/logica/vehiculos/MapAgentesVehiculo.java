package com.p2p.logica.vehiculos;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.p2p.entidades.vehiculos.AgenteVehiculo;

public class MapAgentesVehiculo {

	private static Map<String, AgenteVehiculo> map;

	/**
	 * Inicializa el mapa de agentes vacío.
	 */
	public static void init() {
		map = new HashMap<String, AgenteVehiculo>();
	}

	public static int size() {
		return map.size();
	}

	public static boolean isEmpty() {
		return map.isEmpty();
	}

	public static boolean containsKey(Object key) {
		return map.containsKey(key);
	}

	public static boolean containsValue(Object value) {
		return map.containsValue(value);
	}

	public static AgenteVehiculo get(Object key) {
		return map.get(key);
	}

	public static AgenteVehiculo put(String key, AgenteVehiculo value) {
		return map.put(key, value);
	}

	public static AgenteVehiculo remove(Object key) {
		return map.remove(key);
	}

	public static Collection<AgenteVehiculo> values() {
		List<AgenteVehiculo> list = new ArrayList<AgenteVehiculo>(map.values());
		Collections.sort(list);
		return list;
	}

	public static Set<Entry<String, AgenteVehiculo>> entrySet() {
		return map.entrySet();
	}
}