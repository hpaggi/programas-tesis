package com.p2p.logica.vehiculos;

import com.p2p.enums.vehiculos.NivelPrecio;
import com.p2p.util.CommonUtils;

public class FuncionesPRECIO {

	public static double calcularPrecio(NivelPrecio precioCompra, NivelPrecio precioMantenimiento) {
		double valoracion = 0;

		double valorPrecioCompra = valorSegunPrecioCompra(precioCompra);
		double valorPrecioMantenimiento = valorSegunPrecioMantenimiento(precioMantenimiento);

		valoracion = valorPrecioCompra * valorPrecioMantenimiento;

		return CommonUtils.roundDouble(valoracion, 5);
	}

	private static double valorSegunPrecioCompra(NivelPrecio precioCompra) {
		double valoracion = 0;

		switch (precioCompra) {
		case BAJO:
			valoracion = 1;
			break;
		case MEDIO:
			valoracion = 3;
			break;
		case ALTO:
			valoracion = 2;
			break;
		case MUY_ALTO:
			valoracion = 1;
			break;
		default:
			break;
		}
		return valoracion;
	}

	private static double valorSegunPrecioMantenimiento(NivelPrecio precioMantenimiento) {
		double valoracion = 0;

		switch (precioMantenimiento) {
		case BAJO:
			valoracion = 1;
			break;
		case MEDIO:
			valoracion = 3;
			break;
		case ALTO:
			valoracion = 2;
			break;
		case MUY_ALTO:
			valoracion = 1;
			break;
		default:
			break;
		}
		return valoracion;
	}
}