package com.p2p.logica.vehiculos;

import com.p2p.enums.vehiculos.NumeroAsientos;
import com.p2p.enums.vehiculos.NumeroPuertas;
import com.p2p.enums.vehiculos.TamanioBaul;
import com.p2p.util.CommonUtils;

public class FuncionesCONFORT {

	public static double calcularConfort(NumeroPuertas numPuertas, NumeroAsientos numAsientos, TamanioBaul tamBaul) {
		double valoracion = 0;

		double valoracionNumPuertas = valorSegunNumPuertas(numPuertas);
		double valoracionNumAsientos = valorSegunNumAsientos(numAsientos);
		double valoracionTamanioBaul = valorSegunTamanioBaul(tamBaul);

		valoracion = valoracionNumPuertas * valoracionNumAsientos * valoracionTamanioBaul;

		return CommonUtils.roundDouble(valoracion, 5);
	}

	private static double valorSegunNumPuertas(NumeroPuertas numPuertas) {
		double valoracion = 0;

		switch (numPuertas) {
		case DOS:
			valoracion = 2;
			break;
		case TRES:
			valoracion = 3;
			break;
		case CUATRO:
			valoracion = 4;
			break;
		case CINCO_O_MAS:
			valoracion = 5;
			break;
		default:
			break;
		}
		return valoracion;
	}

	private static double valorSegunNumAsientos(NumeroAsientos numAsientos) {
		double valoracion = 0;

		switch (numAsientos) {
		case DOS:
			valoracion = 2;
			break;
		case CUATRO:
			valoracion = 4;
			break;
		case MAS_DE_CUATRO:
			valoracion = 5;
			break;
		default:
			break;
		}
		return valoracion;
	}

	private static double valorSegunTamanioBaul(TamanioBaul tamBaul) {
		double valoracion = 0;

		switch (tamBaul) {
		case PEQUENIO:
			valoracion = 1;
			break;
		case MEDIO:
			valoracion = 2;
			break;
		case GRANDE:
			valoracion = 3;
			break;
		default:
			break;
		}
		return valoracion;
	}
}