package com.p2p.logica.sitiosWeb;

import java.time.Duration;
import java.time.Instant;

import com.p2p.entidades.SalidaConsulta;
import com.p2p.entidades.ValorCampo;
import com.p2p.entidades.sitiosWeb.AgenteSitioWeb;
import com.p2p.entidades.sitiosWeb.AgentesFavoritosSitioWeb;
import com.p2p.entidades.sitiosWeb.HilosAppSitioWeb;
import com.p2p.entidades.sitiosWeb.MensajeSitioWeb;
import com.p2p.entidades.sitiosWeb.SalidaConsultaOtrosAgentesSitioWeb;
import com.p2p.enums.sitiosWeb.CampoSitioWeb;
import com.p2p.logica.AbstractService;
import com.p2p.logica.LogService;
import com.p2p.logica.MensajesService;
import com.p2p.util.CommonUtils;

public class SitiosWebService extends
		AbstractService<AgenteSitioWeb, MensajeSitioWeb, CampoSitioWeb, AgentesFavoritosSitioWeb, SalidaConsultaOtrosAgentesSitioWeb> {

	private static SitiosWebService instance = new SitiosWebService();

	private SitiosWebService() {
		super();
	}

	public static SitiosWebService getInstance() {
		LogService.getInstance().writeln("Instanciando servicio SitiosWebService.");
		return instance;
	}

	@SuppressWarnings("deprecation")
	@Override
	protected void iniciarConsulta() {
		for (MensajeSitioWeb mensaje : listaDeDatos) {
			Instant now = Instant.now();
			int indiceMsg = mensaje.getIndiceMsg();

			LogService.getInstance().writeln("###################################  Antes de consultar mensaje número " + indiceMsg
					+ "  ###################################");

			SalidaConsulta salida = null;
			Thread hiloConsulta = new Thread(new Runnable() {
				@Override
				public void run() {
					agenteRaiz.consultar(null, 0d, mensaje, CampoSitioWeb.RESULT, 0);
				}
			});
			hiloConsulta.setName("Hilo de" + agenteRaiz.getNombre() + " Nivel: " + 0);
			hiloConsulta.start();

			try {
				hiloConsulta.join(timeoutEsperaRespuesta * 1000);

				salida = agenteRaiz.getSalidaConsulta();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			LogService.getInstance().writeln("###################################  Después de consultar mensaje número " + indiceMsg
					+ "  ###################################\n");

			Duration duration = CommonUtils.timing(now);

			if (salida != null) {
				LogService.getInstance().writeln("Respuesta recibida por el SERVICIO.");
				LogService.getInstance().writeln("	Calidad recibida=" + salida.getCalidad());
				LogService.getInstance().writeln("	Tiempo entre enviar y recibir mensaje=" + duration.getSeconds() + " segs.");
				LogService.getInstance().writeln("	Valor recibido de RESULT: " + salida.getValor() + "");
				mensaje.getCampo(CampoSitioWeb.RESULT).setValor(salida.getValor());
			} else {
				LogService.getInstance().writeln("@@@@@@@@@@@@@@@@ Valor de RESULT: SERVICO NO LLEGÓ A ESPERAR @@@@@@@@@@@@@@@@");
			}
			HilosAppSitioWeb.stopAllThreads((AgenteSitioWeb) agenteRaiz);
			hiloConsulta.stop();

			LogService.getInstance().write("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ ");
			LogService.getInstance().write("Duración entre entrada y salida de mensaje número ");
			LogService.getInstance().writeln(indiceMsg + ": " + duration.getSeconds() + " segs. @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
			LogService.getInstance().writeln();

			logMensajes.add(mensaje.toStringUnaLinea());
		}

		LogService.getInstance().writeln();
		LogService.getInstance().write("###################################  ");
		LogService.getInstance().write("Cantidad de mensajes gastados por registro");
		LogService.getInstance().writeln("  ###################################");

		for (MensajeSitioWeb mensaje : listaDeDatos) {
			int indiceMsg = mensaje.getIndiceMsg();
			int cant = MensajesService.getInstance().getCant(indiceMsg);

			LogService.getInstance().write("	Registro " + indiceMsg + ": " + cant);
			LogService.getInstance().writeln(cant == 1 ? " mensaje." : " mensajes.");
		}

		LogService.getInstance().writeln();
		LogService.getInstance().writeln(
				"-------------------------------------------------------------------------------------------------------------------------------------");
		LogService.getInstance().writeln(
				"-------------------------------------------------------- FIN DE LA EJECUCIÓN --------------------------------------------------------");
		LogService.getInstance().writeln(
				"-------------------------------------------------------------------------------------------------------------------------------------");

		LogService.getInstance().writeln();
		imprimirLogsDeAgentes();
	}

	@Override
	protected CampoSitioWeb getTipoCampo(MensajeSitioWeb mensaje) {
		return mensaje.getCampoBase();
	}

	/**
	 * Instancia los agentes para que puedan interactuar.
	 */
	@Override
	protected void instanciarAgentes() {
		MapAgentesSitioWeb.init();

		agenteRaiz = new AgenteSitioWeb("Agente OMEGA", true, cantMensajesXAgente, cantMaxFavoritos, timeoutEsperaRespuesta, peso, modo);
		LogService.getInstance().writeln("Instanciando agente: " + agenteRaiz);

		// MapAgentesSitioWeb.put("Agente OMEGA", agenteRaiz);

		for (int i = 1; i <= cantAgentes; i++) {
			String nombre = "Agente " + i;
			AgenteSitioWeb agente = new AgenteSitioWeb(nombre, false, cantMensajesXAgente, cantMaxFavoritos, timeoutEsperaRespuesta, peso,
					modo);

			LogService.getInstance().writeln("Instanciando agente: " + agente);
			MapAgentesSitioWeb.put(nombre, agente);
		}
		LogService.getInstance().writeln();

		listaAgentes = MapAgentesSitioWeb.values();
		agenteRaiz.inicializarListaFavoritos();
		for (AgenteSitioWeb agente : MapAgentesSitioWeb.values()) {
			agente.inicializarListaFavoritos();
		}
	}

	@Override
	protected MensajeSitioWeb getMensaje(String[] a) throws Exception {
		if (a.length != 35) {
			throw new Exception("Línea con cantidad de parámetros distinta a la esperada.");
		}

		int having_IP_Address = Integer.valueOf(a[0]);
		int URL_Length = Integer.valueOf(a[1]);
		int Shortining_Service = Integer.valueOf(a[2]);
		int having_At_Symbol = Integer.valueOf(a[3]);
		int double_slash_redirecting = Integer.valueOf(a[4]);
		int Prefix_Suffix = Integer.valueOf(a[5]);
		int having_Sub_Domain = Integer.valueOf(a[6]);
		int SSLfinal_State = Integer.valueOf(a[7]);
		int Domain_registeration_length = Integer.valueOf(a[8]);
		int Favicon = Integer.valueOf(a[9]);
		int HTTPS_token = Integer.valueOf(a[10]);
		int port = Integer.valueOf(a[11]);
		int ADDRESS_BAR_BASED_FEATURES = Integer.valueOf(a[12]);

		int Request_URL = Integer.valueOf(a[13]);
		int URL_of_Anchor = Integer.valueOf(a[14]);
		int Links_in_tags = Integer.valueOf(a[15]);
		int SFH = Integer.valueOf(a[16]);
		int Submitting_to_email = Integer.valueOf(a[17]);
		int Abnormal_URL = Integer.valueOf(a[18]);
		int ABNORMAL_BASED_FEATURES = Integer.valueOf(a[19]);

		int Redirect = Integer.valueOf(a[20]);
		int on_mouseover = Integer.valueOf(a[21]);
		int RightClick = Integer.valueOf(a[22]);
		int popUpWidnow = Integer.valueOf(a[23]);
		int Iframe = Integer.valueOf(a[24]);
		int HTML_AND_JAVASCRIPT_BASED_FEATURES = Integer.valueOf(a[25]);

		int age_of_domain = Integer.valueOf(a[26]);
		int DNSRecord = Integer.valueOf(a[27]);
		int web_traffic = Integer.valueOf(a[28]);
		int Page_Rank = Integer.valueOf(a[29]);
		int Google_Index = Integer.valueOf(a[30]);
		int Links_pointing_to_page = Integer.valueOf(a[31]);
		int Statistical_report = Integer.valueOf(a[32]);
		int DOMAIN_BASED_FEATURES = Integer.valueOf(a[33]);

		int RESULT = Integer.valueOf(a[34]);

		MensajeSitioWeb linea = new MensajeSitioWeb();

		linea.setHaving_IP_Address(new ValorCampo(having_IP_Address));
		linea.setURL_Length(new ValorCampo(URL_Length));
		linea.setShortining_Service(new ValorCampo(Shortining_Service));
		linea.setHaving_At_Symbol(new ValorCampo(having_At_Symbol));
		linea.setDouble_slash_redirecting(new ValorCampo(double_slash_redirecting));
		linea.setPrefix_Suffix(new ValorCampo(Prefix_Suffix));
		linea.setHaving_Sub_Domain(new ValorCampo(having_Sub_Domain));
		linea.setSSLfinal_State(new ValorCampo(SSLfinal_State));
		linea.setDomain_registeration_length(new ValorCampo(Domain_registeration_length));
		linea.setFavicon(new ValorCampo(Favicon));
		linea.setHTTPS_token(new ValorCampo(HTTPS_token));
		linea.setPort(new ValorCampo(port));
		linea.setADDRESS_BAR_BASED_FEATURES(new ValorCampo(ADDRESS_BAR_BASED_FEATURES));

		linea.setRequest_URL(new ValorCampo(Request_URL));
		linea.setURL_of_Anchor(new ValorCampo(URL_of_Anchor));
		linea.setLinks_in_tags(new ValorCampo(Links_in_tags));
		linea.setSFH(new ValorCampo(SFH));
		linea.setSubmitting_to_email(new ValorCampo(Submitting_to_email));
		linea.setAbnormal_URL(new ValorCampo(Abnormal_URL));
		linea.setABNORMAL_BASED_FEATURES(new ValorCampo(ABNORMAL_BASED_FEATURES));

		linea.setRedirect(new ValorCampo(Redirect));
		linea.setOn_mouseover(new ValorCampo(on_mouseover));
		linea.setRightClick(new ValorCampo(RightClick));
		linea.setPopUpWidnow(new ValorCampo(popUpWidnow));
		linea.setIframe(new ValorCampo(Iframe));
		linea.setHTML_AND_JAVASCRIPT_BASED_FEATURES(new ValorCampo(HTML_AND_JAVASCRIPT_BASED_FEATURES));

		linea.setAge_of_domain(new ValorCampo(age_of_domain));
		linea.setDNSRecord(new ValorCampo(DNSRecord));
		linea.setWeb_traffic(new ValorCampo(web_traffic));
		linea.setPage_Rank(new ValorCampo(Page_Rank));
		linea.setGoogle_Index(new ValorCampo(Google_Index));
		linea.setLinks_pointing_to_page(new ValorCampo(Links_pointing_to_page));
		linea.setStatistical_report(new ValorCampo(Statistical_report));
		linea.setDOMAIN_BASED_FEATURES(new ValorCampo(DOMAIN_BASED_FEATURES));

		linea.setRESULT(new ValorCampo(RESULT));

		return linea;
	}
}