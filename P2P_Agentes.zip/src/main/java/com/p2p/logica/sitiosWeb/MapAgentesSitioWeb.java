package com.p2p.logica.sitiosWeb;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.p2p.entidades.sitiosWeb.AgenteSitioWeb;

public class MapAgentesSitioWeb {

	private static Map<String, AgenteSitioWeb> map;

	/**
	 * Inicializa el mapa de agentes vacío.
	 */
	public static void init() {
		map = new HashMap<String, AgenteSitioWeb>();
	}

	public static int size() {
		return map.size();
	}

	public static boolean isEmpty() {
		return map.isEmpty();
	}

	public static boolean containsKey(Object key) {
		return map.containsKey(key);
	}

	public static boolean containsValue(Object value) {
		return map.containsValue(value);
	}

	public static AgenteSitioWeb get(Object key) {
		return map.get(key);
	}

	public static AgenteSitioWeb put(String key, AgenteSitioWeb value) {
		return map.put(key, value);
	}

	public static AgenteSitioWeb remove(Object key) {
		return map.remove(key);
	}

	public static Collection<AgenteSitioWeb> values() {
		List<AgenteSitioWeb> list = new ArrayList<AgenteSitioWeb>(map.values());
		Collections.sort(list);
		return list;
	}

	public static Set<Entry<String, AgenteSitioWeb>> entrySet() {
		return map.entrySet();
	}
}