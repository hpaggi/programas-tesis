package com.p2p.ui;

public class Main {

	public static void main(String[] args) {

		/** Instanciamos el objeto */
		VentanaPrincipal miVentanaPrincipal = new VentanaPrincipal();

		// /**
		// * Enviamos el objeto como parametro para que sea unico
		// * en toda la aplicación
		// */
		// miVentanaPrincipal.setVentanaPrincipal(miVentanaPrincipal);

		/** Hacemos que se cargue la ventana */
		miVentanaPrincipal.setVisible(true);
	}
}
