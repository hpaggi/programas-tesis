package com.p2p.ui;

import static com.p2p.enums.TipoParametro.ARCHIVO_DATOS;
import static com.p2p.enums.TipoParametro.CANTIDAD_AGENTES;
import static com.p2p.enums.TipoParametro.CANTIDAD_EJECUCIONES;
import static com.p2p.enums.TipoParametro.CANTIDAD_MENSAJES;
import static com.p2p.enums.TipoParametro.MODO;
import static com.p2p.enums.TipoParametro.PESO;
import static com.p2p.enums.TipoParametro.TIMEOUT_ESPERA_RESPUESTA;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.SplashScreen;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.apache.commons.lang3.StringUtils;

import com.p2p.entidades.Parametro;
import com.p2p.enums.Modo;
import com.p2p.enums.TipoNegocio;
import com.p2p.enums.TipoParametro;
import com.p2p.logica.AbstractService;
import com.p2p.logica.LogService;
import com.p2p.logica.MensajesService;
import com.p2p.logica.creditos.CreditosService;
import com.p2p.logica.sitiosWeb.SitiosWebService;
import com.p2p.logica.vehiculos.VehiculosService;
import com.p2p.util.CommonUtils;

public class VentanaPrincipal extends JFrame implements ActionListener {

	private static final long serialVersionUID = -8084613804821826300L;

	private static final int ANCHO_VENTANA = 1600;// 500;
	private static final int ALTO_VENTANA = 790;// 420;
	private static final int MARGEN_IZQ_COL_1 = 20;
	private static final int MARGEN_IZQ_COL_2 = 420;
	private static final int MARGEN_IZQ_COL_3 = 820;
	private static final int ALTO_RENGLON = 40;
	private static final int ANCHO_LABELS = 200;
	private static final Font FONT = new Font("Arial", Font.BOLD, 14);

	private Container contenedor;

	private JLabel labelCantAgentes;
	private JTextField txtCantAgentes;

	private JLabel labelCantMensajes;
	private JTextField txtCantMensajes;

	private JLabel labelCantMaxFavoritos;
	private JTextField txtCantMaxFavoritos;

	private JLabel labelTimeoutEsperaRespuesta;
	private JTextField txtTimeoutEsperaRespuesta;

	private JLabel labelPeso;
	private JTextField txtPeso;

	private JLabel labelCantEjecuciones;
	private JTextField txtCantEjecuciones;

	private JLabel labelTipoNegocio;
	private JComboBox<TipoNegocio> comboBoxTipoNegocio;

	private JLabel labelModo;
	private JComboBox<Modo> comboBoxModo;

	// private JLabel labelCalidadRaiz;
	// private JTextField txtCalidadRaiz;

	private JLabel labelArchivoDatos;
	private JButton buttonArchivoDatos;
	private JLabel labelNombreArchivo;
	private File archivoDatos;

	private JLabel labelMensajes;
	private JButton botonIniciar;
	private JButton botonMostrarMensajes;
	private JButton botonGuardarLogs;

	private JTextArea textAreaLogs;

	private AbstractService<?, ?, ?, ?, ?> service;

	// /** declaramos el objeto Label */
	// private VentanaPrincipal miVentanaPrincipal;

	public VentanaPrincipal() {
		splash();

		/** permite iniciar las propiedades de los componentes */
		iniciarComponentes();

		/** Asigna un titulo a la barra de titulo */
		setTitle("P2P Agentes");

		/** tamaño de la ventana */
		setSize(ANCHO_VENTANA, ALTO_VENTANA);

		/** pone la ventana en el Centro de la pantalla */
		setLocationRelativeTo(null);

		URL url = getClass().getResource("/images/icon.png");
		ImageIcon img = new ImageIcon(url);
		setIconImage(img.getImage());

		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				LogService.getInstance().writeln("--------------------------------------");
				LogService.getInstance().writeln("Cerrando aplicación P2P Agentes.");
				LogService.getInstance().writeln("--------------------------------------");

				setVisible(false);
				dispose();
				System.exit(0);
			}
		});
	}

	private void splash() {
		final SplashScreen splash = SplashScreen.getSplashScreen();
		if (splash == null) {
			System.out.println("SplashScreen.getSplashScreen() returned null");
			return;
		}
		Graphics2D g = splash.createGraphics();
		if (g == null) {
			System.out.println("g is null");
			return;
		}
		for (int i = 0; i < 270; i++) {
			renderChar(g, i);
			splash.update();
			try {
				Thread.sleep(17);
			} catch (InterruptedException e) {
			}
		}
		splash.close();
	}

	// private void renderSplashFrame(Graphics2D g, int frame) {
	// final String[] arr = { "foo", "bar", "baz" };
	// g.setComposite(AlphaComposite.Clear);
	// g.fillRect(120, 140, 400, 140);
	// g.setPaintMode();
	// g.setColor(Color.DARK_GRAY);
	// Font font = new Font("Arial", Font.BOLD, 14);
	// g.setFont(font);
	// g.drawString("Cargando " + arr[(frame / 5) % 3] + "... " + frame, 220, 200);
	//
	// // g.drawString("Cargando " + CommonUtils.repeatChar(".", frame), 220, 200);
	// }

	private void renderChar(Graphics2D g, int frame) {
		final String[] arr = { "!", "$", "%", "&", "/", "(", ")", "=", "?", "¿", "¡", "|", "@", "#", "~", "€", "¬", "<", ">", "\\", "-",
				"_", ",", ";", ":", "{", "[", "]", "}" };
		g.setComposite(AlphaComposite.Clear);
		g.fillRect(120, 140, 500, 140);
		g.setPaintMode();
		g.setColor(Color.DARK_GRAY);
		Font font = new Font("Arial", Font.BOLD, 14);
		g.setFont(font);
		// g.drawString("Cargando " + arr[(frame / 5) % 3] + "... " + frame, 220, 200);

		String car = arr[CommonUtils.integerBetween(0, arr.length - 1)];
		String puntos = CommonUtils.repeatChar("...", frame / 10);

		g.drawString("Cargando." + puntos + car, 220, 250);
	}

	// /**
	// * Enviamos una instancia de la ventana principal
	// */
	// public void setVentanaPrincipal(VentanaPrincipal miVentana) {
	// miVentanaPrincipal = miVentana;
	// }

	private void iniciarComponentes() {
		int y = 20;
		contenedor = getContentPane();

		/**
		 * Instanciamos el contenedor.
		 * Con esto definmos nosotros mismos los tamaños y posicion de los componentes.
		 */
		contenedor.setLayout(null);

		y = crearCampoCantAgentes(y);
		y = crearCampoCantMensajes(y);
		y = crearCampoTimeoutEsperaRespuesta(y);
		y = crearCampoPeso(y);
		y = 20;// Segunda columna
		y = crearCampoCantEjecuciones(y);
		y = crearComboTipoNegocio(y);
		y = crearComboModo(y);
		// y = crearCampoCalidadRaiz(y);
		y = crearSeleccionarArchivoDatos(y);
		y = 20;// Tercer columna
		y = crearCampoCantMaxFavoritos(y);
		y = 210;
		y = crearTextAreaLogs(y);
		y = y + ALTO_RENGLON;

		crearLabelMensajes();

		crearBotonIniciar();
		crearBotonMostrarMensajes();
		crearBotonGuardarLogs();

		setearValoresDefault();
	}

	private void setearValoresDefault() {
		txtCantAgentes.setText("2");
		txtCantMensajes.setText("100");
		txtCantMaxFavoritos.setText("5");
		txtPeso.setText("0");
		txtTimeoutEsperaRespuesta.setText("100");
		// archivoDatos = new File(
		// "C:\\Users\\German\\Desktop\\GermanK\\Trabajos personales\\Horacio Paggi\\Negocio Vehículos\\Mensage 1 registro.txt");

		txtCantEjecuciones.setText("1");
		comboBoxTipoNegocio.setSelectedIndex(1);
		comboBoxModo.setSelectedIndex(1);
		// txtCalidadRaiz.setText("1");
	}

	private int crearCampoCantAgentes(int y) {
		labelCantAgentes = new JLabel();
		labelCantAgentes.setFont(FONT);
		labelCantAgentes.setText("Cantidad de Agentes:");
		labelCantAgentes.setBounds(MARGEN_IZQ_COL_1, y, ANCHO_LABELS, 23);
		contenedor.add(labelCantAgentes);

		txtCantAgentes = new JTextField("", 5);
		txtCantAgentes.setFont(FONT);
		txtCantAgentes.setBounds(ANCHO_LABELS + 20, y, 50, 23);
		contenedor.add(txtCantAgentes);

		return y + ALTO_RENGLON;
	}

	private int crearCampoCantMensajes(int y) {
		labelCantMensajes = new JLabel();
		labelCantMensajes.setFont(FONT);
		labelCantMensajes.setText("Cantidad de mensages:");
		labelCantMensajes.setBounds(MARGEN_IZQ_COL_1, y, ANCHO_LABELS, 23);
		contenedor.add(labelCantMensajes);

		txtCantMensajes = new JTextField("", 5);
		txtCantMensajes.setFont(FONT);
		txtCantMensajes.setBounds(ANCHO_LABELS + 20, y, 50, 23);
		contenedor.add(txtCantMensajes);

		return y + ALTO_RENGLON;
	}

	private int crearCampoTimeoutEsperaRespuesta(int y) {
		labelTimeoutEsperaRespuesta = new JLabel();
		labelTimeoutEsperaRespuesta.setFont(FONT);
		labelTimeoutEsperaRespuesta.setText("Timeout espera respuesta:");
		labelTimeoutEsperaRespuesta.setBounds(MARGEN_IZQ_COL_1, y, ANCHO_LABELS, 23);
		contenedor.add(labelTimeoutEsperaRespuesta);

		txtTimeoutEsperaRespuesta = new JTextField("", 5);
		txtTimeoutEsperaRespuesta.setFont(FONT);
		txtTimeoutEsperaRespuesta.setBounds(ANCHO_LABELS + 20, y, 50, 23);
		contenedor.add(txtTimeoutEsperaRespuesta);

		return y + ALTO_RENGLON;
	}

	private int crearCampoPeso(int y) {
		labelPeso = new JLabel();
		labelPeso.setFont(FONT);
		labelPeso.setText("Peso:");
		labelPeso.setBounds(MARGEN_IZQ_COL_1, y, ANCHO_LABELS, 23);
		contenedor.add(labelPeso);

		txtPeso = new JTextField("", 5);
		txtPeso.setFont(FONT);
		txtPeso.setBounds(ANCHO_LABELS + 20, y, 50, 23);
		contenedor.add(txtPeso);

		return y + ALTO_RENGLON;
	}

	private int crearCampoCantEjecuciones(int y) {
		labelCantEjecuciones = new JLabel();
		labelCantEjecuciones.setFont(FONT);
		labelCantEjecuciones.setText("Cantidad de ejecuciones:");
		labelCantEjecuciones.setBounds(MARGEN_IZQ_COL_2, y, ANCHO_LABELS, 23);
		contenedor.add(labelCantEjecuciones);

		txtCantEjecuciones = new JTextField("", 5);
		txtCantEjecuciones.setFont(FONT);
		txtCantEjecuciones.setBounds(MARGEN_IZQ_COL_2 + ANCHO_LABELS + 20, y, 50, 23);
		contenedor.add(txtCantEjecuciones);

		return y + ALTO_RENGLON;
	}

	private int crearComboTipoNegocio(int y) {
		labelTipoNegocio = new JLabel();
		labelTipoNegocio.setFont(FONT);
		labelTipoNegocio.setText("Tipo de negocio:");
		labelTipoNegocio.setBounds(MARGEN_IZQ_COL_2, y, ANCHO_LABELS, 23);
		contenedor.add(labelTipoNegocio);

		comboBoxTipoNegocio = new JComboBox<TipoNegocio>();
		comboBoxTipoNegocio.setFont(FONT);
		comboBoxTipoNegocio.addItem(null);
		comboBoxTipoNegocio.addItem(TipoNegocio.VEHICULOS);
		comboBoxTipoNegocio.addItem(TipoNegocio.SITIOS_WEB);
		comboBoxTipoNegocio.addItem(TipoNegocio.CREDITOS);
		comboBoxTipoNegocio.setBounds(MARGEN_IZQ_COL_2 + ANCHO_LABELS + 20, y, 130, 23);
		contenedor.add(comboBoxTipoNegocio);

		return y + ALTO_RENGLON;
	}

	private int crearComboModo(int y) {
		labelModo = new JLabel();
		labelModo.setFont(FONT);
		labelModo.setText("Modo:");
		labelModo.setBounds(MARGEN_IZQ_COL_2, y, ANCHO_LABELS, 23);
		contenedor.add(labelModo);

		comboBoxModo = new JComboBox<Modo>();
		comboBoxModo.setFont(FONT);
		comboBoxModo.addItem(null);
		comboBoxModo.addItem(Modo.INTELIGENTE);
		comboBoxModo.addItem(Modo.SIMPLE);
		comboBoxModo.setBounds(MARGEN_IZQ_COL_2 + ANCHO_LABELS + 20, y, 130, 23);
		contenedor.add(comboBoxModo);

		return y + ALTO_RENGLON;
	}

	// private int crearCampoCalidadRaiz(int y) {
	// labelCalidadRaiz = new JLabel();
	// labelCalidadRaiz.setFont(FONT);
	// labelCalidadRaiz.setText("Calidad raíz:");
	// labelCalidadRaiz.setBounds(MARGEN_IZQ_COL_2, y, ANCHO_LABELS, 23);
	// contenedor.add(labelCalidadRaiz);
	//
	// txtCalidadRaiz = new JTextField("", 5);
	// txtCalidadRaiz.setFont(FONT);
	// txtCalidadRaiz.setBounds(MARGEN_IZQ_COL_2+ANCHO_LABELS + 20, y, 100, 23);
	// contenedor.add(txtCalidadRaiz);
	//
	// return y + ALTO_RENGLON;
	// }

	private int crearSeleccionarArchivoDatos(int y) {
		labelArchivoDatos = new JLabel();
		labelArchivoDatos.setFont(FONT);
		labelArchivoDatos.setText("Archivo de datos:");
		labelArchivoDatos.setBounds(MARGEN_IZQ_COL_2, y, ANCHO_LABELS, 23);
		contenedor.add(labelArchivoDatos);

		buttonArchivoDatos = new JButton("Examinar...");
		buttonArchivoDatos.setFont(FONT);
		buttonArchivoDatos.setBounds(MARGEN_IZQ_COL_2 + ANCHO_LABELS + 20, y, 120, 23);
		contenedor.add(buttonArchivoDatos);

		labelNombreArchivo = new JLabel();
		labelNombreArchivo.setBounds(MARGEN_IZQ_COL_2, y + 30, ANCHO_VENTANA - 20, 23);
		contenedor.add(labelNombreArchivo);

		buttonArchivoDatos.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JFileChooser fileChooser = new JFileChooser();
				fileChooser.setCurrentDirectory(new File(System.getProperty("user.home") + "\\Desktop"));
				fileChooser.setDialogTitle("Seleccione su archivo de datos");
				fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
				fileChooser.setAcceptAllFileFilterUsed(false);

				int result = fileChooser.showOpenDialog(contenedor);
				if (result == JFileChooser.APPROVE_OPTION) {
					archivoDatos = fileChooser.getSelectedFile();
					LogService.getInstance().writeln("Selected file: " + archivoDatos.getAbsolutePath());
					labelNombreArchivo.setText(archivoDatos.getAbsolutePath());
				}
			}
		});

		return y + 2 * ALTO_RENGLON;
	}

	private int crearCampoCantMaxFavoritos(int y) {
		labelCantMaxFavoritos = new JLabel();
		labelCantMaxFavoritos.setFont(FONT);
		labelCantMaxFavoritos.setText("Cantidad máx. de favoritos:");
		labelCantMaxFavoritos.setBounds(MARGEN_IZQ_COL_3, y, ANCHO_LABELS, 23);
		contenedor.add(labelCantMaxFavoritos);

		txtCantMaxFavoritos = new JTextField("", 5);
		txtCantMaxFavoritos.setFont(FONT);
		txtCantMaxFavoritos.setBounds(MARGEN_IZQ_COL_3 + ANCHO_LABELS + 20, y, 50, 23);
		contenedor.add(txtCantMaxFavoritos);

		return y + ALTO_RENGLON;
	}

	private int crearTextAreaLogs(int y) {
		textAreaLogs = new JTextArea(16, 58);
		textAreaLogs.setEditable(false); // set textArea non-editable
		// textAreaLogs.setFont(new Font("Courier", Font.PLAIN, 15));
		textAreaLogs.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 16));
		textAreaLogs.setForeground(Color.GREEN);
		textAreaLogs.setBackground(Color.DARK_GRAY);

		JScrollPane scrollPanelLog = new JScrollPane(textAreaLogs);
		scrollPanelLog.setBounds(MARGEN_IZQ_COL_1, y - 20, ANCHO_VENTANA - 57, 470);
		// scrollPanelLog.setVerticalScrollBarPolicy ( ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS );

		LogService.getInstance().init(textAreaLogs, scrollPanelLog);
		contenedor.add(scrollPanelLog);

		LogService.getInstance().writeln(
				"|----------------------------------------------------------------------------------------------------------------------------------------|");
		LogService.getInstance().writeln(
				"|------------------------------------------------ Bienvenido a la aplicación P2P Agentes ------------------------------------------------|");
		LogService.getInstance().writeln(
				"|----------------------------------------------------------------------------------------------------------------------------------------|");

		return y + 400 + 30;
	}

	private void crearLabelMensajes() {
		labelMensajes = new JLabel();
		int y = ALTO_VENTANA - 110;
		labelMensajes.setBounds(MARGEN_IZQ_COL_1, y, ANCHO_VENTANA - 20, 23);
		labelMensajes.setFont(new Font("Arial", Font.BOLD, 15));
		labelMensajes.setForeground(Color.RED);
		contenedor.add(labelMensajes);
	}

	private void crearBotonIniciar() {
		botonIniciar = new JButton();
		botonIniciar.setFont(FONT);
		botonIniciar.setText("Iniciar");
		int xBoton = (ANCHO_VENTANA / 2) - 220;
		int yBoton = ALTO_VENTANA - 80;
		botonIniciar.setBounds(xBoton, yBoton, 90, 23);
		botonIniciar.addActionListener(this);
		contenedor.add(botonIniciar);
	}

	private void crearBotonMostrarMensajes() {
		botonMostrarMensajes = new JButton();
		botonMostrarMensajes.setFont(FONT);
		botonMostrarMensajes.setText("Mostrar Mensajes");
		int xBoton = (ANCHO_VENTANA / 2) - 110;
		int yBoton = ALTO_VENTANA - 80;
		botonMostrarMensajes.setBounds(xBoton, yBoton, 170, 23);
		botonMostrarMensajes.addActionListener(this);
		contenedor.add(botonMostrarMensajes);
	}

	private void crearBotonGuardarLogs() {
		botonGuardarLogs = new JButton();
		botonGuardarLogs.setFont(FONT);
		botonGuardarLogs.setText("Guardar logs");
		int xBoton = (ANCHO_VENTANA / 2) + 80;
		int yBoton = ALTO_VENTANA - 80;
		botonGuardarLogs.setBounds(xBoton, yBoton, 130, 23);
		botonGuardarLogs.addActionListener(this);
		contenedor.add(botonGuardarLogs);
	}

	/**
	 * Método que retorna true, solo si todos los campos obligatorios fueron ingresados o elegidos.
	 */
	private boolean validarDatos() {
		if (StringUtils.isBlank(txtCantAgentes.getText())) {
			mostrarMensaje("El campo 'Cantidad de agentes' no puede ser vacío.");
			return false;
		}
		if (StringUtils.isBlank(txtCantMensajes.getText())) {
			mostrarMensaje("El campo 'Cantidad de mensajes' no puede ser vacío.");
			return false;
		}
		if (StringUtils.isBlank(txtTimeoutEsperaRespuesta.getText())) {
			mostrarMensaje("El campo 'Timeout espera respuesta' no puede ser vacío.");
			return false;
		}
		if (StringUtils.isBlank(txtPeso.getText())) {
			mostrarMensaje("El campo 'Peso' no puede ser vacío.");
			return false;
		}
		if (StringUtils.isBlank(txtCantEjecuciones.getText())) {
			mostrarMensaje("El campo 'Cantidad de ejecuciones' no puede ser vacío.");
			return false;
		}
		if (comboBoxTipoNegocio.getSelectedItem() == null) {
			mostrarMensaje("Debe elegir un 'Tipo de negocio'.");
			return false;
		}
		if (comboBoxModo.getSelectedItem() == null) {
			mostrarMensaje("Debe elegir un 'Modo'.");
			return false;
		}
		if (archivoDatos == null) {
			mostrarMensaje("Debe elegir un 'Archivo de datos'.");
			return false;
		}
		if (StringUtils.isBlank(txtCantMaxFavoritos.getText())) {
			mostrarMensaje("El campo 'Cantidad máxima de favoritos' no puede ser vacío.");
			return false;
		}

		return true;
	}

	private void mostrarMensaje(String msg) {
		labelMensajes.setText(msg);
	}

	private void borrarMensajes() {
		labelMensajes.setText("");
	}

	/** Agregamos el evento al momento de llamar la otra ventana */
	@Override
	public void actionPerformed(ActionEvent evento) {
		if (evento.getSource() == botonIniciar) {
			borrarMensajes();

			if (!validarDatos()) {
				return;
			}
			// enviamos la instancia de la ventana principal para que
			// esta sea Padre de la ventana de dialogo
			// VentanaConfirmacion miVentanaConfirmacion=new VentanaConfirmacion(miVentanaPrincipal,true);
			// miVentanaConfirmacion.setVisible(true);

			Parametro paramCantAgentes = new Parametro(CANTIDAD_AGENTES, txtCantAgentes.getText());
			Parametro paramCantMensajes = new Parametro(CANTIDAD_MENSAJES, txtCantMensajes.getText());
			Parametro paramCantMaxFavoritos = new Parametro(TipoParametro.CANTIDAD_MAX_FAVORITOS, txtCantMaxFavoritos.getText());
			Parametro paramTimeoutEsperaRespuesta = new Parametro(TIMEOUT_ESPERA_RESPUESTA, txtTimeoutEsperaRespuesta.getText());
			Parametro paramPeso = new Parametro(PESO, txtPeso.getText());
			Parametro paramCantEjecuciones = new Parametro(CANTIDAD_EJECUCIONES, txtCantEjecuciones.getText());
			Parametro paramModo = new Parametro(MODO, comboBoxModo.getSelectedItem());
			// Parametro paramCalidadRaiz = new Parametro(CALIDAD_RAIZ, txtCalidadRaiz.getText());
			Parametro paramArchivoDatos = new Parametro(ARCHIVO_DATOS, archivoDatos);

			switch ((TipoNegocio) comboBoxTipoNegocio.getSelectedItem()) {
			case VEHICULOS:
				service = VehiculosService.getInstance();
				break;
			case SITIOS_WEB:
				service = SitiosWebService.getInstance();
				break;
			case CREDITOS:
				service = CreditosService.getInstance();
				break;
			default:
				break;
			}

			int cantEjecuciones = Integer.valueOf(txtCantEjecuciones.getText());

			Thread hiloBtnIniciar = new Thread(new Runnable() {
				@Override
				public void run() {
					LogService.getInstance().clear();

					for (int i = 1; i <= cantEjecuciones; i++) {
						LogService.getInstance().writeln();
						LogService.getInstance().write("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
						LogService.getInstance().writeln("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
						LogService.getInstance().write("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
						LogService.getInstance().write(" ITERACIÓN " + i + " INICIO ");
						LogService.getInstance().writeln("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");

						MensajesService.getInstance().clearAll();
						service.clearMensajes();
						service.init(paramCantAgentes, paramCantMensajes, paramCantMaxFavoritos, paramPeso, paramCantEjecuciones, paramModo,
								/* paramCalidadRaiz, */ paramArchivoDatos, paramTimeoutEsperaRespuesta);

						LogService.getInstance().write("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
						LogService.getInstance().write(" ITERACIÓN " + i + " FIN ");
						LogService.getInstance().writeln("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
						LogService.getInstance().write("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
						LogService.getInstance().writeln("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
						LogService.getInstance().writeln();
					}

					String texto = textAreaLogs.getText();
					service.guardarLogPantallaEnArchivo(texto);
				}
			});
			hiloBtnIniciar.setName("Hilo de btnIniciar");
			hiloBtnIniciar.start();

		}
		if (evento.getSource() == botonMostrarMensajes) {
			if (service != null) {
				service.imprimirLogsMensajes();
			}
		}
		if (evento.getSource() == botonGuardarLogs) {
			if (service != null) {
				service.guardarLogsDeAgentes();
				service.guardarLogsMensajes();
			}
		}
	}
}