package com.p2p.enums;

public enum Modo {

	INTELIGENTE("Inteligente"), SIMPLE("Simple");

	private String text;

	private Modo(String text) {
		this.text = text;
	}

	public String getText() {
		return text;
	}

	@Override
	public String toString() {
		return this.getText();
	}
}