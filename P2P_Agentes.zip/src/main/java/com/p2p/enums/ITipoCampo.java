package com.p2p.enums;

public interface ITipoCampo {

	public boolean isCalculado();
}
