package com.p2p.enums.creditos;

import java.util.ArrayList;
import java.util.List;

import com.p2p.enums.ITipoCampo;

/**
 *
 * RESULT = Solicitud de crédito aprobada SI o NO<br>
 * . . FAC_POSITIVOS<br>
 * . . . . . C1<br>
 * . . . . . C3<br>
 * . . . . . C7<br>
 * . . . . . C8<br>
 * . . . . . C11<br>
 * . . . . . C15<br>
 * . . . . . C17<br>
 * . . . . . C19<br>
 * . . FAC_NEGATIVOS<br>
 * . . . . . C2<br>
 * . . . . . C4<br>
 * . . . . . C5<br>
 * . . . . . C6<br>
 * . . . . . C9<br>
 * . . . . . C10<br>
 * . . . . . C13<br>
 * . . . . . C14<br>
 * . . . . . C16<br>
 * . . . . . C18<br>
 * . . . . . C20<br>
 *
 * @author German
 */
public enum CampoCredito implements ITipoCampo {

	RESULT(true),

	FAC_POSITIVOS(true),
	C1(false),
	C3(false),
	C7(false),
	C8(false),
	C11(false),
	C15(false),
	C17(false),
	C19(false),

	FAC_NEGATIVOS(true),
	C2(false),
	C4(false),
	C5(false),
	C6(false),
	C9(false),
	C10(false),
	C13(false),
	C14(false),
	C16(false),
	C18(false),
	C20(false),

	C12(false);

	private boolean calculado;

	private CampoCredito(boolean calculado) {
		this.calculado = calculado;
	}

	@Override
	public boolean isCalculado() {
		return calculado;
	}

	/**
	 * Devuelve una lista con los campos que son calculados.
	 */
	public static List<CampoCredito> dameListaCamposCalculados() {
		List<CampoCredito> list = new ArrayList<CampoCredito>();

		for (CampoCredito campo : values()) {
			if (campo.isCalculado()) {
				list.add(campo);
			}
		}
		return list;
	}
}