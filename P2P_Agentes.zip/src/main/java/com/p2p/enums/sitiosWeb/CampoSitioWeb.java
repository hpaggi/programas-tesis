package com.p2p.enums.sitiosWeb;

import java.util.ArrayList;
import java.util.List;

import com.p2p.enums.ITipoCampo;

/**
 * RESULT = Aceptabilidad del auto<br>
 * . . ADDRESS_BAR_BASED_FEATURES<br>
 * . . . . . having_IP_Address<br>
 * . . . . . URL_Length<br>
 * . . . . . Shortining_Service<br>
 * . . . . . having_At_Symbol<br>
 * . . . . . double_slash_redirecting<br>
 * . . . . . Prefix_Suffix<br>
 * . . . . . having_Sub_Domain<br>
 * . . . . . SSLfinal_State<br>
 * . . . . . Domain_registeration_length<br>
 * . . . . . Favicon<br>
 * . . . . . HTTPS_token<br>
 * . . . . . port<br>
 * . . ABNORMAL_BASED_FEATURES<br>
 * . . . . . Request_URL<br>
 * . . . . . URL_of_Anchor<br>
 * . . . . . Links_in_tags<br>
 * . . . . . SFH<br>
 * . . . . . Submitting_to_email<br>
 * . . . . . Abnormal_URL<br>
 * . . HTML_AND_JAVASCRIPT_BASED_FEATURES<br>
 * . . . . . Redirect<br>
 * . . . . . on_mouseover<br>
 * . . . . . RightClick<br>
 * . . . . . popUpWidnow<br>
 * . . . . . Iframe<br>
 * . . DOMAIN_BASED_FEATURES<br>
 * . . . . . age_of_domain<br>
 * . . . . . DNSRecord<br>
 * . . . . . web_traffic<br>
 * . . . . . Page_Rank<br>
 * . . . . . Google_Index<br>
 * . . . . . Links_pointing_to_page<br>
 * . . . . . Statistical_report<br>
 *
 * @author German
 */
public enum CampoSitioWeb implements ITipoCampo {

	RESULT(true),
	ADDRESS_BAR_BASED_FEATURES(true),
	having_IP_Address(false),
	URL_Length(false),
	Shortining_Service(false),
	having_At_Symbol(false),
	double_slash_redirecting(false),
	Prefix_Suffix(false),
	having_Sub_Domain(false),
	SSLfinal_State(false),
	Domain_registeration_length(false),
	Favicon(false),
	HTTPS_token(false),
	port(false),
	ABNORMAL_BASED_FEATURES(true),
	Request_URL(false),
	URL_of_Anchor(false),
	Links_in_tags(false),
	SFH(false),
	Submitting_to_email(false),
	Abnormal_URL(false),
	HTML_AND_JAVASCRIPT_BASED_FEATURES(true),
	Redirect(false),
	on_mouseover(false),
	RightClick(false),
	popUpWidnow(false),
	Iframe(false),
	DOMAIN_BASED_FEATURES(true),
	age_of_domain(false),
	DNSRecord(false),
	web_traffic(false),
	Page_Rank(false),
	Google_Index(false),
	Links_pointing_to_page(false),
	Statistical_report(false);

	private boolean calculado;

	private CampoSitioWeb(boolean calculado) {
		this.calculado = calculado;
	}

	@Override
	public boolean isCalculado() {
		return calculado;
	}

	/**
	 * Devuelve una lista con los campos que son calculados.
	 */
	public static List<CampoSitioWeb> dameListaCamposCalculados() {
		List<CampoSitioWeb> list = new ArrayList<CampoSitioWeb>();

		for (CampoSitioWeb campo : values()) {
			if (campo.isCalculado()) {
				list.add(campo);
			}
		}
		return list;
	}
}