package com.p2p.enums;

public enum TipoNegocio {

	VEHICULOS("Vehículos"), SITIOS_WEB("Sitios web"), CREDITOS("Créditos");

	private String text;

	private TipoNegocio(String text) {
		this.text = text;
	}

	public String getText() {
		return text;
	}

	@Override
	public String toString() {
		return this.getText();
	}
}