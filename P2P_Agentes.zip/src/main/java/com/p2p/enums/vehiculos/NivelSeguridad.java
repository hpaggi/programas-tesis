package com.p2p.enums.vehiculos;

public enum NivelSeguridad {

	ALTA(3), MEDIA(2), BAJA(1);

	private int code;

	private NivelSeguridad(int code) {
		this.code = code;
	}

	public int getCode() {
		return code;
	}

	public static NivelSeguridad getFromCode(int code) {
		for (NivelSeguridad obj : values()) {
			if (obj.getCode() == code) {
				return obj;
			}
		}
		return null;
	}
}