package com.p2p.enums.vehiculos;

public enum NivelPrecio {

	BAJO(4), MEDIO(3), ALTO(2), MUY_ALTO(1);

	private int code;

	private NivelPrecio(int code) {
		this.code = code;
	}

	public int getCode() {
		return code;
	}

	public static NivelPrecio getFromCode(int code) {
		for (NivelPrecio obj : values()) {
			if (obj.getCode() == code) {
				return obj;
			}
		}
		return null;
	}
}