package com.p2p.enums.vehiculos;

public enum TamanioBaul {

	PEQUENIO(1), MEDIO(2), GRANDE(3);

	private int code;

	private TamanioBaul(int code) {
		this.code = code;
	}

	public int getCode() {
		return code;
	}

	public static TamanioBaul getFromCode(int code) {
		for (TamanioBaul obj : values()) {
			if (obj.getCode() == code) {
				return obj;
			}
		}
		return null;
	}
}