package com.p2p.enums.vehiculos;

import java.util.ArrayList;
import java.util.List;

import com.p2p.enums.ITipoCampo;

/**
 * CAR = Aceptabilidad del auto<br>
 * . . PRICE = Precio en general<br>
 * . . . . . precio de compra<br>
 * . . . . . precio de mantenimiento<br>
 * . . TECH = caracteristicas técnicas<br>
 * . . . . . COMFORT = confort<br>
 * . . . . . . . . nro de puertas<br>
 * . . . . . . . . nro de asientos (cantidad de pasajeros)<br>
 * . . . . . . . . tamaño del baul<br>
 * . . . . . Seguridad del auto<br>
 *
 * @author German
 */
public enum CampoVehiculo implements ITipoCampo {

	CAR(true),
	PRECIO(true),
	PRECIO_COMPRA(false),
	PRECIO_MANT(false),
	TECH(true),
	CONFORT(true),
	NUMERO_PUERTAS(false),
	NUMERO_ASIENTOS(false),
	TAMANIO_BAUL(false),
	SEGURIDAD(false);

	private boolean calculado;

	private CampoVehiculo(boolean calculado) {
		this.calculado = calculado;
	}

	@Override
	public boolean isCalculado() {
		return calculado;
	}

	/**
	 * Devuelve una lista con los campos que son calculados.
	 */
	public static List<CampoVehiculo> dameListaCamposCalculados() {
		List<CampoVehiculo> list = new ArrayList<CampoVehiculo>();

		for (CampoVehiculo campo : values()) {
			if (campo.isCalculado()) {
				list.add(campo);
			}
		}
		return list;
	}
}