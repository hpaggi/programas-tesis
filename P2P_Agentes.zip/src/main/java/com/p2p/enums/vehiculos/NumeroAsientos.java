package com.p2p.enums.vehiculos;

public enum NumeroAsientos {

	DOS(2), CUATRO(4), MAS_DE_CUATRO(5);

	private int code;

	private NumeroAsientos(int code) {
		this.code = code;
	}

	public int getCode() {
		return code;
	}

	public static NumeroAsientos getFromCode(int code) {
		for (NumeroAsientos obj : values()) {
			if (obj.getCode() == code) {
				return obj;
			}
		}
		return null;
	}
}