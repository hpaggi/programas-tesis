package com.p2p.enums.vehiculos;

public enum NumeroPuertas {

	DOS(2), TRES(3), CUATRO(4), CINCO_O_MAS(5);

	private int code;

	private NumeroPuertas(int code) {
		this.code = code;
	}

	public int getCode() {
		return code;
	}

	public static NumeroPuertas getFromCode(int code) {
		for (NumeroPuertas obj : values()) {
			if (obj.getCode() == code) {
				return obj;
			}
		}
		return null;
	}
}